/**
 * Google Apps Script - X Community Tweet Sync
 * 
 * 部署步骤：
 * 1. 打开 Google Sheets，点击 扩展程序 → Apps Script
 * 2. 删除默认代码，粘贴此文件内容
 * 3. 点击 部署 → 新建部署 → 选择类型: Web 应用
 * 4. 设置:
 *    - 执行身份: 我
 *    - 谁有权访问: 任何人
 * 5. 点击部署，复制 Web 应用 URL
 * 6. 将 URL 粘贴到扩展设置中
 * 
 * 表格结构：
 * A: ID | B: 状态 | C: 用户名 | D: 内容 | E: 链接 | F: 发布时间 | 
 * G: 点赞数 | H: 回复数 | I: 转发数 | J: 浏览量 | K: 分组 |
 * L: 已点赞 | M: 已转发 | N: 回复内容 | O: 同步时间
 */

// 处理 GET 请求 (测试连接 或 获取数据)
function doGet(e) {
    const action = e?.parameter?.action;

    // 如果 action=getData，返回表格中的所有数据
    if (action === 'getData') {
        try {
            const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
            const lastRow = sheet.getLastRow();

            if (lastRow <= 1) {
                return createResponse({ success: true, tweets: [], message: '表格为空' });
            }

            // 获取所有数据（跳过表头）- 新结构17列
            const data = sheet.getRange(2, 1, lastRow - 1, 17).getValues();
            const tweets = data.map(row => ({
                id: row[0],
                username: row[1],
                authorName: row[2],
                url: row[3],
                timestamp: row[4],
                content: row[5],
                likes: row[6],
                retweets: row[7],
                replies: row[8],
                views: row[9],
                hasMedia: row[10] === '✅',
                syncTime: row[11],
                liked: row[12] === '✅',
                retweeted: row[13] === '✅',
                replyText: row[14],
                status: row[15],
                groupId: row[16]
            })).filter(t => t.id); // 过滤掉空行

            return createResponse({
                success: true,
                tweets: tweets,
                count: tweets.length
            });
        } catch (error) {
            return createResponse({ success: false, error: error.message });
        }
    }

    // 默认：测试连接
    return ContentService
        .createTextOutput(JSON.stringify({
            success: true,
            message: 'X Community Sync Ready',
            timestamp: new Date().toISOString()
        }))
        .setMimeType(ContentService.MimeType.JSON);
}

// 处理 POST 请求 (同步推文 或 保存归纳帖)
function doPost(e) {
    try {
        const data = JSON.parse(e.postData.contents);

        // 处理保存归纳帖请求
        if (data.action === 'saveSummary') {
            return saveSummaryToSheet(data);
        }

        // 默认：处理推文同步
        const tweets = data.tweets || [];

        if (tweets.length === 0) {
            return createResponse({ success: false, error: 'No tweets provided' });
        }

        const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();

        // 确保表头存在
        ensureHeaders(sheet);

        // 获取现有ID列表用于去重
        const existingIds = getExistingIds(sheet);

        // === 预设置：在录入前，设置接下来20行的格式 ===
        const lastRow = sheet.getLastRow();
        const startRow = lastRow + 1; // 新内容开始的行

        // 设置接下来20行的行高为30
        for (let i = 0; i < 20; i++) {
            sheet.setRowHeight(startRow + i, 30);
        }

        // 设置F列（推文全文列）接下来20行为overflow（CLIP截断模式）
        sheet.getRange(startRow, 6, 20, 1).setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP);

        // 确保接下来20行不是粗体（17列）
        sheet.getRange(startRow, 1, 20, 17).setFontWeight('normal');

        let added = 0;
        let updated = 0;

        tweets.forEach(tweet => {
            // 新结构17列：推文ID, 用户名ID(@username), 作者昵称(显示名), 推文链接, 发布时间, 推文全文, 点赞数, 转发数, 回复数, 浏览数, 包含媒体, 同步时间, 已点赞, 已转推, 回复内容, 状态, 分组
            const row = [
                tweet.id,
                tweet.username,                                   // 用户名ID (@username)
                tweet.authorName || tweet.name || tweet.username, // 作者昵称 (显示名)
                tweet.url,
                formatTimestamp(tweet.timestamp),
                (tweet.content || '').replace(/\n/g, ' '),  // 移除换行符，防止撑高行高
                tweet.likes,
                tweet.retweets,
                tweet.replies,
                tweet.views,
                tweet.hasMedia ? '✅' : '❌',     // 包含媒体
                new Date().toISOString(),         // 同步时间
                tweet.liked ? '✅' : '❌',        // 已点赞
                tweet.retweeted ? '✅' : '❌',    // 已转推
                tweet.replyText || '',            // 回复内容
                tweet.status || 'scanner',        // 状态
                tweet.groupId || 'default'        // 分组
            ];

            const existingRow = existingIds[tweet.id];
            if (existingRow) {
                // 更新现有行
                sheet.getRange(existingRow, 1, 1, row.length).setValues([row]);
                updated++;
            } else {
                // 添加新行
                sheet.appendRow(row);
                const newRow = sheet.getLastRow();
                existingIds[tweet.id] = newRow;
                added++;
            }
        });

        return createResponse({
            success: true,
            added: added,
            updated: updated,
            total: tweets.length
        });

    } catch (error) {
        return createResponse({
            success: false,
            error: error.message
        });
    }
}

// 保存归纳帖到 summarize 工作表
function saveSummaryToSheet(data) {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let summarySheet = ss.getSheetByName('summarize');

    // 如果工作表不存在，创建它
    if (!summarySheet) {
        summarySheet = ss.insertSheet('summarize');
        // 设置表头
        const headers = ['ID', '创建时间', '时间范围', '内容', '是否已发布', '发布时间'];
        summarySheet.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    }

    // 生成唯一ID
    const id = 'SUM_' + Date.now();

    // 添加新记录
    const row = [
        id,
        new Date().toISOString(),           // 创建时间
        data.timeRange || '',               // 时间范围
        data.content || '',                 // 归纳帖内容
        '❌',                               // 是否已发布（默认否）
        ''                                  // 发布时间（待定）
    ];

    summarySheet.appendRow(row);

    return createResponse({
        success: true,
        id: id,
        message: '归纳帖已保存'
    });
}

// 确保表头存在
function ensureHeaders(sheet) {
    const headers = [
        '推文ID', '用户名ID', '作者昵称', '推文链接', '发布时间', '推文全文',
        '点赞数', '转发数', '回复数', '浏览数', '包含媒体',
        '同步时间', '已点赞', '已转推', '回复内容', '状态', '分组'
    ];

    const firstCell = sheet.getRange(1, 1).getValue();
    if (firstCell !== '推文ID') {
        sheet.insertRowBefore(1);
        sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
        sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold');
    }
}

// 获取现有ID及其行号
function getExistingIds(sheet) {
    const lastRow = sheet.getLastRow();
    if (lastRow <= 1) return {};

    const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    const idMap = {};

    ids.forEach((id, index) => {
        if (id[0]) {
            idMap[id[0]] = index + 2;
        }
    });

    return idMap;
}

// 格式化时间戳
function formatTimestamp(timestamp) {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    return Utilities.formatDate(date, 'Asia/Shanghai', 'yyyy-MM-dd HH:mm:ss');
}

// 创建响应
function createResponse(data) {
    return ContentService
        .createTextOutput(JSON.stringify(data))
        .setMimeType(ContentService.MimeType.JSON);
}
