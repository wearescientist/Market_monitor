# 插件中AI API调用位置汇总

## 核心AI调用函数
**位置**: `sidepanel.js` 第3298行
**函数**: `callAI(provider, apiKey, systemPrompt, tweetContent, retryCount)`
**功能**: 统一的AI API调用函数，支持多种AI提供商（OpenAI、Deepseek、Gemini、Grok等）

---

## 所有调用AI API的位置

### 1. **评论回复功能** 💬
**文件**: `comment-reply.js` 第643行
**函数**: `processNextComment()`
**用途**: 自动回复自己推文下的评论
**调用代码**:
```javascript
const replyText = await callAI(
    aiConfig.provider,
    aiConfig.apiKey,
    enhancedPrompt,
    fullContext
);
```
**使用的Prompt**: 评论回复专用的System Prompt（可单独配置）

---

### 2. **KOL扫描自动回复** 🔍
**文件**: `sidepanel.js` 第1544行
**函数**: `scanKOL()`
**用途**: 扫描KOL推文并自动回复
**调用代码**:
```javascript
const reply = await callAI(aiConfig.provider, aiConfig.apiKey, systemPrompt, tweetContent);
```
**使用的Prompt**: AI配置中的System Prompt

---

### 3. **启动AI自动回复** 🤖
**文件**: `sidepanel.js` 第3057行
**函数**: `startAIReplyPhase()` → `processNextTweet()`
**用途**: 点击"启动AI"按钮后的自动回复功能
**调用代码**:
```javascript
const replyText = await callAI(aiConfig.provider, aiConfig.apiKey, currentSystemPrompt, response.content);
```
**使用的Prompt**: AI配置中的System Prompt
**数据源**: Google表格数据源或KOL列表

---

### 4. **列表AI回复** 📋
**文件**: `sidepanel.js` 第5238行
**函数**: `startListAIReply()`
**用途**: 对列表中的推文进行AI回复
**调用代码**:
```javascript
const replyText = await callAI(aiConfig.provider, aiConfig.apiKey, systemPrompt, response.content);
```
**使用的Prompt**: AI配置中的System Prompt

---

### 5. **推文AI总结** 📝
**文件**: `sidepanel.js` 第4509行
**函数**: `generateAITweetSummary()`
**用途**: 生成推文的AI总结（用于日报显示）
**调用代码**:
```javascript
const summary = await callAI(provider, apiKey, '你是一个内容总结助手，请用简洁的一句话概括推文核心内容。', summaryPrompt);
```
**使用的Prompt**: 固定的总结Prompt（不是用户配置的System Prompt）

---

### 6. **7天总结生成** 📊
**文件**: `sidepanel.js` 第5028行
**函数**: `generate7DaySummary()`
**用途**: 生成7天的推文总结
**调用代码**:
```javascript
const summary = await callAI(aiConfig.provider, aiConfig.apiKey, systemPrompt, postsText);
```
**使用的Prompt**: 自定义的7天总结Prompt（包含详细的格式要求）

---

### 7. **项目提取功能** 🏷️
**文件**: `sidepanel.js` 第4963行
**函数**: `extractProjectsFromTweet()`
**用途**: 从推文中提取项目信息（用于项目分组）
**调用代码**:
```javascript
const extracted = await callAI(provider, apiKey, '你是一个内容分析助手，请严格按照要求的格式提取信息。', extractPrompt);
```
**使用的Prompt**: 固定的提取Prompt（要求JSON格式输出）

---

### 8. **同步到Google Sheets时的项目提取** 📤
**文件**: `sidepanel.js` 第5601行
**函数**: `syncToSheets()`
**用途**: 同步推文到Google Sheets时，提取项目信息用于分组
**调用代码**:
```javascript
const extracted = await extractProjectsFromTweet(tweet, aiConfig.provider, aiConfig.apiKey);
```
**说明**: 间接调用，通过`extractProjectsFromTweet`函数调用AI

---

## 使用的AI配置项

所有调用都使用以下配置（来自`aiConfig`对象）：

1. **`aiConfig.provider`** - AI提供商（openai、deepseek、gemini、grok等）
2. **`aiConfig.apiKey`** - API密钥
3. **`aiConfig.apiUrl`** - 自定义API地址（可选）
4. **`aiConfig.systemPrompt`** - 系统提示词（用于回复功能）
5. **`aiConfig.autoLike`** - 自动点赞设置
6. **`aiConfig.autoRepost`** - 自动转发设置
7. **`aiConfig.replyDelayMin/Max`** - 回复延迟设置
8. **`aiConfig.likeDelayMin/Max`** - 点赞延迟设置

---

## 特殊说明

### 评论回复功能
- 使用**独立的System Prompt**（`commentReplyState.systemPrompt`）
- 如果未配置，会回退到`aiConfig.systemPrompt`
- 有专门的判断逻辑（区分个人评论和项目评论）

### 总结和提取功能
- 使用**固定的Prompt**，不依赖用户配置的System Prompt
- 这些功能主要用于内容分析和总结，不是回复功能

### 黑名单机制
- 所有通过`callAI`生成的回复都会经过黑名单检查
- 如果检测到黑名单词汇，会自动重试生成（最多3次）
- 硬编码黑名单：`格局打开`、`未来可期`、`真香`、`稳了`、`HODL`等

---

## 总结

**需要调用AI API的功能共8个**：
1. ✅ 评论回复（独立Prompt）
2. ✅ KOL扫描回复
3. ✅ 启动AI自动回复
4. ✅ 列表AI回复
5. ✅ 推文AI总结
6. ✅ 7天总结生成
7. ✅ 项目提取
8. ✅ 同步到Sheets时的项目提取

**所有调用都通过统一的`callAI`函数**，确保：
- 统一的错误处理
- 统一的黑名单检查
- 统一的重试机制
- 支持多种AI提供商
