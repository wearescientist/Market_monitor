// Localize HTML Page
function localizeHtmlPage() {
    // Localize text content
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while (node = walker.nextNode()) {
        const val = node.nodeValue;
        if (val.includes('__MSG_')) {
            node.nodeValue = val.replace(/__MSG_(\w+)__/g, (match, v1) => {
                return v1 ? chrome.i18n.getMessage(v1) : "";
            });
        }
    }

    // Localize attributes
    const elements = document.getElementsByTagName('*');
    for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        for (let j = 0; j < element.attributes.length; j++) {
            const attr = element.attributes[j];
            if (attr.value.includes('__MSG_')) {
                attr.value = attr.value.replace(/__MSG_(\w+)__/g, (match, v1) => {
                    return v1 ? chrome.i18n.getMessage(v1) : "";
                });
            }
        }
    }
}

localizeHtmlPage();

// DOM Elements
const startBtn = document.getElementById('startBtn');
const clearScannerBtn = document.getElementById('clearScannerBtn');
const emptyTrashBtn = document.getElementById('emptyTrashBtn');

const scannerList = document.getElementById('scannerList');
const listList = document.getElementById('listList');
const archiveList = document.getElementById('archiveList');
const trashList = document.getElementById('trashList');
const kolList = document.getElementById('kolList');

const sortListSelect = document.getElementById('sortListSelect');
const sortArchiveSelect = document.getElementById('sortArchiveSelect');

// List Action Buttons
const listAIReplyBtn = document.getElementById('listAIReplyBtn');
const listClearBtn = document.getElementById('listClearBtn');

const navKOLs = document.getElementById('navKOLs');
const navScanner = document.getElementById('navScanner');
const navList = document.getElementById('navList');
const navArchive = document.getElementById('navArchive');
const navTrash = document.getElementById('navTrash');
const navAI = document.getElementById('navAI');

const viewKOLs = document.getElementById('viewKOLs');
const globalProgressStrip = document.getElementById('globalProgressStrip');
const globalProgressTitle = document.getElementById('globalProgressTitle');
const globalProgressMessage = document.getElementById('globalProgressMessage');
const globalProgressCount = document.getElementById('globalProgressCount');
const globalProgressBar = document.getElementById('globalProgressBar');
const globalProgressSubRow = document.getElementById('globalProgressSubRow');
const globalProgressSubLabel = document.getElementById('globalProgressSubLabel');
const globalProgressSubCount = document.getElementById('globalProgressSubCount');
const globalProgressSubBarWrap = document.getElementById('globalProgressSubBarWrap');
const globalProgressSubBar = document.getElementById('globalProgressSubBar');
const viewScanner = document.getElementById('viewScanner');
const viewList = document.getElementById('viewList');
const viewArchive = document.getElementById('viewArchive');
const viewTrash = document.getElementById('viewTrash');
const viewAI = document.getElementById('viewAI');
const viewReport = document.getElementById('viewReport');
const navReport = document.getElementById('navReport');
const reportDatePicker = document.getElementById('reportDatePicker');
const reportPostsList = document.getElementById('reportPostsList');
const reportSummary = document.getElementById('reportSummary');
const generateSummaryBtn = document.getElementById('generateSummaryBtn');
const report7DaySummary = document.getElementById('report7DaySummary');
const generate7DaySummaryBtn = document.getElementById('generate7DaySummaryBtn');

// Summary View Elements (归纳整理)
const navSummary = document.getElementById('navSummary');
const viewSummary = document.getElementById('viewSummary');
const generateSummaryPostBtn = document.getElementById('generateSummaryBtn');
const summaryDatetimeInput = document.getElementById('summaryDatetime');
const summaryStatus = document.getElementById('summaryStatus');
const summaryResult = document.getElementById('summaryResult');
const summaryActions = document.getElementById('summaryActions');
const copySummaryBtn = document.getElementById('copySummaryBtn');
const saveSummaryBtn = document.getElementById('saveSummaryBtn');

const undoToast = document.getElementById('undoToast');
const undoBtn = document.getElementById('undoBtn');

// KOL Modal Elements
const kolExportBtn = document.getElementById('kolExportBtn');
const kolImportBtn = document.getElementById('kolImportBtn');
const configFileInput = document.getElementById('configFileInput');
const kolAddBtn = document.getElementById('kolAddBtn');

const addKOLModal = document.getElementById('addKOLModal');
const cancelKOLBtn = document.getElementById('cancelKOLBtn');
const saveKOLBtn = document.getElementById('saveKOLBtn');
const kolNameInput = document.getElementById('kolName');
const kolNoteInput = document.getElementById('kolNote');
const kolLinkInput = document.getElementById('kolLink');
const kolAvatarInput = document.getElementById('kolAvatar');

const kolBatchAddBtn = document.getElementById('kolBatchAddBtn');
const batchAddKOLModal = document.getElementById('batchAddKOLModal');
const batchKOLInput = document.getElementById('batchKOLInput');
const cancelBatchKOLBtn = document.getElementById('cancelBatchKOLBtn');
const saveBatchKOLBtn = document.getElementById('saveBatchKOLBtn');

// Group/Strategy Elements
const strategyList = document.getElementById('strategyList');
const addGroupBtn = document.getElementById('addGroupBtn');
const strategySettingsModal = document.getElementById('strategySettingsModal');
const strategyIdInput = document.getElementById('strategyId');
const strategyNameInput = document.getElementById('strategyName');
const strategyPromptInput = document.getElementById('strategyPrompt');
const strategyMaxTweetAgeInput = document.getElementById('strategyMaxTweetAge');
const strategyAutoLikeCheckbox = document.getElementById('strategyAutoLike');
const strategyAutoRepostCheckbox = document.getElementById('strategyAutoRepost');
const strategyActiveStartInput = document.getElementById('strategyActiveStart');
const strategyActiveEndInput = document.getElementById('strategyActiveEnd');
const strategyAllDayCheckbox = document.getElementById('strategyAllDay');
const strategyColorInputs = document.getElementsByName('strategyColor');
const deleteStrategyBtn = document.getElementById('deleteStrategyBtn');
const cancelStrategyBtn = document.getElementById('cancelStrategyBtn');
const saveStrategyBtn = document.getElementById('saveStrategyBtn');
const kolGroupSelect = document.getElementById('kolGroup');

// State
let tweetStore = new Map();
let kolStore = new Map(); // Key: link, Value: { name, note, link, addedAt, groupId }
let groupStore = new Map(); // Key: id, Value: { id, name, config }
let dailyReportStore = new Map(); // Key: 'YYYY-MM-DD', Value: { posts: [], summary: null }
let sheetsTweetsStore = new Map(); // Key: tweet URL, Value: { tweet data from sheets }
let sheetsUrl = localStorage.getItem('sheetsUrl') || '';
let currentListSort = 'time';
let currentArchiveSort = 'time';
let lastDeletedTweetId = null;
let lastDeletedTweetStatus = null;
let undoTimeout = null;
let selectedReportDate = null; // Session-only date persistence (resets on plugin close)

// Helper function to safely save to localStorage with quota management
function safeSetRepliedUrls(urls) {
    try {
        localStorage.setItem('repliedTweetUrls', JSON.stringify(Array.from(urls)));
        return true;
    } catch (e) {
        if (e.name === 'QuotaExceededError') {
            console.warn('[Storage] Quota exceeded, cleaning old entries...');
            // Keep only the most recent 5000 URLs (roughly ~500KB)
            const urlsArray = Array.from(urls);
            const cleanedUrls = urlsArray.slice(-5000);
            try {
                localStorage.setItem('repliedTweetUrls', JSON.stringify(cleanedUrls));
                console.log(`[Storage] Cleaned repliedTweetUrls, kept ${cleanedUrls.length} most recent entries`);
                return true;
            } catch (e2) {
                console.error('[Storage] Failed to save even after cleanup:', e2);
                // Try keeping only 3000
                try {
                    const moreCleaned = urlsArray.slice(-3000);
                    localStorage.setItem('repliedTweetUrls', JSON.stringify(moreCleaned));
                    console.log(`[Storage] Further cleaned to ${moreCleaned.length} entries`);
                    return true;
                } catch (e3) {
                    console.error('[Storage] Failed completely, cannot save repliedTweetUrls');
                    return false;
                }
            }
        }
        console.error('[Storage] Error saving repliedTweetUrls:', e);
        return false;
    }
}

function safeSetRepliedThreadIds(ids) {
    try {
        localStorage.setItem('repliedThreadIds', JSON.stringify(Array.from(ids)));
        return true;
    } catch (e) {
        if (e.name === 'QuotaExceededError') {
            console.warn('[Storage] Quota exceeded for repliedThreadIds, cleaning old entries...');
            const idsArray = Array.from(ids);
            const cleanedIds = idsArray.slice(-3000);
            try {
                localStorage.setItem('repliedThreadIds', JSON.stringify(cleanedIds));
                console.log(`[Storage] Cleaned repliedThreadIds, kept ${cleanedIds.length} most recent entries`);
                return true;
            } catch (e2) {
                console.error('[Storage] Failed to save repliedThreadIds even after cleanup');
                return false;
            }
        }
        console.error('[Storage] Error saving repliedThreadIds:', e);
        return false;
    }
}

// 新用户/空白时的默认 System Prompt（已有自定义内容的用户不会被覆盖）
const DEFAULT_SYSTEM_PROMPT = '你是加密货币领域KOL，生成2-20字的推文评论，语言匹配推文主要语言（中英文为主，多语言以中文回复）不要用双引号,不要用@账户,不要用任何括号括起来,评论不要太官方,要有人性化。自动回复内容去除句号，逗号保留';

let aiConfig = {
    provider: localStorage.getItem('aiProvider') || 'deepseek',
    apiKey: localStorage.getItem('aiApiKey') || '',
    systemPrompt: (() => {
        const saved = localStorage.getItem('aiSystemPrompt');
        if (saved !== null && saved.trim() !== '') return saved;
        const i18n = chrome.i18n.getMessage('default_system_prompt');
        if (i18n) return i18n;
        return DEFAULT_SYSTEM_PROMPT;
    })(),
    autoLike: localStorage.getItem('aiAutoLike') === 'true',
    autoRepost: localStorage.getItem('aiAutoRepost') === 'true',
    replyDelayMin: localStorage.getItem('aiReplyDelayMin') || '3',
    replyDelayMax: localStorage.getItem('aiReplyDelayMax') || '7',
    likeDelayMin: localStorage.getItem('aiLikeDelayMin') || '1',
    likeDelayMax: localStorage.getItem('aiLikeDelayMax') || '5',
    postReplyWaitMin: localStorage.getItem('aiPostReplyWaitMin') || '5',
    postReplyWaitMax: localStorage.getItem('aiPostReplyWaitMax') || '15',
    pageLoadWaitMin: localStorage.getItem('aiPageLoadWaitMin') || '5',
    pageLoadWaitMax: localStorage.getItem('aiPageLoadWaitMax') || '8',
    kolMaxTweetsPerKol: parseInt(localStorage.getItem('aiKolMaxTweetsPerKol'), 10) || 5,
    autoRunEnabled: localStorage.getItem('aiAutoRunEnabled') === 'true',
    autoRunStart: localStorage.getItem('aiAutoRunStart') || '08:00',
    autoRunEnd: localStorage.getItem('aiAutoRunEnd') || '23:00',
    autoRunInterval: parseInt(localStorage.getItem('aiAutoRunInterval')) || 60,
    maxTweetAge: parseInt(localStorage.getItem('aiMaxTweetAge')) || 24,
    lastAutoRunTime: parseInt(localStorage.getItem('aiLastAutoRunTime') || '0'),
    apiUrl: localStorage.getItem('aiApiUrl') || '', // Custom Base URL
    activeHoursStart: localStorage.getItem('aiActiveHoursStart') || '08:00',
    activeHoursEnd: localStorage.getItem('aiActiveHoursEnd') || '23:00',
    allDay: localStorage.getItem('aiAllDay') === 'true'
};

let aiProcessState = {
    active: false,
    paused: false, // NEW: Track pause state
    currentPhase: 'idle', // NEW: 'idle', 'scanning', 'replying', 'snoozing'
    inCycle: false, // New flag for continuous cycle
    stoppedByUser: false, // Flag to prevent auto-restart after manual stop
    currentIndex: 0,
    list: []
};

// === Google Sheets Sync Configuration ===
let googleSheetsConfig = {
    scriptUrl: localStorage.getItem('googleScriptUrl') || '',
    lastSyncTime: parseInt(localStorage.getItem('googleLastSyncTime') || '0')
};

// Google Sheets DOM Elements
const googleScriptUrlInput = document.getElementById('googleScriptUrl');
const testSheetsBtn = document.getElementById('testSheetsBtn');
const sheetsUrlInput = document.getElementById('sheetsUrlInput');
const testSheetsUrlBtn = document.getElementById('testSheetsUrlBtn');
const loadSheetsDataBtn = document.getElementById('loadSheetsDataBtn');
const sheetsStatus = document.getElementById('sheetsStatus');
const syncToSheetsBtn = document.getElementById('syncToSheetsBtn');

// Initialize Google Sheets URL input
if (googleScriptUrlInput) {
    googleScriptUrlInput.value = googleSheetsConfig.scriptUrl;
    googleScriptUrlInput.addEventListener('change', (e) => {
        googleSheetsConfig.scriptUrl = e.target.value.trim();
        localStorage.setItem('googleScriptUrl', googleSheetsConfig.scriptUrl);
    });
}

// Show sync status message
function showSheetsStatus(message, type = 'loading') {
    if (!sheetsStatus) return;
    sheetsStatus.textContent = message;
    sheetsStatus.className = 'sync-status ' + type;
    sheetsStatus.style.display = 'block';

    // Auto-hide success/error after 5 seconds
    if (type !== 'loading') {
        setTimeout(() => {
            sheetsStatus.style.display = 'none';
        }, 5000);
    }
}

// Test connection to Google Apps Script
async function testGoogleSheetsConnection() {
    const url = googleSheetsConfig.scriptUrl;
    if (!url) {
        showNotification('请先输入 Apps Script URL', true);
        return;
    }

    showSheetsStatus('正在测试连接...', 'loading');

    try {
        const response = await fetch(url, {
            method: 'GET',
            mode: 'cors'
        });

        if (response.ok) {
            const data = await response.json();
            showSheetsStatus('✓ 连接成功！' + (data.message || ''), 'success');
        } else {
            showSheetsStatus('✗ 连接失败: HTTP ' + response.status, 'error');
        }
    } catch (error) {
        console.error('Sheets connection test failed:', error);
        showSheetsStatus('✗ 连接错误: ' + error.message, 'error');
    }
}

// Sync tweets to Google Sheets
// Sync tweets to Google Sheets (single sheet with status column)
// tweetsArray: optional, if provided, sync these tweets instead of tweetStore
async function syncToGoogleSheets(tweetsArray = null) {
    const url = googleSheetsConfig.scriptUrl;
    if (!url) {
        showNotification('请先输入 Apps Script URL', true);
        return false;
    }

    // Get tweets to sync
    let tweetsToSync;
    if (tweetsArray) {
        tweetsToSync = tweetsArray;
    } else {
        // Default: archived tweets + list tweets
        tweetsToSync = Array.from(tweetStore.values()).filter(t =>
            t.status === 'archive' || t.status === 'list'
        );
    }

    if (tweetsToSync.length === 0) {
        showNotification('没有可同步的推文', true);
        return false;
    }

    showSheetsStatus(`正在同步 ${tweetsToSync.length} 条推文...`, 'loading');

    try {
        // Prepare data for Google Sheets
        const payload = tweetsToSync.map(tweet => ({
            id: tweet.id,
            username: tweet.username,
            content: tweet.content || '',
            url: tweet.url,
            timestamp: tweet.timestamp,
            likes: tweet.likes || 0,
            replies: tweet.replies || 0,
            retweets: tweet.retweets || 0,
            views: tweet.views || 0,
            status: tweet.status || 'scanner',
            groupId: tweet.groupId || 'default',
            // Interaction data
            liked: tweet.interactions?.like || false,
            retweeted: tweet.interactions?.retweet || false,
            replyText: tweet.replyText || '',
            syncedAt: Date.now()
        }));

        const response = await fetch(url, {
            method: 'POST',
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ tweets: payload })
        });

        if (response.ok) {
            const result = await response.json();
            googleSheetsConfig.lastSyncTime = Date.now();
            localStorage.setItem('googleLastSyncTime', googleSheetsConfig.lastSyncTime.toString());
            showSheetsStatus(`✓ 同步成功！${result.added || 0} 条新增，${result.updated || 0} 条更新`, 'success');
            return true;
        } else {
            const errorText = await response.text();
            showSheetsStatus('✗ 同步失败: ' + errorText, 'error');
            return false;
        }
    } catch (error) {
        console.error('Sync to Google Sheets failed:', error);
        showSheetsStatus('✗ 同步错误: ' + error.message, 'error');
        return false;
    }
}

// Wire up Google Sheets buttons
if (testSheetsBtn) {
    testSheetsBtn.addEventListener('click', testGoogleSheetsConnection);
}

if (syncToSheetsBtn) {
    syncToSheetsBtn.addEventListener('click', syncToGoogleSheets);
}

// === Google Sheets Data Source (for AI Reply) ===
// 默认表格：当未配置、加载失败或加载后无数据时使用
const DEFAULT_SHEETS_URL = 'https://docs.google.com/spreadsheets/d/10KSynVq49eWZO5gfCppuVCfrpSeSV8FR6R1qrREDPJA/edit?pli=1&gid=1124555770#gid=1124555770';

function applyDefaultSheetsUrl() {
    sheetsUrl = DEFAULT_SHEETS_URL;
    if (sheetsUrlInput) sheetsUrlInput.value = sheetsUrl;
    try { localStorage.setItem('sheetsUrl', sheetsUrl); } catch (e) {}
}

// Convert Google Sheets URL to CSV export URL
function convertSheetsUrlToCSV(sheetUrl) {
    const spreadsheetIdMatch = sheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (!spreadsheetIdMatch) {
        throw new Error('无法从URL中提取表格ID');
    }
    const spreadsheetId = spreadsheetIdMatch[1];
    
    // Extract gid (sheet ID) from URL if present
    let gid = '0';
    const gidMatch = sheetUrl.match(/[#&]gid=(\d+)/);
    if (gidMatch) {
        gid = gidMatch[1];
    }
    
    // Try multiple CSV export URL formats
    return [
        `https://docs.google.com/spreadsheets/d/${spreadsheetId}/export?format=csv&gid=${gid}`,
        `https://docs.google.com/spreadsheets/d/${spreadsheetId}/gviz/tq?tqx=out:csv&gid=${gid}`,
        `https://docs.google.com/spreadsheets/d/${spreadsheetId}/export?format=csv`
    ];
}

// Parse CSV text to array of objects
function parseCSV(csvText) {
    const lines = csvText.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];
    
    // Parse header
    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    
    // Parse data rows
    const data = [];
    for (let i = 1; i < lines.length; i++) {
        const line = lines[i];
        if (!line.trim()) continue;
        
        // Simple CSV parsing (handles quoted fields)
        const values = [];
        let current = '';
        let inQuotes = false;
        
        for (let j = 0; j < line.length; j++) {
            const char = line[j];
            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                values.push(current.trim());
                current = '';
            } else {
                current += char;
            }
        }
        values.push(current.trim());
        
        if (values.length === headers.length) {
            const row = {};
            headers.forEach((header, index) => {
                row[header] = values[index] || '';
            });
            data.push(row);
        }
    }
    
    return data;
}

// Load tweets from Google Sheets
async function loadTweetsFromSheets() {
    // 未配置时使用默认表格
    if (!sheetsUrl || !String(sheetsUrl).trim()) {
        applyDefaultSheetsUrl();
    }

    if (sheetsStatus) {
        sheetsStatus.style.display = 'block';
        sheetsStatus.textContent = '正在加载数据...';
        sheetsStatus.style.color = 'var(--text-color)';
    }
    
    try {
        const csvUrls = convertSheetsUrlToCSV(sheetsUrl);
        let csvText = '';
        let lastError = null;
        
        for (let i = 0; i < csvUrls.length; i++) {
            const csvUrl = csvUrls[i];
            try {
                const response = await fetch(csvUrl, {
                    method: 'GET',
                    mode: 'cors',
                    credentials: 'omit'
                });
                
                if (!response.ok) {
                    if (response.status === 403 || response.status === 0) {
                        throw new Error('无法访问表格。请确保表格已设置为"任何知道链接的人都可以查看"');
                    }
                    if (response.status === 400 && i < csvUrls.length - 1) {
                        continue;
                    }
                    throw new Error(`无法访问表格: ${response.status} ${response.statusText}`);
                }
                
                csvText = await response.text();
                break;
            } catch (fetchError) {
                lastError = fetchError;
                if (i === csvUrls.length - 1) {
                    throw fetchError;
                }
            }
        }
        
        if (!csvText) {
            throw new Error('无法获取表格数据');
        }
        
        const tweets = parseCSV(csvText);
        console.log('Loaded tweets from sheets:', tweets.length);
        
        // Clear and populate sheetsTweetsStore
        sheetsTweetsStore.clear();
        tweets.forEach(tweet => {
            const url = tweet['推文链接'] || tweet['Tweet Link'] || tweet['url'] || '';
            if (url) {
                sheetsTweetsStore.set(url, tweet);
            }
        });
        
        // 加载后无数据且当前不是默认表格时，切换为默认表格并重新加载
        if (sheetsTweetsStore.size === 0 && sheetsUrl !== DEFAULT_SHEETS_URL) {
            applyDefaultSheetsUrl();
            if (sheetsStatus) {
                sheetsStatus.textContent = '当前表格无数据，已切换为默认表格并重新加载...';
                sheetsStatus.style.color = 'var(--text-color)';
            }
            showNotification('当前表格无数据，已切换为默认表格并重新加载', false);
            return loadTweetsFromSheets();
        }
        
        if (sheetsStatus) {
            sheetsStatus.textContent = `✓ 成功加载 ${tweets.length} 条推文`;
            sheetsStatus.style.color = 'var(--success-color, #4CAF50)';
        }
        
        showNotification(`成功加载 ${tweets.length} 条推文`, false);
        
    } catch (error) {
        console.error('Error loading tweets from sheets:', error);
        // 加载失败且当前不是默认表格时，切换为默认表格并重新加载
        if (sheetsUrl !== DEFAULT_SHEETS_URL) {
            applyDefaultSheetsUrl();
            if (sheetsStatus) {
                sheetsStatus.textContent = '加载失败，已切换为默认表格并重新加载...';
                sheetsStatus.style.color = 'var(--text-color)';
            }
            showNotification('加载失败，已切换为默认表格并重新加载', false);
            return loadTweetsFromSheets();
        }
        if (sheetsStatus) {
            sheetsStatus.textContent = `✗ 加载失败: ${error.message}`;
            sheetsStatus.style.color = 'var(--error-color, #f4212e)';
        }
        showNotification('加载失败: ' + error.message, true);
    }
}

// Test Google Sheets URL connection
async function testSheetsUrlConnection() {
    if (!sheetsUrlInput) return;
    
    const url = sheetsUrlInput.value.trim();
    if (!url) {
        showNotification('请输入表格URL', true);
        return;
    }
    
    if (sheetsStatus) {
        sheetsStatus.style.display = 'block';
        sheetsStatus.textContent = '正在测试连接...';
        sheetsStatus.style.color = 'var(--text-color)';
    }
    
    try {
        const csvUrls = convertSheetsUrlToCSV(url);
        let success = false;
        
        for (const csvUrl of csvUrls) {
            try {
                const response = await fetch(csvUrl, {
                    method: 'HEAD',
                    mode: 'cors',
                    credentials: 'omit'
                });
                
                if (response.ok) {
                    success = true;
                    break;
                }
            } catch (e) {
                continue;
            }
        }
        
        if (success) {
            sheetsUrl = url;
            localStorage.setItem('sheetsUrl', sheetsUrl);
            if (sheetsStatus) {
                sheetsStatus.textContent = '✓ 连接成功';
                sheetsStatus.style.color = 'var(--success-color, #4CAF50)';
            }
            showNotification('连接成功', false);
        } else {
            throw new Error('无法连接到表格');
        }
    } catch (error) {
        if (sheetsStatus) {
            sheetsStatus.textContent = `✗ 连接失败: ${error.message}`;
            sheetsStatus.style.color = 'var(--error-color, #f4212e)';
        }
        showNotification('连接失败: ' + error.message, true);
    }
}

// Wire up Google Sheets data source buttons
// === Scan and Reply (Reply commenters' first non-pinned tweet) ===
const scanAndReplyBtn = document.getElementById('scanAndReplyBtn');
const pauseScanAndReplyBtn = document.getElementById('pauseScanAndReplyBtn');
const stopScanAndReplyBtn = document.getElementById('stopScanAndReplyBtn');
const scanAndReplyStatus = document.getElementById('scanAndReplyStatus');

// 扫描回复状态
let scanReplyState = {
    active: false,
    paused: false
};

const SCAN_REPLY_REPLIED_URLS_KEY = 'scanReplyRepliedUrls';
const SCAN_REPLY_REPLIED_URLS_MAX = 500;

// 扫描当前页面并依次回复评论者主页第一条非置顶推文（带查重）
async function scanCurrentPageAndReply() {
    if (!scanAndReplyBtn) return;
    
    // 如果已经在运行，不重复启动
    if (scanAndReplyBtn.classList.contains('active-state')) {
        return;
    }
    
    // Check if AI is configured
    if (!aiConfig.apiKey || !aiConfig.provider) {
        showNotification('请先配置AI设置', true);
        return;
    }
    
    scanAndReplyBtn.classList.add('active-state');
    scanAndReplyBtn.textContent = '扫描中...';
    
    // 显示暂停、停止按钮
    if (pauseScanAndReplyBtn) {
        pauseScanAndReplyBtn.style.display = 'inline-block';
        pauseScanAndReplyBtn.textContent = '暂停';
    }
    if (stopScanAndReplyBtn) {
        stopScanAndReplyBtn.style.display = 'inline-block';
    }
    
    if (scanAndReplyStatus) {
        scanAndReplyStatus.style.display = 'block';
        scanAndReplyStatus.textContent = '正在扫描当前页面...';
        scanAndReplyStatus.style.color = 'var(--text-secondary)';
    }
    showGlobalProgress({ type: 'scanAndReply', current: 0, total: 1, message: '正在扫描当前页面...' });
    
    // 加载已回复过的推文 URL（查重，避免重复回复）
    let repliedUrls = [];
    try {
        const stored = await chrome.storage.local.get(SCAN_REPLY_REPLIED_URLS_KEY);
        if (stored[SCAN_REPLY_REPLIED_URLS_KEY] && Array.isArray(stored[SCAN_REPLY_REPLIED_URLS_KEY])) {
            repliedUrls = stored[SCAN_REPLY_REPLIED_URLS_KEY];
        }
    } catch (e) {
        console.warn('Load replied URLs failed:', e);
    }
    
    // 状态管理
    scanReplyState.active = true;
    scanReplyState.paused = false;
    const state = {
        currentTweetIndex: 0,
        currentCommenterIndex: 0,
        tweets: [],
        commenters: [],
        processedCommenters: new Set(),
        repliedTweetUrls: new Set(repliedUrls)
    };
    
    try {
        // Get current tab
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tabs[0]) {
            throw new Error('无法获取当前标签页');
        }
        
        const tabId = tabs[0].id;
        const url = tabs[0].url;
        
        // Check if on X/Twitter
        if (!url.includes('twitter.com') && !url.includes('x.com')) {
            throw new Error('请在X/Twitter页面使用此功能');
        }
        
        // 提取当前页面的推文
        let extractResponse;
        let retryCount = 0;
        const maxRetries = 2;
        
        while (retryCount <= maxRetries) {
            try {
                extractResponse = await chrome.tabs.sendMessage(tabId, { 
                    action: 'EXTRACT_TWEETS_FOR_REPLY' 
                });
                
                if (extractResponse && extractResponse.tweets !== undefined) {
                    break;
                }
            } catch (msgError) {
                if (retryCount < maxRetries) {
                    try {
                        await chrome.scripting.executeScript({
                            target: { tabId: tabId },
                            files: ['src/content.js']
                        });
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    } catch (injectError) {
                        console.warn('Failed to inject content script:', injectError);
                    }
                } else {
                    throw new Error('无法连接到页面脚本，请刷新页面后重试');
                }
            }
            retryCount++;
        }
        
        if (!extractResponse || !extractResponse.tweets) {
            throw new Error('无法提取推文，请确保在推文列表页面');
        }
        
        state.tweets = extractResponse.tweets;
        
        if (scanAndReplyStatus) {
            scanAndReplyStatus.textContent = `找到 ${state.tweets.length} 条推文，开始处理...`;
        }
        showGlobalProgress({ type: 'scanAndReply', current: 0, total: state.tweets.length, message: `找到 ${state.tweets.length} 条推文，开始处理...` });
        
        if (state.tweets.length === 0) {
            if (scanAndReplyStatus) {
                scanAndReplyStatus.textContent = '当前页面没有推文';
                scanAndReplyStatus.style.color = 'var(--meta-color)';
            }
            stopScanAndReply();
            return;
        }
        
        // 处理每条推文
        for (let i = 0; i < state.tweets.length; i++) {
            if (!scanReplyState.active) break;
            while (scanReplyState.paused && scanReplyState.active) {
                await new Promise(r => setTimeout(r, 500));
            }
            if (!scanReplyState.active) break;
            
            const tweet = state.tweets[i];
            state.currentTweetIndex = i;
            
            if (scanAndReplyStatus) {
                scanAndReplyStatus.textContent = `处理推文 ${i + 1}/${state.tweets.length}: ${tweet.username}`;
            }
            showGlobalProgress({ type: 'scanAndReply', current: i + 1, total: state.tweets.length, message: `处理推文 ${i + 1}/${state.tweets.length}: ${tweet.username}`, subLabel: '当前推文', subCurrent: i + 1, subTotal: state.tweets.length });
            
            // 1. 导航到推文详情页
            await new Promise(resolve => {
                chrome.tabs.update(tabId, { url: tweet.url });
                resolve();
            });
            
            // 等待页面加载（暂停时不 resolve，恢复后再继续）
            await new Promise(resolve => {
                const check = setInterval(() => {
                    if (!scanReplyState.active) { clearInterval(check); resolve(); return; }
                    if (scanReplyState.paused) return;
                    chrome.tabs.get(tabId, (tab) => {
                        if (tab && tab.status === 'complete') {
                            clearInterval(check);
                            setTimeout(resolve, 3000);
                        }
                    });
                }, 1000);
            });
            while (scanReplyState.paused && scanReplyState.active) { await new Promise(r => setTimeout(r, 500)); }
            if (!scanReplyState.active) break;
            
            // 2. 获取评论者列表
            let commentersResponse;
            try {
                commentersResponse = await chrome.tabs.sendMessage(tabId, {
                    action: 'GET_TWEET_COMMENTERS'
                });
            } catch (e) {
                console.warn(`Failed to get commenters for tweet ${tweet.id}:`, e);
                continue;
            }
            
            if (!commentersResponse || !commentersResponse.commenters) {
                console.log(`No commenters found for tweet ${tweet.id}`);
                continue;
            }
            
            const commenters = commentersResponse.commenters.filter(c => 
                !state.processedCommenters.has(c.toLowerCase())
            );
            
            if (commenters.length === 0) {
                console.log(`All commenters already processed for tweet ${tweet.id}`);
                continue;
            }
            
            // 3. 依次访问每个评论者的主页并回复第一条推文
            for (let j = 0; j < commenters.length; j++) {
                if (!scanReplyState.active) break;
                while (scanReplyState.paused && scanReplyState.active) {
                    await new Promise(r => setTimeout(r, 500));
                }
                if (!scanReplyState.active) break;
                
                const commenter = commenters[j];
                state.currentCommenterIndex = j;
                
                if (scanAndReplyStatus) {
                    scanAndReplyStatus.textContent = `处理评论者 ${j + 1}/${commenters.length}: @${commenter}`;
                }
                showGlobalProgress({ type: 'scanAndReply', current: i + 1, total: state.tweets.length, message: `处理评论者 ${j + 1}/${commenters.length}: @${commenter}`, subLabel: '当前推文评论者', subCurrent: j + 1, subTotal: commenters.length });
                
                // 标记为已处理
                state.processedCommenters.add(commenter.toLowerCase());
                
                // 导航到评论者主页
                const profileUrl = `https://x.com/${commenter}`;
                await new Promise(resolve => {
                    chrome.tabs.update(tabId, { url: profileUrl });
                    resolve();
                });
                
                // 等待页面加载（暂停时不 resolve）
                await new Promise(resolve => {
                    const check = setInterval(() => {
                        if (!scanReplyState.active) { clearInterval(check); resolve(); return; }
                        if (scanReplyState.paused) return;
                        chrome.tabs.get(tabId, (tab) => {
                            if (tab && tab.status === 'complete') {
                                clearInterval(check);
                                setTimeout(resolve, 3000);
                            }
                        });
                    }, 1000);
                });
                while (scanReplyState.paused && scanReplyState.active) { await new Promise(r => setTimeout(r, 500)); }
                if (!scanReplyState.active) break;
                
                // 获取第一条非置顶推文
                let firstTweetResponse;
                try {
                    firstTweetResponse = await chrome.tabs.sendMessage(tabId, {
                        action: 'GET_FIRST_NON_PINNED_TWEET'
                    });
                } catch (e) {
                    console.warn(`Failed to get first tweet for @${commenter}:`, e);
                    continue;
                }
                
                if (!firstTweetResponse || !firstTweetResponse.tweet) {
                    console.log(`No non-pinned tweet found for @${commenter}`);
                    continue;
                }
                
                const firstTweet = firstTweetResponse.tweet;
                
                // 查重：已回复过该推文则跳过
                if (state.repliedTweetUrls.has(firstTweet.url)) {
                    if (scanAndReplyStatus) {
                        scanAndReplyStatus.textContent = `跳过已回复: @${commenter}`;
                    }
                    continue;
                }
                
                // 4. 导航到推文并回复
                await new Promise(resolve => {
                    chrome.tabs.update(tabId, { url: firstTweet.url });
                    resolve();
                });
                
                // 等待页面加载
                await new Promise(resolve => {
                    const check = setInterval(() => {
                        chrome.tabs.get(tabId, (tab) => {
                            if (tab && tab.status === 'complete') {
                                clearInterval(check);
                                setTimeout(resolve, 3000);
                            }
                        });
                    }, 1000);
                });
                
                // 查重：评论页检查当前用户是否已手动回复过（无本地记录时也跳过）
                let alreadyRepliedByUser = false;
                try {
                    const scanResp = await chrome.tabs.sendMessage(tabId, { action: 'SCAN_REPLIES' });
                    if (scanResp && scanResp.hasReplied === true) {
                        alreadyRepliedByUser = true;
                    }
                } catch (e) {
                    console.warn('SCAN_REPLIES check failed:', e);
                }
                if (alreadyRepliedByUser) {
                    state.repliedTweetUrls.add(firstTweet.url);
                    repliedUrls = Array.from(state.repliedTweetUrls);
                    if (repliedUrls.length > SCAN_REPLY_REPLIED_URLS_MAX) {
                        repliedUrls = repliedUrls.slice(-SCAN_REPLY_REPLIED_URLS_MAX);
                    }
                    try {
                        await chrome.storage.local.set({ [SCAN_REPLY_REPLIED_URLS_KEY]: repliedUrls });
                    } catch (e) {
                        console.warn('Save replied URLs failed:', e);
                    }
                    if (scanAndReplyStatus) {
                        scanAndReplyStatus.textContent = `跳过(页面已回复): @${commenter}`;
                    }
                    continue;
                }
                
                // 生成回复并发送
                try {
                    const response = await sendMessageToActiveTab({ action: 'SCRAPE_TWEET_CONTENT' });
                    if (response && response.isOwnTweet) {
                        if (scanAndReplyStatus) scanAndReplyStatus.textContent = `跳过 - 自己的推文: @${commenter}`;
                        continue;
                    }
                    if (response && response.content) {
                        const systemPrompt = aiConfig.systemPrompt || DEFAULT_SYSTEM_PROMPT;
                        const reply = await callAI(aiConfig.provider, aiConfig.apiKey, systemPrompt, response.content);
                        
                        if (reply) {
                            await sendMessageToActiveTab({
                                action: 'PASTE_AND_REPLY',
                                text: reply,
                                doLike: aiConfig.autoLike || false,
                                doRepost: aiConfig.autoRepost || false
                            });
                            
                            // 记录已回复，避免重复
                            state.repliedTweetUrls.add(firstTweet.url);
                            repliedUrls = Array.from(state.repliedTweetUrls);
                            if (repliedUrls.length > SCAN_REPLY_REPLIED_URLS_MAX) {
                                repliedUrls = repliedUrls.slice(-SCAN_REPLY_REPLIED_URLS_MAX);
                            }
                            try {
                                await chrome.storage.local.set({ [SCAN_REPLY_REPLIED_URLS_KEY]: repliedUrls });
                            } catch (e) {
                                console.warn('Save replied URLs failed:', e);
                            }
                            
                            // 等待一下再处理下一个
                            await new Promise(r => setTimeout(r, 3000 + Math.random() * 2000));
                        }
                    }
                } catch (e) {
                    console.error(`Failed to reply to @${commenter}'s tweet:`, e);
                }
            }
        }
        
        if (scanAndReplyStatus) {
            scanAndReplyStatus.textContent = '处理完成';
            scanAndReplyStatus.style.color = 'var(--success-color)';
        }
        
        stopScanAndReply();
        
    } catch (error) {
        console.error('Scan and reply error:', error);
        showNotification('扫描失败: ' + error.message, true);
        stopScanAndReply();
        if (scanAndReplyStatus) {
            scanAndReplyStatus.textContent = '扫描失败: ' + error.message;
            scanAndReplyStatus.style.color = 'var(--danger-color)';
        }
    }
}

// 停止扫描和回复
function stopScanAndReply() {
    scanReplyState.active = false;
    scanReplyState.paused = false;
    
    scanAndReplyBtn.classList.remove('active-state');
    scanAndReplyBtn.textContent = '回复评论者首条推文';
    
    // 隐藏暂停、停止按钮
    if (pauseScanAndReplyBtn) {
        pauseScanAndReplyBtn.style.display = 'none';
        pauseScanAndReplyBtn.textContent = '暂停';
    }
    if (stopScanAndReplyBtn) {
        stopScanAndReplyBtn.style.display = 'none';
    }
    
    // 停止AI回复流程
    if (aiProcessState.active) {
        aiProcessState.active = false;
        aiProcessState.paused = false;
        aiProcessState.stoppedByUser = true;
    }
    
    if (scanAndReplyStatus) {
        scanAndReplyStatus.style.display = 'none';
    }
    hideGlobalProgress();
}

// 暂停扫描回复
function pauseScanAndReply() {
    if (!scanReplyState.active || scanReplyState.paused) return;
    scanReplyState.paused = true;
    if (pauseScanAndReplyBtn) pauseScanAndReplyBtn.textContent = '恢复';
    if (scanAndReplyStatus) {
        scanAndReplyStatus.textContent = (scanAndReplyStatus.textContent || '') + ' [已暂停]';
        scanAndReplyStatus.style.color = 'var(--warning-color, #ff9800)';
    }
}

// 恢复扫描回复
function resumeScanAndReply() {
    if (!scanReplyState.active || !scanReplyState.paused) return;
    scanReplyState.paused = false;
    if (pauseScanAndReplyBtn) pauseScanAndReplyBtn.textContent = '暂停';
    if (scanAndReplyStatus) {
        const t = scanAndReplyStatus.textContent || '';
        scanAndReplyStatus.textContent = t.replace(/\s*\[已暂停\]\s*$/, '');
        scanAndReplyStatus.style.color = 'var(--text-secondary)';
    }
}

if (scanAndReplyBtn) {
    scanAndReplyBtn.addEventListener('click', scanCurrentPageAndReply);
}

if (pauseScanAndReplyBtn) {
    pauseScanAndReplyBtn.addEventListener('click', () => {
        if (scanReplyState.active && scanReplyState.paused) {
            resumeScanAndReply();
        } else if (scanReplyState.active && !scanReplyState.paused) {
            pauseScanAndReply();
        }
    });
}

if (stopScanAndReplyBtn) {
    stopScanAndReplyBtn.addEventListener('click', stopScanAndReply);
}

if (sheetsUrlInput) {
    sheetsUrlInput.value = sheetsUrl;
    sheetsUrlInput.addEventListener('input', (e) => {
        sheetsUrl = e.target.value.trim();
        localStorage.setItem('sheetsUrl', sheetsUrl);
    });
}

if (testSheetsUrlBtn) {
    testSheetsUrlBtn.addEventListener('click', testSheetsUrlConnection);
}

if (loadSheetsDataBtn) {
    loadSheetsDataBtn.addEventListener('click', loadTweetsFromSheets);
}

// === Authorization Management ===
const authSheetUrlInput = document.getElementById('authSheetUrl');
const checkAuthBtn = document.getElementById('checkAuthBtn');
const authStatus = document.getElementById('authStatus');
const authIndicator = document.getElementById('authIndicator');
const authText = document.getElementById('authText');
const authStatusDetail = document.getElementById('authStatusDetail');

// 授权检查遮罩层元素
const authCheckOverlay = document.getElementById('authCheckOverlay');
const authCheckStatus = document.getElementById('authCheckStatus');
const authCheckError = document.getElementById('authCheckError');
const authCheckRefreshBtn = document.getElementById('authCheckRefreshBtn');
const authCheckRefreshHint = document.getElementById('authCheckRefreshHint');
const mainAppContainer = document.getElementById('mainAppContainer');

// 默认授权表格URL（硬编码）
const DEFAULT_AUTH_SHEET_URL = 'https://docs.google.com/spreadsheets/d/1wb-XzulxztyYOoGigl16L25aX7AEFa6V3O7eeF2Vn7M/edit?gid=0#gid=0';

// Authorization state
let authState = {
    valid: false,
    userId: null,
    licenseType: null,
    endDate: null,
    reason: null
};

// Load auth sheet URL from localStorage
if (authSheetUrlInput) {
    const savedAuthUrl = localStorage.getItem('authSheetUrl');
    if (savedAuthUrl) {
        authSheetUrlInput.value = savedAuthUrl;
    }
    authSheetUrlInput.addEventListener('change', (e) => {
        localStorage.setItem('authSheetUrl', e.target.value.trim());
    });
}

// Parse date string (支持多种格式: "2027-1-1", "1-1", "2027-01-01" 等)
function parseDate(dateStr) {
    if (!dateStr || !dateStr.trim()) return null;
    
    const str = dateStr.trim();
    const parts = str.split(/[-\/]/).map(p => parseInt(p));
    
    if (parts.length < 2) return null;
    
    let year, month, day;
    
    if (parts.length === 2) {
        // 格式: "1-1" 或 "01-01" - 假设是当前年份
        year = new Date().getFullYear();
        month = parts[0];
        day = parts[1];
    } else if (parts.length === 3) {
        // 格式: "2027-1-1" 或 "2027-01-01"
        year = parts[0];
        month = parts[1];
        day = parts[2];
    } else {
        return null;
    }
    
    // 如果年份是2位数，假设是20xx
    if (year < 100) {
        year = 2000 + year;
    }
    
    const date = new Date(year, month - 1, day);
    if (isNaN(date.getTime())) return null;
    
    return date;
}

// Load authorization data from Google Sheets
async function loadAuthDataFromSheet(sheetUrl) {
    if (!sheetUrl) {
        throw new Error('未配置授权表格URL');
    }
    
    // Convert to CSV export URL
    const match = sheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (!match) {
        throw new Error('无法从URL中提取表格ID');
    }
    
    const sheetId = match[1];
    const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv&gid=0`;
    
    try {
        const response = await fetch(csvUrl);
        if (!response.ok) {
            if (response.status === 403) {
                throw new Error('无法访问表格。请确保表格已设置为"任何知道链接的人都可以查看"');
            }
            throw new Error(`无法访问表格: ${response.status} ${response.statusText}`);
        }
        
        const csvText = await response.text();
        const lines = csvText.split('\n').filter(line => line.trim());
        
        if (lines.length < 2) {
            throw new Error('表格数据为空或格式不正确');
        }
        
        // Parse CSV (格式: ID | 起始日期 | 结束日期)
        // 跳过表头（第一行）
        const authData = [];
        
        for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(',').map(v => v.trim());
            if (values.length >= 3 && values[0]) {
                // 解析日期
                const startDate = parseDate(values[1]);
                const endDate = parseDate(values[2]);
                
                authData.push({
                    userId: values[0]?.replace('@', '').toLowerCase() || '',
                    startDate: values[1] || '',
                    endDate: values[2] || '',
                    startDateParsed: startDate,
                    endDateParsed: endDate
                });
            }
        }
        
        return authData;
    } catch (error) {
        console.error('Load auth data error:', error);
        throw error;
    }
}

// Get current user username
async function getCurrentUserUsername() {
    try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tabs[0]) return null;
        
        const tabId = tabs[0].id;
        const url = tabs[0].url;
        
        // Check if on X/Twitter
        if (!url.includes('twitter.com') && !url.includes('x.com')) {
            return null;
        }
        
        const response = await chrome.tabs.sendMessage(tabId, { 
            action: 'GET_CURRENT_USERNAME' 
        });
        
        return response?.username || null;
    } catch (error) {
        console.error('Get current username error:', error);
        return null;
    }
}

// 显示授权检查失败页面（遮罩层内），并提示请联系管理员开通权限，显示刷新按钮
function showAuthCheckError(message) {
    if (authCheckStatus) authCheckStatus.style.display = 'none';
    if (authCheckError) {
        const msgEl = document.getElementById('authCheckErrorMsg');
        if (msgEl) msgEl.textContent = message;
        authCheckError.style.display = 'block';
    }
    if (authCheckRefreshHint) authCheckRefreshHint.style.display = 'block';
    if (authCheckRefreshBtn) authCheckRefreshBtn.style.display = 'inline-block';
}

// 授权通过：隐藏遮罩层，显示插件主页
function showMainApp() {
    if (authCheckOverlay) authCheckOverlay.style.display = 'none';
    if (mainAppContainer) mainAppContainer.style.display = 'block';
}

// Check user authorization
async function checkUserAuthorization(showOverlay = false) {
    // 打开插件时用默认表格URL或本地保存的URL
    const sheetUrl = (showOverlay ? (localStorage.getItem('authSheetUrl') || DEFAULT_AUTH_SHEET_URL) : null)
        || (authSheetUrlInput && authSheetUrlInput.value.trim())
        || DEFAULT_AUTH_SHEET_URL;
    
    if (showOverlay && authCheckStatus) {
        authCheckStatus.textContent = '正在获取用户ID...';
        authCheckStatus.style.display = 'block';
        if (authCheckError) authCheckError.style.display = 'none';
        if (authCheckRefreshHint) authCheckRefreshHint.style.display = 'none';
        if (authCheckRefreshBtn) authCheckRefreshBtn.style.display = 'none';
    }
    
    try {
        // Get current user
        const currentUser = await getCurrentUserUsername();
        if (!currentUser) {
            authState = {
                valid: false,
                reason: '无法获取用户ID，请确保已登录X/Twitter并在X/Twitter页面'
            };
            if (showOverlay) {
                showAuthCheckError('无法获取用户ID，请确保已登录X/Twitter并在X/Twitter页面');
            } else {
                updateAuthStatusUI();
            }
            return authState;
        }
        
        if (showOverlay && authCheckStatus) {
            authCheckStatus.textContent = `正在检查授权状态 (@${currentUser})...`;
        }
        
        // Load auth data
        const authData = await loadAuthDataFromSheet(sheetUrl);
        
        // Find user in auth data
        const userAuth = authData.find(u => 
            u.userId.toLowerCase() === currentUser.toLowerCase()
        );
        
        if (!userAuth) {
            authState = {
                valid: false,
                userId: currentUser,
                reason: '用户未授权'
            };
            if (showOverlay) {
                showAuthCheckError('您的账号未在授权列表中');
            } else {
                updateAuthStatusUI();
            }
            return authState;
        }
        
        // Check date range - 使用解析后的日期
        const now = new Date();
        const startDate = userAuth.startDateParsed || parseDate(userAuth.startDate);
        const endDate = userAuth.endDateParsed || parseDate(userAuth.endDate);
        
        if (!startDate || !endDate || isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
            authState = {
                valid: false,
                userId: currentUser,
                reason: '授权日期格式错误'
            };
            if (showOverlay) {
                showAuthCheckError('授权日期格式错误，请联系管理员');
            } else {
                updateAuthStatusUI();
            }
            return authState;
        }
        
        if (now < startDate) {
            authState = {
                valid: false,
                userId: currentUser,
                reason: `授权未开始 (开始日期: ${userAuth.startDate})`
            };
            if (showOverlay) {
                showAuthCheckError(`授权未开始，开始日期: ${userAuth.startDate}`);
            } else {
                updateAuthStatusUI();
            }
            return authState;
        }
        
        if (now > endDate) {
            authState = {
                valid: false,
                userId: currentUser,
                reason: `授权已过期 (结束日期: ${userAuth.endDate})`
            };
            if (showOverlay) {
                showAuthCheckError(`授权已过期，结束日期: ${userAuth.endDate}`);
            } else {
                updateAuthStatusUI();
            }
            return authState;
        }
        
        // Valid authorization - 当前日期在结束日期之内
        const daysRemaining = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
        authState = {
            valid: true,
            userId: currentUser,
            licenseType: '授权',
            endDate: userAuth.endDate,
            daysRemaining: daysRemaining
        };
        
        if (showOverlay) {
            showMainApp();
        }
        updateAuthStatusUI();
        return authState;
        
    } catch (error) {
        console.error('Check authorization error:', error);
        authState = {
            valid: false,
            reason: '授权检查失败: ' + error.message
        };
        if (showOverlay) {
            showAuthCheckError('授权检查失败: ' + error.message);
        } else {
            updateAuthStatusUI();
        }
        return authState;
    }
}

// Update authorization status UI
function updateAuthStatusUI() {
    if (!authStatus || !authIndicator || !authText) return;
    
    authStatus.style.display = 'flex';
    
    if (authState.valid) {
        authIndicator.style.background = 'var(--success-color)';
        authText.textContent = `授权有效 (剩余 ${authState.daysRemaining} 天)`;
        authText.style.color = 'var(--success-color)';
    } else {
        authIndicator.style.background = 'var(--danger-color)';
        authText.textContent = authState.reason || '授权无效';
        authText.style.color = 'var(--danger-color)';
    }
    
    // Update detail status
    if (authStatusDetail) {
        if (authState.valid) {
            authStatusDetail.textContent = `用户: @${authState.userId} | 有效期至: ${authState.endDate}`;
            authStatusDetail.className = 'sync-status success';
        } else {
            authStatusDetail.textContent = authState.reason || '授权检查失败';
            authStatusDetail.className = 'sync-status error';
        }
        authStatusDetail.style.display = 'block';
    }
}

// Check authorization on button click
if (checkAuthBtn) {
    checkAuthBtn.addEventListener('click', async () => {
        checkAuthBtn.disabled = true;
        checkAuthBtn.textContent = '检查中...';
        
        if (authStatusDetail) {
            authStatusDetail.textContent = '正在检查授权状态...';
            authStatusDetail.className = 'sync-status loading';
            authStatusDetail.style.display = 'block';
        }
        
        await checkUserAuthorization();
        
        checkAuthBtn.disabled = false;
        checkAuthBtn.textContent = '检查授权状态';
    });
}

// 打开插件时自动检查授权：先显示授权页，通过则进入主页，否则显示请联系管理员开通权限
async function autoCheckAuthorization() {
    if (!authCheckOverlay || !mainAppContainer) return;
    
    // 始终显示授权检查遮罩层，直到检查完成
    authCheckOverlay.style.display = 'flex';
    mainAppContainer.style.display = 'none';
    
    if (authCheckStatus) {
        authCheckStatus.textContent = '正在检查授权状态...';
        authCheckStatus.style.display = 'block';
    }
    if (authCheckError) authCheckError.style.display = 'none';
    if (authCheckRefreshHint) authCheckRefreshHint.style.display = 'none';
    if (authCheckRefreshBtn) authCheckRefreshBtn.style.display = 'none';
    
    // 使用默认管理表格或用户配置的URL
    const sheetUrl = (localStorage.getItem('authSheetUrl') || '').trim() || DEFAULT_AUTH_SHEET_URL;
    if (sheetUrl) localStorage.setItem('authSheetUrl', sheetUrl);
    
    setTimeout(async () => {
        await checkUserAuthorization(true); // showOverlay = true，结果会控制遮罩/主页显示
    }, 800);
}

// Run auto-check on load
autoCheckAuthorization();

// 刷新并再次验证：用户必须先刷新推特页面后再点击，才能正确获取用户ID并验证
if (authCheckRefreshBtn) {
    authCheckRefreshBtn.addEventListener('click', async () => {
        if (!authCheckOverlay || !mainAppContainer) return;
        authCheckOverlay.style.display = 'flex';
        mainAppContainer.style.display = 'none';
        if (authCheckStatus) {
            authCheckStatus.textContent = '正在检查授权状态...';
            authCheckStatus.style.display = 'block';
        }
        if (authCheckError) authCheckError.style.display = 'none';
        if (authCheckRefreshHint) authCheckRefreshHint.style.display = 'none';
        if (authCheckRefreshBtn) authCheckRefreshBtn.style.display = 'none';
        await checkUserAuthorization(true);
    });
}

// === Google Sheets Help Modal ===
const sheetsHelpModal = document.getElementById('sheetsHelpModal');
const sheetsHelpBtn = document.getElementById('sheetsHelpBtn');
const closeSheetsHelpBtn = document.getElementById('closeSheetsHelpBtn');
const copyScriptBtn = document.getElementById('copyScriptBtn');
const scriptCodePreview = document.getElementById('scriptCodePreview');

// Apps Script code template
// Apps Script code placeholder (will be loaded dynamically)
let APPS_SCRIPT_CODE = 'Loading code...';

// Load Apps Script code from file
async function loadAppsScriptCode() {
    try {
        const response = await fetch(chrome.runtime.getURL('google_apps_script.js'));
        if (response.ok) {
            APPS_SCRIPT_CODE = await response.text();
            if (scriptCodePreview) {
                scriptCodePreview.textContent = APPS_SCRIPT_CODE;
            }
        } else {
            console.error('Failed to load Apps Script code');
            APPS_SCRIPT_CODE = '// Failed to load script code';
        }
    } catch (e) {
        console.error('Error loading Apps Script code:', e);
        APPS_SCRIPT_CODE = '// Error loading script code';
    }
}

// Show help modal
if (sheetsHelpBtn && sheetsHelpModal) {
    sheetsHelpBtn.addEventListener('click', () => {
        sheetsHelpModal.classList.remove('hidden');
        if (scriptCodePreview) {
            scriptCodePreview.textContent = APPS_SCRIPT_CODE;
        }
    });
}

// Close help modal
if (closeSheetsHelpBtn && sheetsHelpModal) {
    closeSheetsHelpBtn.addEventListener('click', () => {
        sheetsHelpModal.classList.add('hidden');
    });

    // Close on background click
    sheetsHelpModal.addEventListener('click', (e) => {
        if (e.target === sheetsHelpModal) {
            sheetsHelpModal.classList.add('hidden');
        }
    });
}

// Copy script code
if (copyScriptBtn) {
    copyScriptBtn.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(APPS_SCRIPT_CODE);
            copyScriptBtn.textContent = '已复制!';
            setTimeout(() => {
                copyScriptBtn.textContent = '复制代码';
            }, 2000);
        } catch (err) {
            showNotification('复制失败，请手动选择复制', true);
        }
    });
}

// Icons
const ICONS = {
    add: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>',
    archive: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M20.54 5.23l-1.39-1.68C18.88 3.21 18.47 3 18 3H6c-.47 0-.88.21-1.16.55L3.46 5.23C3.17 5.57 3 6.02 3 6.5V19c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6.5c0-.48-.17-.93-.46-1.27zM6.24 5h11.52l.83 1H5.42l.82-1zM19 19H5V8h14v11zm-8-2h2v-4h-2v4zm0-6h2v-2h-2v2z"/></svg>',
    unarchive: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M20.54 5.23l-1.39-1.68C18.88 3.21 18.47 3 18 3H6c-.47 0-.88.21-1.16.55L3.46 5.23C3.17 5.57 3 6.02 3 6.5V19c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6.5c0-.48-.17-.93-.46-1.27zM6.24 5h11.52l.83 1H5.42l.82-1zM19 19H5V8h14v11zm-8-2h2v-4h-2v4zm0-6h2v-2h-2v2z"/><path d="M12 10l-4 4h8z"/></svg>', // Modified for unarchive visual
    trash: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>',
    restore: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>',
    reply: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M1.751 10c0-4.42 3.584-8 8.005-8h4.366c4.49 0 8.129 3.64 8.129 8.13 0 2.96-1.607 5.68-4.196 7.11l-8.054 4.46v-3.69h-.067c-4.49.1-8.183-3.51-8.183-8.01zm8.005-6c-3.317 0-6.005 2.69-6.005 6 0 3.37 2.77 6.08 6.138 6.01l.351-.01h1.761v2.3l5.087-2.81c1.951-1.08 3.163-3.13 3.163-5.36 0-3.39-2.744-6.13-6.129-6.13H9.756z"/></svg>',
    retweet: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M19 7v4H5.83l3.58-3.59L8 6l-6 6 6 6 1.41-1.41L5.83 13H21V7z"/></svg>',
    like: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>',
    edit: '<svg class="icon-svg" viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>'
};

// --- Navigation Logic ---
function switchTab(tab) {
    navKOLs.classList.remove('active');
    navScanner.classList.remove('active');
    navList.classList.remove('active');
    navArchive.classList.remove('active');
    navTrash.classList.remove('active');
    if (navAI) navAI.classList.remove('active');
    if (navReport) navReport.classList.remove('active');
    if (navSummary) navSummary.classList.remove('active');


    viewKOLs.classList.remove('active');
    viewScanner.classList.remove('active');
    viewList.classList.remove('active');
    viewArchive.classList.remove('active');
    viewTrash.classList.remove('active');
    if (viewAI) viewAI.classList.remove('active');
    if (viewReport) viewReport.classList.remove('active');
    if (viewSummary) viewSummary.classList.remove('active');


    if (tab === 'kols') {
        navKOLs.classList.add('active');
        viewKOLs.classList.add('active');
    } else if (tab === 'scanner') {
        navScanner.classList.add('active');
        viewScanner.classList.add('active');
    } else if (tab === 'list') {
        navList.classList.add('active');
        viewList.classList.add('active');
    } else if (tab === 'archive') {
        navArchive.classList.add('active');
        viewArchive.classList.add('active');
    } else if (tab === 'trash') {
        navTrash.classList.add('active');
        viewTrash.classList.add('active');
        renderTrash();
    } else if (tab === 'ai') {
        if (navAI) navAI.classList.add('active');
        if (viewAI) viewAI.classList.add('active');
    } else if (tab === 'report') {
        if (navReport) navReport.classList.add('active');
        if (viewReport) viewReport.classList.add('active');
        console.log('[switchTab] Rendering all interaction traces');
        renderDailyReport(undefined, false); // No date parameter needed - show all, reset scroll position when switching tabs
    } else if (tab === 'summary') {
        if (navSummary) navSummary.classList.add('active');
        if (viewSummary) viewSummary.classList.add('active');
    }
}
navKOLs.addEventListener('click', () => switchTab('kols'));
navScanner.addEventListener('click', () => switchTab('scanner'));
navList.addEventListener('click', () => switchTab('list'));
navArchive.addEventListener('click', () => switchTab('archive'));
navTrash.addEventListener('click', () => switchTab('trash'));
if (navAI) navAI.addEventListener('click', () => switchTab('ai'));
if (navReport) navReport.addEventListener('click', () => switchTab('report'));
if (navSummary) navSummary.addEventListener('click', () => switchTab('summary'));


// --- Messaging Logic ---
// KOL Scan Elements
const startKOLScanBtn = document.getElementById('startKOLScanBtn');
const stopKOLScanBtn = document.getElementById('stopKOLScanBtn');

const kolScanState = {
    active: false,
    kols: [],
    currentIndex: 0,
    timerId: null,
    intervalId: null // Add intervalId
};

// KOL 24h Reply State
let kol24hReplyState = {
    active: false,
    paused: false,
    originalMaxTweetAge: null
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'NEW_TWEETS') {
        const newTweets = message.payload;
        let addedCount = 0;
        const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
        const now = Date.now();

        newTweets.forEach(tweet => {
            if (tweetStore.has(tweet.id)) return;

            // Determine target list and status based on scan mode
            let targetList = scannerList;
            let status = 'scanner';

            if (kolScanState.active) {
                // Filter: Check if tweet username matches KOL username
                const currentKOL = kolScanState.kols[kolScanState.currentIndex];
                if (currentKOL && currentKOL.link) {
                    // Extract username from KOL link (e.g. https://x.com/username)
                    const kolUsernameMatch = currentKOL.link.match(/(?:twitter\.com|x\.com)\/([^\/]+)/);
                    if (kolUsernameMatch && kolUsernameMatch[1]) {
                        const kolUsername = kolUsernameMatch[1].toLowerCase();
                        const tweetUsername = tweet.username.toLowerCase();

                        // If usernames don't match, it's likely a retweet or ad
                        if (kolUsername !== tweetUsername) {
                            console.log(`Skipping tweet from @${tweet.username} (Expected @${kolUsername})`);
                            return;
                        }

                        // Filter: Check Max Tweet Age (Group Specific)
                        const groupId = currentKOL.groupId || 'default';
                        const group = groupStore.get(groupId);
                        const groupMaxAge = (group && group.config && group.config.maxTweetAge !== undefined)
                            ? parseInt(group.config.maxTweetAge, 10)
                            : aiConfig.maxTweetAge;

                        if (groupMaxAge > 0) {
                            const cutoff = Date.now() - (groupMaxAge * 60 * 60 * 1000); // Hours
                            if (tweet.timestamp < cutoff) {
                                console.log(`Skipping old tweet from @${tweet.username} (Age > ${groupMaxAge} hours)`);
                                return;
                            }
                        }
                    }
                }

                targetList = listList;
                status = 'list';
            } else {
                // Scanner mode: Apply 24h filter and reply exclusion

                // Filter: Skip replies
                if (tweet.isReply) {
                    console.log(`Skipping reply tweet from @${tweet.username} `);
                    return;
                }

                // Filter: Only 24h tweets
                const cutoff = now - TWENTY_FOUR_HOURS;
                if (tweet.timestamp < cutoff) {
                    console.log(`Skipping old tweet from @${tweet.username} (Age > 24 hours)`);
                    return;
                }
            }

            tweetStore.set(tweet.id, {
                ...tweet,
                interactions: { reply: false, retweet: false, like: false },
                status: status,
                addedAt: status === 'list' ? Date.now() : 0,
                archivedAt: 0,
                deletedAt: 0,
                groupId: (kolScanState.active && kolScanState.kols[kolScanState.currentIndex]) ? (kolScanState.kols[kolScanState.currentIndex].groupId || 'default') : 'default'
            });

            addTweetCard(tweetStore.get(tweet.id), targetList);
            addedCount++;

            // Auto-sync to Google Sheets if added to list
            if (status === 'list' && googleSheetsConfig.scriptUrl) {
                syncToGoogleSheets([tweetStore.get(tweet.id)]);
            }
        });

        if (addedCount > 0) {
            if (kolScanState.active) {
                removeEmptyState(listList);
            } else {
                removeEmptyState(scannerList);
            }
            saveTweets(); // Persist new tweets
        }
    } else if (message.type === 'PROFILE_INFO') {
        if (message.payload) {
            kolNameInput.value = message.payload.name || '';
            kolLinkInput.value = message.payload.link || '';
            kolAvatarInput.value = message.payload.avatar || '';
        }
    }
});

// KOL Auto-Scan Logic
function startKOLScan() {
    // Get KOLs in visual order (Top to Bottom)
    const kols = Array.from(kolStore.values()).reverse();

    if (kols.length === 0) {
        showNotification(chrome.i18n.getMessage('notification_no_kols'), true);
        return;
    }

    kolScanState.active = true;
    kolScanState.kols = kols;
    kolScanState.currentIndex = 0;

    // UI Updates
    startKOLScanBtn.disabled = false; // Keep enabled for stop action
    // Jumping Text: S c a n n i n g . . .
    startKOLScanBtn.innerHTML = `<div class="scanning-text"> ${chrome.i18n.getMessage('scanning_text')}</div> `;

    processNextKOL();
}

function stopKOLScan() {
    kolScanState.active = false;
    kolScanState.kols = [];
    kolScanState.currentIndex = 0;
    if (kolScanState.timerId) clearTimeout(kolScanState.timerId);
    if (kolScanState.intervalId) clearInterval(kolScanState.intervalId);
    kolScanState.timerId = null;
    kolScanState.intervalId = null;

    // UI Updates
    if (startKOLScanBtn) {
        startKOLScanBtn.disabled = false;
        startKOLScanBtn.textContent = chrome.i18n.getMessage('btn_scan'); // Reset to plain text
        startKOLScanBtn.classList.remove('active-state'); // Ensure hover state is removed
    }
    
    // If this was KOL 24h reply mode, stop it
    if (kol24hReplyState && kol24hReplyState.active) {
        stopKOL24hReply();
    }
}

// --- KOL Logic ---

// Add KOL Button (Opens Modal)
if (kolAddBtn) {
    kolAddBtn.addEventListener('click', async () => {
        // Clear inputs
        kolNameInput.value = '';
        kolNoteInput.value = '';
        kolLinkInput.value = '';
        kolAvatarInput.value = '';

        // Show modal
        addKOLModal.classList.remove('hidden');

        // Trigger Auto-fill
        const profileInfo = await sendMessageToActiveTab({ action: 'GET_PROFILE_INFO' });
        if (profileInfo) {
            kolNameInput.value = profileInfo.name || '';
            kolLinkInput.value = profileInfo.link || '';
            kolAvatarInput.value = profileInfo.avatar || '';
        } else {
            showNotification(chrome.i18n.getMessage('notification_go_to_homepage'), true);
        }
    });
}



// Export Config Button
if (kolExportBtn) {
    kolExportBtn.addEventListener('click', () => {
        exportAllConfig();
    });
}

// Import Config Button
if (kolImportBtn && configFileInput) {
    kolImportBtn.addEventListener('click', () => {
        configFileInput.click(); // Trigger file picker
    });

    configFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            importAllConfig(file);
            configFileInput.value = ''; // Reset for next use
        }
    });
}

if (cancelKOLBtn) {
    cancelKOLBtn.addEventListener('click', () => {
        addKOLModal.classList.add('hidden');
    });
}

if (saveKOLBtn) {
    saveKOLBtn.addEventListener('click', () => {
        const name = kolNameInput.value.trim();
        const note = kolNoteInput.value.trim();
        const link = kolLinkInput.value.trim();
        const avatar = kolAvatarInput.value; // Get avatar URL
        const groupId = kolGroupSelect ? kolGroupSelect.value : 'default';

        if (!name || !link) {
            showNotification(chrome.i18n.getMessage('notification_fields_required'), true);
            return;
        }

        if (kolStore.has(link)) {
            // Edit existing
            const kol = kolStore.get(link);
            kol.name = name;
            kol.note = note;
            kol.avatar = avatar;
            kol.groupId = groupId; // Update group
            kolStore.set(link, kol);
            addKOLCard(kol); // Refresh UI
            showNotification(chrome.i18n.getMessage('notification_kol_updated'), false);
        } else {
            // Add new
            const newKOL = {
                name,
                note,
                link,
                avatar,
                addedAt: Date.now(),
                groupId: groupId // Set group
            };
            kolStore.set(link, newKOL);
            addKOLCard(newKOL);
            showNotification(chrome.i18n.getMessage('notification_kol_added'), false);
            removeEmptyState(kolList);
        }
        saveKOLs(); // Save changes
        addKOLModal.classList.add('hidden');
    });
}

function addKOLCard(data) {
    // Remove existing card if updating
    const existingCard = kolList.querySelector(`.tweet-card[data-link="${data.link}"]`);
    if (existingCard) existingCard.remove();

    const card = document.createElement('div');
    card.className = 'tweet-card'; // Reuse card style
    card.dataset.link = data.link; // Store link for updates

    const date = new Date(data.addedAt);
    const formattedDate = date.toLocaleString('en-US', {
        year: 'numeric', month: '2-digit', day: '2-digit'
    });

    // Extract handle from link if possible
    let handle = '';
    const match = data.link.match(/(?:twitter\.com|x\.com)\/([^\/]+)/);
    if (match) handle = '@' + match[1];

    // Avatar Logic
    let avatarHtml = '';
    if (data.avatar) {
        avatarHtml = `<img src="${data.avatar}" class="kol-avatar" alt="${data.name}">`;
    } else {
        // Default Gray Avatar (Anonymous)
        avatarHtml = `<div class="kol-avatar default">
    <svg viewBox="0 0 24 24" fill="#ffffff"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" /></svg>
        </div> `;
    }

    // 仅当存在多个策略时显示策略标签（只有一个策略不显示默认策略）
    const group = groupStore.get(data.groupId || 'default');
    const groupName = group ? group.name : 'Unknown';
    const groupColor = group ? group.color || '#666' : '#666';
    const showGroupBadge = groupStore.size > 1;
    const groupBadge = showGroupBadge ? `
    <div class="group-badge" style="background-color: ${groupColor};">
        <svg viewBox="0 0 24 24"><path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z" /></svg>
            ${groupName}
        </div>
    ` : '';

    card.innerHTML = `
    <div class="kol-card-header">
        ${avatarHtml}
            <div style="flex: 1; min-width: 0;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span class="username">${data.name}</span>
                    <span class="timestamp">${handle}</span>
                </div>
                <div style="font-size: 12px; color: var(--text-color); margin-top: 2px; display: flex; align-items: center; gap: 6px;">
                    <span style="color: var(--meta-color);">${chrome.i18n.getMessage('note_prefix')}<span style="color: var(--text-color);">${data.note || ''}</span></span>
                </div>
            </div>
            <div style="display: flex; gap: 4px;">
                <button class="icon-btn edit-header-btn" title="${chrome.i18n.getMessage('btn_edit')}">${ICONS.edit}</button>
                <button class="icon-btn delete-btn" title="${chrome.i18n.getMessage('btn_delete')}">${ICONS.trash}</button>
            </div>
        </div>
        <a href="${data.link}" target="_blank" class="tweet-content-link">
            <div class="tweet-link">${data.link}</div>
        </a>
        <div class="kol-card-footer">
            ${groupBadge}
            <div style="font-size: 10px; color: var(--meta-color); margin-top: 4px;">
                ${chrome.i18n.getMessage('added_date', [formattedDate])}
            </div>
        </div>
`;

    // Delete Listener
    const deleteBtn = card.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent bubbling
        showConfirmModal(
            chrome.i18n.getMessage('modal_delete_kol_title'),
            chrome.i18n.getMessage('modal_delete_kol_msg', [data.name]),
            chrome.i18n.getMessage('btn_yes_delete'),
            () => {
                kolStore.delete(data.link);
                card.remove();
                saveKOLs(); // Save changes
                checkEmptyState(kolList);
            }
        );
    });

    // Edit Function
    const openEditModal = () => {
        // Populate Modal
        kolNameInput.value = data.name || '';
        kolNoteInput.value = data.note || '';
        kolLinkInput.value = data.link || '';
        kolAvatarInput.value = data.avatar || '';
        if (kolGroupSelect) kolGroupSelect.value = data.groupId || 'default';

        // Show Modal
        addKOLModal.classList.remove('hidden');

    };

    // Header Edit Listener
    const headerEditBtn = card.querySelector('.edit-header-btn');
    headerEditBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openEditModal();
    });

    kolList.prepend(card);
}

function exportKOLsToCSV() {
    const kols = Array.from(kolStore.values());

    if (kols.length === 0) {
        alert(chrome.i18n.getMessage('alert_no_kols_export'));
        return;
    }

    // Columns: Name, Note, Link, Added Time
    const headers = ['Name', 'Note', 'Link', 'Added Time'];
    const rows = kols.map(item => {
        const time = new Date(item.addedAt).toLocaleString();
        return [
            item.name,
            item.note,
            item.link,
            time
        ].map(field => `"${field}"`).join(','); // Quote fields
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `x_kol_list_${Date.now()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Export all configuration data as JSON
function exportAllConfig() {
    const config = {
        version: '1.0',
        exportedAt: new Date().toISOString(),
        kols: Array.from(kolStore.values()),
        groups: Array.from(groupStore.values()),
        tweets: Array.from(tweetStore.values()),
        aiConfig: {
            provider: aiConfig.provider,
            prompt: aiConfig.prompt,
            autoLike: aiConfig.autoLike,
            autoRepost: aiConfig.autoRepost,
            replyDelayMin: aiConfig.replyDelayMin,
            replyDelayMax: aiConfig.replyDelayMax,
            likeDelayMin: aiConfig.likeDelayMin,
            likeDelayMax: aiConfig.likeDelayMax,
            maxTweetAge: aiConfig.maxTweetAge,
            autoRunEnabled: aiConfig.autoRunEnabled,
            autoRunStart: aiConfig.autoRunStart,
            autoRunEnd: aiConfig.autoRunEnd,
            autoRunInterval: aiConfig.autoRunInterval
            // Note: API key is NOT exported for security
        }
    };

    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.setAttribute('href', url);

    // Generate filename with date
    const date = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
    link.setAttribute('download', `xcommunity_config_${date}.json`);

    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showNotification('配置已导出', false);
}

// Import all configuration data from JSON file
function importAllConfig(file) {
    const reader = new FileReader();

    reader.onload = (e) => {
        try {
            const config = JSON.parse(e.target.result);

            // Validate config structure
            if (!config.version || !config.kols) {
                throw new Error('无效的配置文件格式');
            }

            // Show confirmation dialog
            showConfirmModal(
                '导入配置',
                `确定要导入此配置吗？\n\n将导入: \n• ${config.kols?.length || 0} 个 KOL\n• ${config.groups?.length || 0} 个策略组\n• ${config.tweets?.length || 0} 条推文\n\n⚠️ 现有数据将与导入数据合并`,
                '确认导入',
                () => {
                    performImport(config);
                }
            );
        } catch (error) {
            console.error('Import failed:', error);
            showNotification('导入失败: ' + error.message, true);
        }
    };

    reader.onerror = () => {
        showNotification('读取文件失败', true);
    };

    reader.readAsText(file);
}

// Actually perform the import
function performImport(config) {
    let importedKols = 0;
    let importedGroups = 0;
    let importedTweets = 0;

    // Import KOLs (merge, don't overwrite existing)
    if (config.kols && Array.isArray(config.kols)) {
        config.kols.forEach(kol => {
            if (!kolStore.has(kol.link)) {
                kolStore.set(kol.link, kol);
                addKOLCard(kol);
                importedKols++;
            }
        });
        if (importedKols > 0) {
            removeEmptyState(kolList);
            saveKOLs();
        }
    }

    // Import Groups (merge, don't overwrite existing)
    if (config.groups && Array.isArray(config.groups)) {
        config.groups.forEach(group => {
            if (!groupStore.has(group.id)) {
                groupStore.set(group.id, group);
                importedGroups++;
            }
        });
        if (importedGroups > 0) {
            saveGroups();
            renderStrategyList();
        }
    }

    // Import Tweets (merge, don't overwrite existing)
    if (config.tweets && Array.isArray(config.tweets)) {
        config.tweets.forEach(tweet => {
            if (!tweetStore.has(tweet.id)) {
                tweetStore.set(tweet.id, tweet);
                // Render to appropriate list
                if (tweet.status === 'scanner') {
                    addTweetCard(tweet, scannerList);
                } else if (tweet.status === 'list') {
                    addTweetCard(tweet, listList);
                } else if (tweet.status === 'archive') {
                    addTweetCard(tweet, archiveList);
                }
                importedTweets++;
            }
        });
        if (importedTweets > 0) {
            saveTweets();
        }
    }

    // Import AI Config (optional, only if present)
    if (config.aiConfig) {
        // Note: API key is not imported for security
        if (config.aiConfig.provider) aiConfig.provider = config.aiConfig.provider;
        if (config.aiConfig.prompt) aiConfig.prompt = config.aiConfig.prompt;
        if (config.aiConfig.autoLike !== undefined) aiConfig.autoLike = config.aiConfig.autoLike;
        if (config.aiConfig.autoRepost !== undefined) aiConfig.autoRepost = config.aiConfig.autoRepost;
        // Save to localStorage
        localStorage.setItem('aiProvider', aiConfig.provider);
        localStorage.setItem('aiPrompt', aiConfig.prompt);
        localStorage.setItem('aiAutoLike', aiConfig.autoLike);
        localStorage.setItem('aiAutoRepost', aiConfig.autoRepost);
    }

    showNotification(
        `导入完成: ${importedKols} KOL, ${importedGroups} 策略组, ${importedTweets} 推文`,
        false
    );
}

// ... (Rest of UI Logic) ...

// --- UI Logic ---

// --- FAB Logic ---
const fabMenuBtn = document.getElementById('fabMenuBtn');
const fabActions = document.getElementById('fabActions');
const exportBtn = document.getElementById('exportBtn');
const deleteAllArchiveBtn = document.getElementById('deleteAllArchiveBtn');

if (fabMenuBtn) {
    fabMenuBtn.addEventListener('click', () => {
        fabActions.classList.toggle('hidden');
    });
}

if (exportBtn) {
    exportBtn.addEventListener('click', () => {
        exportToCSV();
    });
}

// --- Modal Logic ---
const confirmModal = document.getElementById('confirmModal');
const confirmTitle = confirmModal.querySelector('h3');
const confirmMessage = confirmModal.querySelector('p');
const confirmYesBtn = document.getElementById('confirmYesBtn');
const confirmNoBtn = document.getElementById('confirmNoBtn');

let currentConfirmCallback = null;

function showConfirmModal(title, message, yesText, callback, showCancel = true, yesBtnClass = 'danger') {
    confirmTitle.textContent = title;
    confirmMessage.textContent = message;
    confirmYesBtn.textContent = yesText;
    currentConfirmCallback = callback;

    // Reset classes
    confirmYesBtn.className = '';
    confirmYesBtn.classList.add(yesBtnClass);

    if (showCancel) {
        confirmNoBtn.classList.remove('hidden');
    } else {
        confirmNoBtn.classList.add('hidden');
    }

    confirmModal.classList.remove('hidden');
}

function hideConfirmModal() {
    confirmModal.classList.add('hidden');
    currentConfirmCallback = null;
    confirmNoBtn.classList.remove('hidden'); // Reset
    // Reset Yes button to default danger for safety
    confirmYesBtn.className = 'danger';
}

if (confirmNoBtn) {
    confirmNoBtn.addEventListener('click', hideConfirmModal);
}

if (confirmYesBtn) {
    confirmYesBtn.addEventListener('click', () => {
        if (currentConfirmCallback) {
            currentConfirmCallback();
        }
        hideConfirmModal();
    });
}

function processNextKOL() {
    if (!kolScanState.active) return;
    if (aiProcessState.paused) return; // NEW: Skip if paused

    aiProcessState.currentPhase = 'scanning'; // NEW: Track phase

    if (kolScanState.currentIndex >= kolScanState.kols.length) {
        // Scan complete
        stopKOLScan();

        if (aiProcessState.active) {
            // Check if this is KOL 24h reply mode
            if (kol24hReplyState.active) {
                // KOL 24h Reply Mode -> All KOLs scanned, now reply to collected tweets
                startAIReplyPhase();
            } else {
                // AI Mode -> Group Scan Complete
                // Proceed to Reply Phase for THIS group
                startAIReplyPhase();
            }
        } else {
            // Normal Manual Scan Complete - 移除弹窗，静默完成
            console.log('KOL scan completed');
        }
        return;
    }

    const kol = kolScanState.kols[kolScanState.currentIndex];

    // Navigate to KOL link
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!kolScanState.active || aiProcessState.paused) return; // Check active and paused before acting

        if (tabs[0]) {
            const tabId = tabs[0].id;
            chrome.tabs.update(tabId, { url: kol.link });

            // Poll for tab completion
            const checkTabStatus = setInterval(() => {
                if (!kolScanState.active || aiProcessState.paused) {
                    clearInterval(checkTabStatus);
                    console.log('KOL scan stopped or paused');
                    return;
                }

                chrome.tabs.get(tabId, (tab) => {
                    if (chrome.runtime.lastError || !tab) {
                        clearInterval(checkTabStatus);
                        return;
                    }

                    if (tab.status === 'complete') {
                        clearInterval(checkTabStatus);

                        // Wait 10 seconds after load
                        kolScanState.timerId = setTimeout(async () => {
                            if (!kolScanState.active || aiProcessState.paused) return; // Check active and paused

                            // Sync Avatar and Display Name
                            try {
                                const profileInfo = await sendMessageToActiveTab({ action: 'GET_PROFILE_INFO' });
                                if (profileInfo) {
                                    let needsUpdate = false;

                                    // Update avatar if changed
                                    if (profileInfo.avatar && kol.avatar !== profileInfo.avatar) {
                                        console.log(`Updating avatar for ${kol.name}`);
                                        kol.avatar = profileInfo.avatar;
                                        needsUpdate = true;
                                    }

                                    // Update display name (昵称) if changed and available
                                    if (profileInfo.name && kol.name !== profileInfo.name) {
                                        console.log(`Updating display name for ${kol.link}: ${kol.name} -> ${profileInfo.name}`);
                                        kol.name = profileInfo.name;
                                        needsUpdate = true;
                                    }

                                    if (needsUpdate) {
                                        kolStore.set(kol.link, kol);
                                        addKOLCard(kol);
                                        saveKOLs();
                                    }
                                }
                            } catch (err) {
                                console.warn('Failed to sync profile info:', err);
                            }

                            // Start Scan
                            if (!kolScanState.active || aiProcessState.paused) return;

                            // KOL 24h 模式：当前页滚动+提取 24h 推文（排除置顶），扫完当前 KOL 即回复，再下一个
                            if (kol24hReplyState && kol24hReplyState.active) {
                                try {
                                    console.log(`[KOL 24h] Starting scan for ${kol.name} (${kol.link})...`);
                                    updateAIProgress(kolScanState.currentIndex + 1, kolScanState.kols.length, `正在扫描 ${kol.name}...`, 'kol24h', { label: '当前 KOL', current: kolScanState.currentIndex + 1, total: kolScanState.kols.length });
                                    
                                    const res = await sendMessageToActiveTab({
                                        action: 'SCROLL_AND_EXTRACT_PROFILE_TWEETS',
                                        payload: { targetCount: 10, maxAgeHours: 24 } // 24h内推文不会很多
                                    });
                                    
                                    if (!res) {
                                        console.error('[KOL 24h] No response from content script');
                                        kol.lastScannedAt = Date.now();
                                        kolStore.set(kol.link, kol);
                                        saveKOLs();
                                        kolScanState.currentIndex++;
                                        processNextKOL();
                                        return;
                                    }
                                    
                                    const rawTweets = (res && res.tweets) ? res.tweets : [];
                                    // 只回复博主本人发布的推文（原创、引用后自己发的都回复）；跳过转帖及他人原推（链接作者≠博主）
                                    const kolUsername = (kol.link.match(/(?:twitter\.com|x\.com)\/([^\/]+)/) || [])[1] || '';
                                    let tweets = rawTweets.filter(t => {
                                        const author = (t.username || '').toLowerCase();
                                        const ok = author === kolUsername.toLowerCase();
                                        if (!ok && (t.username || t.url)) {
                                            console.log(`[KOL 24h] 跳过非博主本人推文: @${t.username} (期望 @${kolUsername})`);
                                        }
                                        return ok;
                                    });
                                    const maxPerKol = parseInt(aiConfig.kolMaxTweetsPerKol, 10) || 0;
                                    if (maxPerKol > 0 && tweets.length > maxPerKol) {
                                        tweets = tweets.slice(0, maxPerKol);
                                        console.log(`[KOL 24h] 每个 KOL 最多回复 ${maxPerKol} 条，取前 ${tweets.length} 条 for ${kol.name}`);
                                    }
                                    console.log(`[KOL 24h] Extracted ${rawTweets.length} tweets, ${tweets.length} 条博主本人推文 for ${kol.name}`);
                                    
                                    if (tweets.length > 0) {
                                        console.log(`[KOL 24h] Found ${tweets.length} tweets for ${kol.name}. Starting reply...`);
                                        updateAIProgress(kolScanState.currentIndex + 1, kolScanState.kols.length, `正在回复 ${kol.name} 的 ${tweets.length} 条推文...`, 'kol24h', { label: '当前 KOL 推文', current: 0, total: tweets.length });
                                        await processCurrentKOLTweets(tweets, kol);
                                        console.log(`[KOL 24h] Completed replies for ${kol.name}`);
                                    } else {
                                        console.log(`[KOL 24h] No 24h tweets found for ${kol.name}.`);
                                    }
                                } catch (err) {
                                    console.error('[KOL 24h] Error in processNextKOL:', err);
                                }
                                kol.lastScannedAt = Date.now();
                                kolStore.set(kol.link, kol);
                                saveKOLs();
                                // 移动到下一个 KOL（暂停时不继续，等恢复后再走）
                                kolScanState.currentIndex++;
                                if (kolScanState.active && (!kol24hReplyState || !kol24hReplyState.paused)) {
                                    processNextKOL();
                                }
                                return;
                            }

                            // 非 KOL 24h：原有逻辑（模拟滚动 + 监听 + tweetStore）
                            try {
                                await sendMessageToActiveTab({ action: 'SIMULATE_SCROLL' });
                            } catch (err) {
                                console.warn('Failed to simulate scroll:', err);
                            }

                            if (!kolScanState.active) return;
                            sendMessageToActiveTab({ action: 'START_LISTENING' });

                            kolScanState.timerId = setTimeout(async () => {
                                if (!kolScanState.active || aiProcessState.paused) return;

                                try {
                                    sendMessageToActiveTab({ action: 'STOP_LISTENING' });

                                    const username = kol.link.split('/').pop();
                                    let maxTweetAge = aiConfig.maxTweetAge;
                                    if (isNaN(maxTweetAge)) maxTweetAge = 0;
                                    const cutoff = maxTweetAge > 0 ? Date.now() - (maxTweetAge * 60 * 60 * 1000) : 0;

                                    const tweets = Array.from(tweetStore.values()).filter(t => {
                                        const isUser = t.username.toLowerCase() === username.toLowerCase();
                                        const isUnreplied = !t.interactions?.reply;
                                        const isRecent = cutoff === 0 || t.timestamp >= cutoff;
                                        return isUser && isUnreplied && isRecent;
                                    });

                                    if (tweets.length > 0) {
                                        console.log(`Found ${tweets.length} tweets for ${username}. Processing...`);
                                        await processCurrentKOLTweets(tweets, kol);
                                    } else {
                                        console.log(`No new tweets found for ${username}.`);
                                    }
                                } catch (err) {
                                    console.error("Error in processNextKOL inner loop:", err);
                                }

                                kolScanState.currentIndex++;
                                processNextKOL();
                            }, 5000);

                        }, 10000);
                    }
                });
            }, 1000); // Check every 1s

            // Store interval
            kolScanState.intervalId = checkTabStatus;
        } else {
            // No tab found? Skip
            console.warn("No active tab found for scan.");
            kolScanState.currentIndex++;
            processNextKOL();
        }
    });
}

// 暂停时在此等待，直到恢复或停止（KOL 24h 专用）
async function waitUntilKOL24hUnpaused() {
    while (kol24hReplyState && kol24hReplyState.active && kol24hReplyState.paused) {
        await new Promise(r => setTimeout(r, 500));
    }
}

async function processCurrentKOLTweets(tweets, kol) {
    for (let i = 0; i < tweets.length; i++) {
        const tweet = tweets[i];
        const currentKol = kol || (kolScanState.kols && kolScanState.kols[kolScanState.currentIndex]);
        if (currentKol) {
            updateAIProgress(kolScanState.currentIndex + 1, kolScanState.kols.length, `正在回复 ${currentKol.name} 第 ${i + 1}/${tweets.length} 条...`, 'kol24h', { label: '当前 KOL 推文', current: i + 1, total: tweets.length });
        }
        await waitUntilKOL24hUnpaused();
        if (!kolScanState.active || (kol24hReplyState && !kol24hReplyState.active)) return;
        if (kol24hReplyState && kol24hReplyState.paused) continue;

        console.log(`Processing tweet ${tweet.id} for KOL...`);
        aiStatusDiv.textContent = chrome.i18n.getMessage('processing_tweet', [tweet.username]);

        // 1. Navigate to Tweet
        console.log(`[KOL 24h] Navigating to tweet: ${tweet.url}`);
        await new Promise(resolve => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.update(tabs[0].id, { url: tweet.url });
                    console.log(`[KOL 24h] Tab updated to tweet URL`);
                    resolve();
                } else {
                    console.error('[KOL 24h] No active tab found');
                    resolve(); // Should not happen
                }
            });
        });

        await waitUntilKOL24hUnpaused();
        if (!kolScanState.active || (kol24hReplyState && !kol24hReplyState.active)) return;

        // 2. Wait for Load - 确保页面完全加载
        console.log(`[KOL 24h] Waiting for page to load...`);
        await new Promise(resolve => {
            let checkCount = 0;
            const maxChecks = 30; // 最多等待30秒
            const check = setInterval(() => {
                checkCount++;
                if (!kolScanState.active || (kol24hReplyState && !kol24hReplyState.active)) {
                    clearInterval(check);
                    resolve();
                    return;
                }
                if (kol24hReplyState && kol24hReplyState.paused) return; // 暂停时不结束等待，继续轮询
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    if (tabs[0] && tabs[0].status === 'complete') {
                        clearInterval(check);
                        // 等待页面稳定，模拟真人阅读速度
                        console.log(`[KOL 24h] Page loaded (after ${checkCount}s), waiting 3s for stability...`);
                        setTimeout(resolve, 3000);
                    } else if (checkCount >= maxChecks) {
                        // 超时也继续
                        console.warn(`[KOL 24h] Page load timeout, continuing anyway...`);
                        clearInterval(check);
                        setTimeout(resolve, 2000);
                    }
                });
            }, 1000);
        });

        await waitUntilKOL24hUnpaused();
        if (!kolScanState.active || (kol24hReplyState && !kol24hReplyState.active)) return;

        // 3. Scrape Content (Optional, but good for context)
        // 兼容不同来源的推文对象：extractTweetLinks 返回 content，其他来源可能用 text
        let tweetContent = tweet.text || tweet.content || '';
        try {
            // Wait additional 2 seconds for DOM to be fully ready
            console.log(`[KOL 24h] Waiting for DOM to be ready...`);
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            await waitUntilKOL24hUnpaused();
            if (!kolScanState.active || (kol24hReplyState && !kol24hReplyState.active)) return;
            
            console.log(`[KOL 24h] Scraping tweet content...`);
            const response = await sendMessageToActiveTab({ action: 'SCRAPE_TWEET_CONTENT' });
            
            if (!response) {
                console.error(`[KOL 24h] Failed to scrape tweet content, skipping...`);
                continue; // 跳过这条推文
            }
            
            console.log(`[KOL 24h] Tweet content scraped successfully`);
            
            // 若当前页是自己发布的推文则跳过（例如把自己加进 KOL 列表时）
            if (response.isOwnTweet) {
                console.log(`[KOL 24h] Skipping - this is your own tweet (@${response.tweetAuthor})`);
                aiStatusDiv.textContent = `跳过 - 自己的推文`;
                continue;
            }
            
            // PRIORITY 0: Check if tweet URL is already in repliedUrls
            const tweetUrl = tweet.url || tweet.normalizedUrl;
            if (tweetUrl) {
                const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                // Normalize URL for comparison
                const normalizedUrl = tweetUrl.split('?')[0].replace(/\/$/, '');
                if (repliedUrls.has(normalizedUrl)) {
                    console.log(`[Priority Skip] Tweet URL already in repliedUrls - skipping:`, normalizedUrl);
                    aiStatusDiv.textContent = `跳过 - 已回复过`;
                    
                    // Mark in local state
                    const data = tweetStore.get(tweet.id) || tweet;
                    data.interactions = data.interactions || {};
                    data.interactions.reply = true;
                    tweetStore.set(tweet.id, data);
                    
                    // Continue to next tweet
                    return;
                }
            }
            
            // PRIORITY 1: Check if tweet is already liked - skip if so
            if (response && response.isLiked) {
                console.log(`[Priority Skip] Tweet is already liked - marking as replied and skipping`);
                aiStatusDiv.textContent = `跳过 - 已点赞`;
                
                // Mark as replied to avoid retrying
                const data = tweetStore.get(tweet.id) || tweet;
                data.interactions = data.interactions || {};
                data.interactions.reply = true; // Mark as replied
                data.interactions.like = true; // Already liked
                tweetStore.set(tweet.id, data);
                
                // Also add to repliedUrls
                if (tweetUrl) {
                    const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                    const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                    const normalizedUrl = tweetUrl.split('?')[0].replace(/\/$/, '');
                    repliedUrls.add(normalizedUrl);
                    safeSetRepliedUrls(repliedUrls);
                }
                
                // Continue to next tweet
                return;
            }

            // PRIORITY 2: Check if tweet is already replied to (from page detection)
            if (response && response.isReplied) {
                console.log(`[Priority Skip] Tweet is already replied (detected from page) - marking as replied and skipping`);
                aiStatusDiv.textContent = `跳过 - 页面检测已回复`;
                
                // Mark as replied
                const data = tweetStore.get(tweet.id) || tweet;
                data.interactions = data.interactions || {};
                data.interactions.reply = true;
                tweetStore.set(tweet.id, data);
                
                // Also add to repliedUrls
                if (tweetUrl) {
                    const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                    const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                    const normalizedUrl = tweetUrl.split('?')[0].replace(/\/$/, '');
                    repliedUrls.add(normalizedUrl);
                    safeSetRepliedUrls(repliedUrls);
                }
                
                // Continue to next tweet
                return;
            }

            // SCREENING MECHANISM 2: Scan replies to check if current user has already replied
            // Wait additional 1 second for replies to load after scrolling
            await new Promise(resolve => setTimeout(resolve, 1000));
            try {
                const scanResponse = await sendMessageToActiveTab({ action: 'SCAN_REPLIES' });
                if (scanResponse && scanResponse.hasReplied) {
                    console.log(`[Screening Skip] Found own reply when scanning - marking as replied and skipping`);
                    aiStatusDiv.textContent = `跳过 - 扫描发现已回复`;
                    
                    // Mark as replied
                    const data = tweetStore.get(tweet.id) || tweet;
                    data.interactions = data.interactions || {};
                    data.interactions.reply = true;
                    tweetStore.set(tweet.id, data);
                    
                    // Also add to repliedUrls
                    if (tweetUrl) {
                        const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                        const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                        const normalizedUrl = tweetUrl.split('?')[0].replace(/\/$/, '');
                        repliedUrls.add(normalizedUrl);
                        safeSetRepliedUrls(repliedUrls);
                        console.log('[Screening Skip] Marked as replied (scan found own reply):', normalizedUrl);
                    }
                    
                    // Continue to next tweet
                    return;
                }
            } catch (scanError) {
                console.warn('[Screening] Failed to scan replies, continuing with normal flow:', scanError);
                // Continue with normal flow if scan fails
            }

            if (response && response.content) {
                tweetContent = response.content;
            }
        } catch (e) {
            console.warn('Failed to scrape content, using stored text:', e);
        }

        await waitUntilKOL24hUnpaused();
        if (!kolScanState.active || (kol24hReplyState && !kol24hReplyState.active)) return;

        // 4. Generate Reply
        // Use AI config systemPrompt directly
        let systemPrompt = aiConfig.systemPrompt || chrome.i18n.getMessage('default_system_prompt') || DEFAULT_SYSTEM_PROMPT;
        const reply = await callAI(aiConfig.provider, aiConfig.apiKey, systemPrompt, tweetContent);

        await waitUntilKOL24hUnpaused();
        if (!kolScanState.active || (kol24hReplyState && !kol24hReplyState.active)) return;

        // Use AI config autoLike and autoRepost directly
        let doLike = aiConfig.autoLike || false;
        let doRepost = aiConfig.autoRepost || false;

        if (reply) {
            // 5. Interact (Paste & Reply)
            console.log(`[KOL 24h] Sending reply: ${reply.substring(0, 50)}...`);
            const replyResult = await sendMessageToActiveTab({
                action: 'PASTE_AND_REPLY',
                text: reply,
                doLike: doLike,
                doRepost: doRepost
            });
            
            if (replyResult && replyResult.success === false) {
                console.error(`[KOL 24h] Failed to send reply:`, replyResult.error);
                // 继续处理下一条推文
                continue;
            }
            
            console.log(`[KOL 24h] Reply sent successfully`);

            await waitUntilKOL24hUnpaused();
            if (!kolScanState.active || (kol24hReplyState && !kol24hReplyState.active)) return;

            // Save Interaction
            const data = tweetStore.get(tweet.id) || tweet;
            data.interactions = data.interactions || {};
            data.interactions.reply = true;
            if (doLike) data.interactions.like = true;
            if (doRepost) data.interactions.retweet = true;
            data.replyText = reply;
            tweetStore.set(tweet.id, data);

            // Add to Daily Report
            addPostToReport({
                tweetId: tweet.id,
                kolName: tweet.username,
                kolLink: tweet.url,
                timestamp: tweet.timestamp,
                content: tweetContent,
                replyText: reply || '' // AI回复内容
            });

            // Auto-Archive (only if tweet is in list, skip for KOL 24h mode)
            if (!kol24hReplyState || !kol24hReplyState.active) {
                moveToArchive(tweet.id);
            } else {
                // For KOL 24h mode, just mark as archived in store
                const data = tweetStore.get(tweet.id) || tweet;
                data.status = 'archive';
                data.archivedAt = Date.now();
                tweetStore.set(tweet.id, data);
            }

            // Wait a bit (simulating typing/reading)
            await new Promise(r => setTimeout(r, 3000 + Math.random() * 2000));

            if (!kolScanState.active) return; // Check active state
        }
    }
}

// Close modal on outside click
if (confirmModal) {
    confirmModal.addEventListener('click', (e) => {
        if (e.target === confirmModal) {
            hideConfirmModal();
        }
    });
}

// --- Listeners using Modal ---

if (deleteAllArchiveBtn) {
    deleteAllArchiveBtn.addEventListener('click', () => {
        showConfirmModal(
            chrome.i18n.getMessage('modal_delete_all_title'),
            chrome.i18n.getMessage('modal_delete_all_msg'),
            chrome.i18n.getMessage('btn_yes_delete_all'),
            () => {
                const archiveItems = Array.from(tweetStore.values()).filter(t => t.status === 'archive');

                // Move to Trash logic
                archiveItems.forEach(item => {
                    const data = tweetStore.get(item.id);
                    data.status = 'trash';
                    data.deletedAt = Date.now();
                    tweetStore.set(item.id, data);
                });

                // Clear UI
                archiveList.innerHTML = '';
                checkEmptyState(archiveList);
                saveTweets(); // Persist changes

                // Hide menu
                fabActions.classList.add('hidden');
            }
        );
    });
}

clearScannerBtn.addEventListener('click', () => {
    showConfirmModal(
        chrome.i18n.getMessage('modal_clear_scanner_title'),
        chrome.i18n.getMessage('modal_clear_scanner_msg'),
        chrome.i18n.getMessage('btn_yes_clear_list'),
        () => {
            const cards = scannerList.querySelectorAll('.tweet-card');
            cards.forEach(c => {
                const id = c.dataset.id;
                tweetStore.delete(id);
                c.remove();
            });
            checkEmptyState(scannerList);
            saveTweets(); // Persist changes
        }
    );
});

emptyTrashBtn.addEventListener('click', () => {
    showConfirmModal(
        chrome.i18n.getMessage('modal_empty_trash_title'),
        chrome.i18n.getMessage('confirm_delete_all_trash'),
        chrome.i18n.getMessage('btn_yes_empty_trash'),
        () => {
            const cards = trashList.querySelectorAll('.tweet-card');
            cards.forEach(c => {
                const id = c.dataset.id;
                tweetStore.delete(id);
                c.remove();
            });
            checkEmptyState(trashList);
            saveTweets(); // Persist changes
        }
    );
});

function exportToCSV() {
    const archiveItems = Array.from(tweetStore.values()).filter(t => t.status === 'archive');

    if (archiveItems.length === 0) {
        alert('No archived tweets to export.');
        return;
    }

    // Columns: Blogger Name (Username), Link, Reply, Retweet, Like, Time
    const headers = ['Username', 'Link', 'Reply', 'Retweet', 'Like', 'Time'];
    const rows = archiveItems.map(item => {
        const time = new Date(item.timestamp).toLocaleString();

        return [
            item.username,
            item.url,
            item.interactions.reply ? '✅' : '❌',
            item.interactions.retweet ? '✅' : '❌',
            item.interactions.like ? '✅' : '❌',
            time
        ].map(field => `"${field}"`).join(','); // Quote fields
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `x_link_collector_archive_${Date.now()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// --- UI Logic ---

function addTweetCard(tweetData, container) {
    const card = document.createElement('div');
    card.className = 'tweet-card';
    card.dataset.timestamp = tweetData.timestamp;
    card.dataset.id = tweetData.id;
    if (tweetData.addedAt) card.dataset.addedAt = tweetData.addedAt;
    if (tweetData.archivedAt) card.dataset.archivedAt = tweetData.archivedAt;

    const date = new Date(tweetData.timestamp);
    const formattedDate = date.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });

    // Fallback for missing username
    let displayUsername = tweetData.username;
    if (!displayUsername) {
        // Try to extract from URL
        const match = tweetData.url.match(/(?:twitter\.com|x\.com)\/([^\/]+)\/status\//);
        if (match) {
            displayUsername = match[1];
        } else {
            displayUsername = "Unknown";
        }
    }

    // Determine Action Button
    let actionBtnIcon, actionBtnTitle, actionBtnClass;

    if (container === scannerList) {
        actionBtnIcon = ICONS.add;
        actionBtnTitle = "Add to List";
        actionBtnClass = "add-btn";
    } else if (container === listList) {
        actionBtnIcon = ICONS.archive;
        actionBtnTitle = "Archive";
        actionBtnClass = "archive-btn";
    } else if (container === archiveList) {
        actionBtnIcon = ICONS.unarchive;
        actionBtnTitle = "Unarchive";
        actionBtnClass = "unarchive-btn";
    } else { // Trash
        actionBtnIcon = ICONS.restore;
        actionBtnTitle = "Restore";
        actionBtnClass = "restore-btn";
    }

    const replyActive = tweetData.interactions.reply ? 'active' : '';
    const retweetActive = tweetData.interactions.retweet ? 'active' : '';
    const likeActive = tweetData.interactions.like ? 'active' : '';

    card.innerHTML = `
    <div class="tweet-header-row">
      <span class="username">@${displayUsername}</span>
      <span class="timestamp">${formattedDate}</span>
      <div class="header-spacer"></div>
      <div class="action-btn-group">
        <button class="icon-btn ${actionBtnClass}" title="${actionBtnTitle}">${actionBtnIcon}</button>
        <button class="icon-btn delete-btn" title="Delete">${ICONS.trash}</button>
      </div>
    </div>
    <a href="${tweetData.url}" target="_blank" class="tweet-content-link">
      <div class="tweet-link">${tweetData.url}</div>
    </a>
    <div class="tweet-actions">
      <div class="trash-countdown-container"></div>
      <div class="interaction-group">
        <button class="interaction-btn reply ${replyActive}" title="Replied" data-type="reply">${ICONS.reply}</button>
        <button class="interaction-btn retweet ${retweetActive}" title="Retweeted" data-type="retweet">${ICONS.retweet}</button>
        <button class="interaction-btn like ${likeActive}" title="Liked" data-type="like">${ICONS.like}</button>
      </div>
    </div>
`;

    // Insert Logic
    if (container === scannerList) {
        insertSorted(container, card, 'time');
    } else if (container === listList) {
        insertSorted(container, card, currentListSort, 'addedAt');
    } else if (container === archiveList) {
        insertSorted(container, card, currentArchiveSort, 'archivedAt');
    } else {
        // Trash: Sort by deletedAt (newest deleted first)
        container.prepend(card);

        // Add Countdown for Trash
        const deletedAt = tweetData.deletedAt || Date.now();
        const retentionMs = 30 * 24 * 60 * 60 * 1000; // 30 days
        const expiresAt = deletedAt + retentionMs;
        const msRemaining = expiresAt - Date.now();
        const daysRemaining = Math.max(0, Math.ceil(msRemaining / (24 * 60 * 60 * 1000)));

        // Insert into Countdown Container
        const countdownContainer = card.querySelector('.trash-countdown-container');
        if (countdownContainer) {
            const countdownDiv = document.createElement('div');
            countdownDiv.className = 'trash-countdown';
            // Use icon + text: ⏳ 30D
            countdownDiv.innerHTML = `⏳ ${daysRemaining} D`;
            countdownContainer.appendChild(countdownDiv);
        }
    }

    // Event Listeners
    const deleteBtn = card.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (container === trashList) {
            // Permanent Delete
            if (confirm(chrome.i18n.getMessage('confirm_delete_tweet'))) {
                card.remove();
                tweetStore.delete(tweetData.id);
                checkEmptyState(container);
            }
        } else {
            // Move to Trash
            moveToTrash(tweetData.id, card);
        }
    });

    const actionBtn = card.querySelector(`.${actionBtnClass} `);
    actionBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (container === scannerList) {
            moveToList(tweetData.id, card);
        } else if (container === listList) {
            moveToArchive(tweetData.id, card);
        } else if (container === archiveList) {
            unarchiveToList(tweetData.id, card);
        } else if (container === trashList) {
            restoreFromTrash(tweetData.id, card);
        }
    });

    const interactionBtns = card.querySelectorAll('.interaction-btn');
    interactionBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const type = btn.dataset.type;
            btn.classList.toggle('active');
            const currentData = tweetStore.get(tweetData.id);
            if (currentData) {
                currentData.interactions[type] = btn.classList.contains('active');
                tweetStore.set(tweetData.id, currentData);
                saveTweets(); // Persist interaction changes
            }
        });
    });
}

function insertSorted(container, card, mode, timeKey) {
    const children = Array.from(container.children).filter(c => c.classList.contains('tweet-card'));
    let value, nextSibling;

    if (mode === 'time') {
        value = parseInt(card.dataset.timestamp);
        nextSibling = children.find(child => parseInt(child.dataset.timestamp) < value);
    } else {
        value = parseInt(card.dataset[timeKey] || 0);
        nextSibling = children.find(child => parseInt(child.dataset[timeKey] || 0) < value);
    }

    if (nextSibling) {
        container.insertBefore(card, nextSibling);
    } else {
        container.appendChild(card);
    }
}

// --- Action Functions ---

// Helper: Sync a single tweet to Google Sheets 'list' sheet
function syncTweetToListSheet(tweet) {
    if (!googleSheetsConfig.scriptUrl) return;
    // Use the syncToGoogleSheets function with 'list' sheet and single tweet array
    syncToGoogleSheets([tweet]);
}

function moveToList(id, card) {
    const data = tweetStore.get(id);
    if (!data) return;
    data.status = 'list';
    data.addedAt = Date.now();
    tweetStore.set(id, data);
    card.remove();
    checkEmptyState(scannerList);
    addTweetCard(data, listList);
    removeEmptyState(listList);
    saveTweets(); // Persist changes

    // Auto-sync to Google Sheets 'list' sheet
    syncTweetToListSheet(data);
}

function moveToArchive(id, card) {
    const data = tweetStore.get(id);
    if (!data) return;

    // If card not provided, try to find it in the list
    if (!card) {
        // 使用转义的选择器，避免ID中的特殊字符问题
        try {
            card = listList.querySelector(`.tweet-card[data-id="${CSS.escape(String(id))}"]`);
        } catch (e) {
            // 如果CSS.escape不支持，使用querySelectorAll遍历
            const cards = listList.querySelectorAll('.tweet-card');
            card = Array.from(cards).find(c => c.dataset.id === String(id));
        }
    }

    data.status = 'archive';
    data.archivedAt = Date.now();
    tweetStore.set(id, data);

    if (card) {
        card.remove();
        checkEmptyState(listList);
    }

    addTweetCard(data, archiveList);
    removeEmptyState(archiveList);
    saveTweets(); // Persist changes

    // Auto-sync to Google Sheets 'archive' sheet
    if (googleSheetsConfig.scriptUrl) {
        syncToGoogleSheets([data]);
    }
}

function unarchiveToList(id, card) {
    const data = tweetStore.get(id);
    if (!data) return;
    data.status = 'list';
    data.archivedAt = 0;
    tweetStore.set(id, data);
    card.remove();
    checkEmptyState(archiveList);
    addTweetCard(data, listList);
    removeEmptyState(listList);
    saveTweets(); // Persist changes

    // Auto-sync to Google Sheets 'list' sheet
    syncTweetToListSheet(data);
}

function moveToTrash(id, card) {
    const data = tweetStore.get(id);
    if (!data) return;

    // Animation
    card.classList.add('fly-to-trash');

    // Wait for animation
    setTimeout(() => {
        const previousStatus = data.status; // Save for undo

        data.status = 'trash';
        data.deletedAt = Date.now();
        tweetStore.set(id, data);

        card.remove();
        // Check empty state for the container the card came from
        checkEmptyState(card.parentElement || scannerList || listList || archiveList); // Fallback

        // Show Undo Toast
        showUndoToast(id, previousStatus);
        saveTweets(); // Persist changes
    }, 400);
}

function restoreFromTrash(id, card) {
    const data = tweetStore.get(id);
    if (!data) return;

    // Default restore to List? Or Scanner?
    // Let's restore to List as it's the safest middle ground, or Scanner if it was never added?
    // Simplest is restore to List.
    data.status = 'list';
    data.deletedAt = 0;
    data.addedAt = Date.now(); // Treat as newly added
    tweetStore.set(id, data);

    card.remove();
    checkEmptyState(trashList);
    addTweetCard(data, listList);
    removeEmptyState(listList);
    saveTweets(); // Persist changes

    // Auto-sync to Google Sheets 'list' sheet
    syncTweetToListSheet(data);
}

function renderTrash() {
    trashList.innerHTML = '<div class="empty-state">Trash is empty.</div>';
    const trashItems = Array.from(tweetStore.values()).filter(t => t.status === 'trash');

    if (trashItems.length > 0) {
        removeEmptyState(trashList);
        // Sort by deletedAt desc
        trashItems.sort((a, b) => b.deletedAt - a.deletedAt);
        trashItems.forEach(item => addTweetCard(item, trashList));
    }
}

// --- Undo Logic ---
function showUndoToast(id, previousStatus) {
    lastDeletedTweetId = id;
    lastDeletedTweetStatus = previousStatus; // Store status
    undoToast.classList.add('show');

    // Clear previous timeout
    if (undoTimeout) clearTimeout(undoTimeout);

    // Auto hide after 5s
    undoTimeout = setTimeout(() => {
        undoToast.classList.remove('show');
        lastDeletedTweetId = null;
        lastDeletedTweetStatus = null;
    }, 5000);
}

undoBtn.addEventListener('click', () => {
    if (!lastDeletedTweetId) return;

    const data = tweetStore.get(lastDeletedTweetId);
    if (data && data.status === 'trash') {
        // Restore to previous status
        data.status = lastDeletedTweetStatus || 'list'; // Use stored status
        data.deletedAt = 0;
        tweetStore.set(lastDeletedTweetId, data);

        // If we are in Trash view, re-render to remove it
        if (viewTrash.classList.contains('active')) {
            renderTrash();
        } else {
            // If we are in the view it belongs to, add it back
            const targetList = getListByStatus(data.status);
            if (targetList) {
                // We need to check if it's already there? No, it was removed.
                addTweetCard(data, targetList);
                removeEmptyState(targetList);
            }
        }
    }

    undoToast.classList.remove('show');
    lastDeletedTweetId = null;
    lastDeletedTweetStatus = null;
    saveTweets(); // Persist changes
});

function getListByStatus(status) {
    if (status === 'scanner') return scannerList;
    if (status === 'list') return listList;
    if (status === 'archive') return archiveList;
    return null;
}

function removeEmptyState(container) {
    const emptyState = container.querySelector('.empty-state');
    if (emptyState) {
        emptyState.style.display = 'none';
    }
}

function checkEmptyState(container) {
    // If container is null (e.g. detached element), ignore
    if (!container) return;

    const hasCards = container.querySelector('.tweet-card');
    const emptyState = container.querySelector('.empty-state');
    if (!hasCards && emptyState) {
        emptyState.style.display = 'block';
    }
}

// --- Communication ---
// --- Notification Logic ---
const notificationToast = document.getElementById('notificationToast');
let notificationTimeout = null;

function showNotification(message, isError = true) {
    if (!notificationToast) return;

    const span = notificationToast.querySelector('span');
    if (span) span.textContent = message;

    notificationToast.style.backgroundColor = isError ? '#f4212e' : '#1d9bf0'; // Red or Blue
    notificationToast.classList.add('show');

    if (notificationTimeout) clearTimeout(notificationTimeout);

    notificationTimeout = setTimeout(() => {
        notificationToast.classList.remove('show');
    }, 3000);
}

// --- Communication ---
async function sendMessageToActiveTab(message) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
        try {
            const response = await chrome.tabs.sendMessage(tab.id, message);
            return response; // Return actual response
        } catch (e) {
            // Suppress connection errors (content script not ready or async response timeout)
            if (!e.message.includes("Receiving end does not exist") &&
                !e.message.includes("Could not establish connection") &&
                !e.message.includes("message channel closed")) {
                console.error("Could not send message to tab:", e);
            }
            return false; // Failure
        }
    } else {
        return false; // No tab
    }
}

// Scanner State
let isScanning = false;
let scannerTimeoutId = null;
const MAX_SCAN_TIME_MS = 10 * 60 * 1000; // 10 minutes

// Function to stop scanning (reusable)
async function stopScanning() {
    if (!isScanning) return;

    const success = await sendMessageToActiveTab({ action: 'STOP_LISTENING' });
    if (success) {
        isScanning = false;
        startBtn.classList.remove('active-state');
        startBtn.innerHTML = chrome.i18n.getMessage('btn_scan');

        // Stop auto-scrolling
        await sendMessageToActiveTab({ action: 'STOP_SCANNER_SCROLL' });

        // Clear timeout if exists
        if (scannerTimeoutId) {
            clearTimeout(scannerTimeoutId);
            scannerTimeoutId = null;
        }

        // Auto-sync scanned tweets to Google Sheets
        const scannedTweets = Array.from(tweetStore.values()).filter(t => t.status === 'scanner');
        if (scannedTweets.length > 0 && googleSheetsConfig.scriptUrl) {
            showNotification(`正在同步 ${scannedTweets.length} 条扫描推文到 Sheets...`, false);
            syncToGoogleSheets(scannedTweets);
        }
    }
}

startBtn.addEventListener('click', async () => {
    if (!isScanning) {
        // Start Scanning
        const success = await sendMessageToActiveTab({ action: 'START_LISTENING' });
        if (success) {
            isScanning = true;
            startBtn.classList.add('active-state');

            // Set animated text
            startBtn.innerHTML = `
    <div class="scanning-text">
                <span>S</span><span>c</span><span>a</span><span>n</span><span>n</span><span>i</span><span>n</span><span>g</span>
              </div>
    `;

            // Start auto-scrolling
            await sendMessageToActiveTab({ action: 'START_SCANNER_SCROLL' });

            // Set 10-minute auto-stop timer
            scannerTimeoutId = setTimeout(async () => {
                showNotification('扫描已自动停止（达到10分钟上限）', false);
                await stopScanning();
            }, MAX_SCAN_TIME_MS);
        } else {
            showNotification('Please refresh the X page.', true);
        }
    } else {
        // Stop Scanning manually
        await stopScanning();
    }
});

// Remove stopBtn listener as it's deleted
// stopBtn.addEventListener('click', ...);



// --- AI Logic ---

const aiProviderSelect = document.getElementById('aiProvider');
const aiApiKeyInput = document.getElementById('aiApiKey');
const aiApiUrlInput = document.getElementById('aiApiUrl');
const aiSystemPromptInput = document.getElementById('aiSystemPrompt');
const aiMaxTweetAgeInput = document.getElementById('aiMaxTweetAge');
const aiAutoLikeCheckbox = document.getElementById('aiAutoLike');
const aiAutoRepostCheckbox = document.getElementById('aiAutoRepost');
const aiActiveHoursStartInput = document.getElementById('aiActiveHoursStart');
const aiActiveHoursEndInput = document.getElementById('aiActiveHoursEnd');
const aiAllDayCheckbox = document.getElementById('aiAllDay');
const aiReplyDelayMinInput = document.getElementById('aiReplyDelayMin');
const aiReplyDelayMaxInput = document.getElementById('aiReplyDelayMax');
const aiLikeDelayMinInput = document.getElementById('aiLikeDelayMin');
const aiLikeDelayMaxInput = document.getElementById('aiLikeDelayMax');
const aiPostReplyWaitMinInput = document.getElementById('aiPostReplyWaitMin');
const aiPostReplyWaitMaxInput = document.getElementById('aiPostReplyWaitMax');
const aiPageLoadWaitMinInput = document.getElementById('aiPageLoadWaitMin');
const aiPageLoadWaitMaxInput = document.getElementById('aiPageLoadWaitMax');
const aiKolMaxTweetsPerKolInput = document.getElementById('aiKolMaxTweetsPerKol');
const aiAutoRunCheckbox = document.getElementById('aiAutoRun');
const aiAutoRunIntervalInput = document.getElementById('aiAutoRunInterval');
const saveAutoRunBtn = document.getElementById('saveAutoRunBtn');
const aiSettingsToggle = document.getElementById('aiSettingsToggle');
const aiSettingsContainer = document.getElementById('aiSettingsContainer');
const startAIBtn = document.getElementById('startAIBtn');
const pauseAIBtn = document.getElementById('pauseAIBtn');
const resumeAIBtn = document.getElementById('resumeAIBtn');
const stopAIBtn = document.getElementById('stopAIBtn');
const aiBtnDropdown = document.querySelector('.ai-btn-dropdown');
const aiBtnContainer = document.querySelector('.ai-btn-container');
const aiStatusDiv = document.getElementById('aiStatus');

// Comment Reply UI Elements
const startCommentReplyBtn = document.getElementById('startCommentReplyBtn');
const pauseCommentReplyBtn = document.getElementById('pauseCommentReplyBtn');
const stopCommentReplyBtn = document.getElementById('stopCommentReplyBtn');
const commentReplyProfileUrlInput = document.getElementById('commentReplyProfileUrl');
const commentReplyMaxTweetsInput = document.getElementById('commentReplyMaxTweets');
const commentReplyMaxCommentsInput = document.getElementById('commentReplyMaxComments');
const commentReplySystemPromptInput = document.getElementById('commentReplySystemPrompt');




// Initialize Inputs
if (aiProviderSelect) {
    aiProviderSelect.value = aiConfig.provider;
    aiApiKeyInput.value = aiConfig.apiKey;
    if (aiApiUrlInput) {
        aiApiUrlInput.value = aiConfig.apiUrl || '';
    }
    if (aiSystemPromptInput) {
        aiSystemPromptInput.value = aiConfig.systemPrompt || '';
    }
    if (aiMaxTweetAgeInput) {
        aiMaxTweetAgeInput.value = aiConfig.maxTweetAge || 24;
    }
    if (aiAutoLikeCheckbox) {
        aiAutoLikeCheckbox.checked = aiConfig.autoLike;
    }
    if (aiAutoRepostCheckbox) {
        aiAutoRepostCheckbox.checked = aiConfig.autoRepost;
    }
    if (aiActiveHoursStartInput) {
        aiActiveHoursStartInput.value = aiConfig.activeHoursStart || '08:00';
    }
    if (aiActiveHoursEndInput) {
        aiActiveHoursEndInput.value = aiConfig.activeHoursEnd || '23:00';
    }
    if (aiAllDayCheckbox) {
        aiAllDayCheckbox.checked = aiConfig.allDay;
    }
    if (aiReplyDelayMinInput) aiReplyDelayMinInput.value = aiConfig.replyDelayMin;
    if (aiReplyDelayMaxInput) aiReplyDelayMaxInput.value = aiConfig.replyDelayMax;
    if (aiLikeDelayMinInput) aiLikeDelayMinInput.value = aiConfig.likeDelayMin;
    if (aiLikeDelayMaxInput) aiLikeDelayMaxInput.value = aiConfig.likeDelayMax;
    if (aiPostReplyWaitMinInput) aiPostReplyWaitMinInput.value = aiConfig.postReplyWaitMin;
    if (aiPostReplyWaitMaxInput) aiPostReplyWaitMaxInput.value = aiConfig.postReplyWaitMax;
    if (aiPageLoadWaitMinInput) aiPageLoadWaitMinInput.value = aiConfig.pageLoadWaitMin;
    if (aiPageLoadWaitMaxInput) aiPageLoadWaitMaxInput.value = aiConfig.pageLoadWaitMax;
    if (aiKolMaxTweetsPerKolInput) aiKolMaxTweetsPerKolInput.value = aiConfig.kolMaxTweetsPerKol;
    if (aiAutoRunCheckbox) aiAutoRunCheckbox.checked = aiConfig.autoRunEnabled;
    if (aiAutoRunIntervalInput) aiAutoRunIntervalInput.value = aiConfig.autoRunInterval;

    // Listeners
    aiProviderSelect.addEventListener('change', (e) => {
        aiConfig.provider = e.target.value;
        localStorage.setItem('aiProvider', aiConfig.provider);
    });

    aiApiKeyInput.addEventListener('input', (e) => {
        aiConfig.apiKey = e.target.value;
        localStorage.setItem('aiApiKey', aiConfig.apiKey);
    });

    if (aiApiUrlInput) {
        aiApiUrlInput.addEventListener('input', (e) => {
            aiConfig.apiUrl = e.target.value;
            localStorage.setItem('aiApiUrl', aiConfig.apiUrl);
        });
    }

    if (aiSystemPromptInput) {
        aiSystemPromptInput.addEventListener('input', (e) => {
            aiConfig.systemPrompt = e.target.value;
            localStorage.setItem('aiSystemPrompt', aiConfig.systemPrompt);
        });
    }

    if (aiMaxTweetAgeInput) {
        aiMaxTweetAgeInput.addEventListener('input', (e) => {
            aiConfig.maxTweetAge = parseInt(e.target.value) || 24;
            localStorage.setItem('aiMaxTweetAge', aiConfig.maxTweetAge);
        });
    }

    // Comment Reply Configuration
    // 检查 commentReplyState 是否已定义（从 comment-reply.js）
    if (typeof commentReplyState !== 'undefined') {
        if (commentReplyProfileUrlInput) {
            commentReplyProfileUrlInput.value = commentReplyState.profileUrl || 'https://x.com/WWTLitee';
            commentReplyProfileUrlInput.addEventListener('input', (e) => {
                commentReplyState.profileUrl = e.target.value.trim();
                if (typeof saveCommentReplyConfig === 'function') {
                    saveCommentReplyConfig();
                }
            });
        }

        if (commentReplyMaxTweetsInput) {
            commentReplyMaxTweetsInput.value = commentReplyState.maxTweets || 20;
            commentReplyMaxTweetsInput.addEventListener('input', (e) => {
                commentReplyState.maxTweets = parseInt(e.target.value) || 20;
                if (typeof saveCommentReplyConfig === 'function') {
                    saveCommentReplyConfig();
                }
            });
        }

        if (commentReplyMaxCommentsInput) {
            commentReplyMaxCommentsInput.value = commentReplyState.maxCommentsPerTweet || 30;
            commentReplyMaxCommentsInput.addEventListener('input', (e) => {
                commentReplyState.maxCommentsPerTweet = parseInt(e.target.value) || 30;
                if (typeof saveCommentReplyConfig === 'function') {
                    saveCommentReplyConfig();
                }
            });
        }

        if (commentReplySystemPromptInput) {
            commentReplySystemPromptInput.value = commentReplyState.systemPrompt || '';
            commentReplySystemPromptInput.addEventListener('input', (e) => {
                commentReplyState.systemPrompt = e.target.value.trim();
                if (typeof saveCommentReplyConfig === 'function') {
                    saveCommentReplyConfig();
                }
            });
        }
    } else {
        console.warn('[Sidepanel] commentReplyState not defined - comment-reply.js may not be loaded');
    }

    // Comment Reply Button Events
    if (typeof commentReplyState !== 'undefined') {
        if (startCommentReplyBtn) {
            startCommentReplyBtn.addEventListener('click', () => {
                if (typeof startCommentReply === 'function') {
                    if (!commentReplyState.active) {
                        startCommentReply();
                    }
                }
            });
        }

        if (pauseCommentReplyBtn) {
            pauseCommentReplyBtn.addEventListener('click', () => {
                if (typeof togglePauseCommentReply === 'function') {
                    togglePauseCommentReply();
                }
            });
        }

        if (stopCommentReplyBtn) {
            stopCommentReplyBtn.addEventListener('click', () => {
                if (typeof stopCommentReply === 'function') {
                    stopCommentReply();
                }
            });
        }
    }

    if (aiAutoLikeCheckbox) {
        aiAutoLikeCheckbox.addEventListener('change', (e) => {
            aiConfig.autoLike = e.target.checked;
            localStorage.setItem('aiAutoLike', aiConfig.autoLike);
        });
    }

    if (aiAutoRepostCheckbox) {
        aiAutoRepostCheckbox.addEventListener('change', (e) => {
            aiConfig.autoRepost = e.target.checked;
            localStorage.setItem('aiAutoRepost', aiConfig.autoRepost);
        });
    }

    if (aiActiveHoursStartInput) {
        aiActiveHoursStartInput.addEventListener('change', (e) => {
            aiConfig.activeHoursStart = e.target.value;
            localStorage.setItem('aiActiveHoursStart', aiConfig.activeHoursStart);
        });
    }

    if (aiActiveHoursEndInput) {
        aiActiveHoursEndInput.addEventListener('change', (e) => {
            aiConfig.activeHoursEnd = e.target.value;
            localStorage.setItem('aiActiveHoursEnd', aiConfig.activeHoursEnd);
        });
    }

    if (aiAllDayCheckbox) {
        aiAllDayCheckbox.addEventListener('change', (e) => {
            aiConfig.allDay = e.target.checked;
            localStorage.setItem('aiAllDay', aiConfig.allDay);
        });
    }
}

aiReplyDelayMinInput.addEventListener('input', (e) => {
    aiConfig.replyDelayMin = e.target.value;
    localStorage.setItem('aiReplyDelayMin', aiConfig.replyDelayMin);
});

aiReplyDelayMaxInput.addEventListener('input', (e) => {
    aiConfig.replyDelayMax = e.target.value;
    localStorage.setItem('aiReplyDelayMax', aiConfig.replyDelayMax);
});

aiLikeDelayMinInput.addEventListener('input', (e) => {
    aiConfig.likeDelayMin = e.target.value;
    localStorage.setItem('aiLikeDelayMin', aiConfig.likeDelayMin);
});

if (aiLikeDelayMaxInput) aiLikeDelayMaxInput.addEventListener('input', (e) => {
    aiConfig.likeDelayMax = e.target.value;
    localStorage.setItem('aiLikeDelayMax', aiConfig.likeDelayMax);
});
if (aiPostReplyWaitMinInput) aiPostReplyWaitMinInput.addEventListener('input', (e) => {
    aiConfig.postReplyWaitMin = e.target.value;
    localStorage.setItem('aiPostReplyWaitMin', aiConfig.postReplyWaitMin);
});
if (aiPostReplyWaitMaxInput) aiPostReplyWaitMaxInput.addEventListener('input', (e) => {
    aiConfig.postReplyWaitMax = e.target.value;
    localStorage.setItem('aiPostReplyWaitMax', aiConfig.postReplyWaitMax);
});
if (aiPageLoadWaitMinInput) aiPageLoadWaitMinInput.addEventListener('input', (e) => {
    aiConfig.pageLoadWaitMin = e.target.value;
    localStorage.setItem('aiPageLoadWaitMin', aiConfig.pageLoadWaitMin);
});
if (aiPageLoadWaitMaxInput) aiPageLoadWaitMaxInput.addEventListener('input', (e) => {
    aiConfig.pageLoadWaitMax = e.target.value;
    localStorage.setItem('aiPageLoadWaitMax', aiConfig.pageLoadWaitMax);
});
if (aiKolMaxTweetsPerKolInput) {
    aiKolMaxTweetsPerKolInput.addEventListener('input', (e) => {
        const v = parseInt(e.target.value, 10);
        if (!isNaN(v) && v >= 0 && v <= 20) {
            aiConfig.kolMaxTweetsPerKol = v;
            localStorage.setItem('aiKolMaxTweetsPerKol', String(v));
        }
    });
}

// Auto-Run inputs NO LONGER auto-save on input.
// They are saved when "Save" is clicked.

if (saveAutoRunBtn) {
    saveAutoRunBtn.addEventListener('click', () => {
        aiConfig.autoRunEnabled = aiAutoRunCheckbox.checked;
        // aiConfig.autoRunStart removed
        // aiConfig.autoRunEnd removed
        aiConfig.autoRunInterval = parseInt(aiAutoRunIntervalInput.value);
        localStorage.setItem('aiAutoRunEnabled', aiConfig.autoRunEnabled);
        localStorage.setItem('aiAutoRunInterval', aiConfig.autoRunInterval);

        showNotification(chrome.i18n.getMessage('notification_cycle_settings_saved'), false);

        // Reset stoppedByUser so it can run again if conditions met
        aiProcessState.stoppedByUser = false;
    });
}


// --- AI Cycle Logic ---

let aiCycleState = {
    active: false,
    groups: [],
    currentGroupIndex: 0,
    isRunning: false
};

async function startAICycle() {
    if (!aiConfig.apiKey) {
        showNotification(chrome.i18n.getMessage('notification_api_key_required'), true);
        return;
    }

    // Sync Auto-Run State
    if (aiAutoRunCheckbox) {
        aiConfig.autoRunEnabled = aiAutoRunCheckbox.checked;
        localStorage.setItem('aiAutoRunEnabled', aiConfig.autoRunEnabled);
    }

    // Check active hours
    if (!aiConfig.allDay) {
        const now = new Date();
        const currentMinutes = now.getHours() * 60 + now.getMinutes();
        const [startH, startM] = (aiConfig.activeHoursStart || '08:00').split(':').map(Number);
        const [endH, endM] = (aiConfig.activeHoursEnd || '23:00').split(':').map(Number);
        const startMinutes = startH * 60 + startM;
        const endMinutes = endH * 60 + endM;
        
        if (currentMinutes < startMinutes || currentMinutes > endMinutes) {
            showNotification(`当前不在活跃时间内 (${aiConfig.activeHoursStart} - ${aiConfig.activeHoursEnd})`, true);
            return;
        }
    }

    // 检查是否需要自动加载Google表格数据（无 URL 时也会用默认表格加载）
    if (sheetsTweetsStore.size === 0) {
        if (!sheetsUrl || !String(sheetsUrl).trim()) {
            applyDefaultSheetsUrl();
        }
        aiStatusDiv.textContent = '正在自动加载Google表格数据...';
        showNotification('正在自动加载Google表格数据...', false);
        
        try {
            await loadTweetsFromSheets();
            // 加载完成后继续
            if (sheetsTweetsStore.size === 0) {
                showNotification('表格数据为空，无法开始回复', true);
                return;
            }
            showNotification(`已自动加载 ${sheetsTweetsStore.size} 条推文，开始回复...`, false);
        } catch (error) {
            console.error('Error auto-loading sheets:', error);
            showNotification('自动加载表格数据失败: ' + error.message, true);
            return;
        }
    }

    aiProcessState.active = true;
    aiProcessState.inCycle = aiConfig.autoRunEnabled;
    aiProcessState.stoppedByUser = false;

    // UI：只显示暂停+停止，隐藏主按钮
    if (startAIBtn) {
        startAIBtn.style.display = 'none';
        startAIBtn.disabled = false;
    }
    if (pauseAIBtn) {
        pauseAIBtn.style.display = 'inline-block';
        pauseAIBtn.textContent = '暂停';
    }
    if (stopAIBtn) stopAIBtn.style.display = 'inline-block';
    aiStatusDiv.textContent = chrome.i18n.getMessage('status_cycle_started');

    // Directly start reply phase (no group processing)
    startAIReplyPhase();
}

// Removed processNextGroup and startKOLScanForGroup - now using direct AI config

function startAIReplyPhase() {
    if (!aiProcessState.active || aiProcessState.paused) {
        console.log('AI stopped or paused, not starting reply phase');
        return;
    }

    aiStatusDiv.textContent = chrome.i18n.getMessage('status_cycle_replying');
    
    // Show progress status in KOLs view
    updateAIProgress(0, aiProcessState.list ? aiProcessState.list.length : 0, '准备开始回复...');

    // Use AI config directly (no group processing)
    const systemPrompt = aiConfig.systemPrompt || DEFAULT_SYSTEM_PROMPT;
    const replyDelayMin = parseInt(aiConfig.replyDelayMin);
    const replyDelayMax = parseInt(aiConfig.replyDelayMax);
    const likeDelayMin = parseInt(aiConfig.likeDelayMin);
    const likeDelayMax = parseInt(aiConfig.likeDelayMax);
    const autoLike = aiConfig.autoLike || false;
    const autoRepost = aiConfig.autoRepost || false;
    const maxTweetAge = parseInt(aiConfig.maxTweetAge || 24);

    let listItems = [];
    
    // Check if this is KOL 24h reply mode
    if (kol24hReplyState && kol24hReplyState.active) {
        // Get tweets from tweetStore (collected during KOL scan)
        const now = Date.now();
        const twentyFourHoursAgo = now - (24 * 60 * 60 * 1000); // Force 24h
        
        // Get replied tweet URLs and thread IDs from localStorage
        const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
        const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
        const repliedThreadIdsData = localStorage.getItem('repliedThreadIds');
        const repliedThreadIds = repliedThreadIdsData ? new Set(JSON.parse(repliedThreadIdsData)) : new Set();
        
        // Filter tweets: 24h, not replied, not in thread
        listItems = Array.from(tweetStore.values()).filter(t => {
            const isRecent = t.timestamp >= twentyFourHoursAgo;
            const isUnreplied = !repliedUrls.has(t.url || t.normalizedUrl);
            const isNotInThread = !repliedThreadIds.has(t.threadId || '');
            const hasNoReply = !t.interactions?.reply;
            return isRecent && isUnreplied && isNotInThread && hasNoReply;
        });
        
        console.log(`从KOL列表获取 ${listItems.length} 条24小时内的推文`);
        
        // Set list for AI processing
        aiProcessState.list = listItems;
        aiProcessState.currentIndex = 0;
        
        if (listItems.length === 0) {
            showNotification('没有找到24小时内的推文', true);
            if (kol24hReplyState.active) {
                stopKOL24hReply();
            }
            return;
        }
    }
    // Check if using Google Sheets as data source
    else if (sheetsUrl && sheetsTweetsStore.size > 0) {
        // Get tweets from Google Sheets
        const now = Date.now();
        const twentyFourHoursAgo = now - (maxTweetAge * 60 * 60 * 1000);
        
        // Get replied tweet URLs and thread IDs from localStorage
        const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
        const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
        const repliedThreadIdsData = localStorage.getItem('repliedThreadIds');
        const repliedThreadIds = repliedThreadIdsData ? new Set(JSON.parse(repliedThreadIdsData)) : new Set();
        
        // Helper function to extract thread ID from URL
        // Thread ID is the status ID in the URL: https://x.com/username/status/THREAD_ID
        function extractThreadId(url) {
            if (!url) return null;
            const match = url.match(/\/status\/(\d+)/);
            return match ? match[1] : null;
        }
        
        listItems = Array.from(sheetsTweetsStore.values())
            .map(sheetTweet => {
                // Extract tweet data from sheet
                const url = sheetTweet['推文链接'] || sheetTweet['Tweet Link'] || sheetTweet['url'] || '';
                const text = sheetTweet['推文全文'] || sheetTweet['Tweet Full Text'] || sheetTweet['fullText'] || '';
                const username = sheetTweet['用户名'] || sheetTweet['Username'] || sheetTweet['username'] || '';
                const authorName = sheetTweet['作者名'] || sheetTweet['Author Name'] || sheetTweet['authorName'] || username;
                const tweetId = sheetTweet['推文ID'] || sheetTweet['Tweet ID'] || sheetTweet['id'] || '';
                
                // Get timestamp
                let timestamp = null;
                if (sheetTweet['发布时间']) {
                    timestamp = new Date(sheetTweet['发布时间']).getTime();
                } else if (sheetTweet['Tweet Time'] || sheetTweet['Time']) {
                    timestamp = new Date(sheetTweet['Tweet Time'] || sheetTweet['Time']).getTime();
                } else if (tweetId) {
                    try {
                        const id = BigInt(tweetId);
                        timestamp = Number((id >> 22n) + 1288834974657n);
                    } catch (e) {
                        console.warn('无法解析推文ID时间:', tweetId);
                    }
                }
                
                // Normalize URL for deduplication
                const normalizedUrl = url.replace(/\/$/, '').split('?')[0];
                
                // Extract thread ID (the status ID in the URL)
                const threadId = extractThreadId(url) || tweetId;
                
                return {
                    id: tweetId || normalizedUrl,
                    url: url,
                    normalizedUrl: normalizedUrl,
                    threadId: threadId, // Add thread ID for thread deduplication
                    text: text,
                    fullText: text,
                    username: username,
                    authorName: authorName,
                    timestamp: timestamp || Date.now(),
                    scrapedAt: timestamp || Date.now(),
                    status: 'list',
                    fromSheets: true,
                    sheetData: sheetTweet
                };
            })
            .filter(t => {
                // Filter: 24 hours
                if (t.timestamp && t.timestamp < twentyFourHoursAgo) {
                    return false;
                }
                
                // Filter: Not already replied (by URL)
                if (repliedUrls.has(t.normalizedUrl)) {
                    return false;
                }
                
                // Filter: Not already replied (by thread ID) - CRITICAL: avoid replying to same thread
                if (t.threadId && repliedThreadIds.has(t.threadId)) {
                    console.log(`Skipping tweet - thread already replied: ${t.threadId}`);
                    return false;
                }
                
                // Filter: Main tweet only (not a reply)
                // Check if text starts with @username (reply indicator)
                const text = t.text || '';
                if (text.trim().match(/^@\w+\s/)) {
                    return false;
                }
                
                // Filter: Not too short (spam filter)
                if (text.length < 20) {
                    return false;
                }
                
                // Filter: Has URL
                if (!t.url || !t.url.includes('x.com/') && !t.url.includes('twitter.com/')) {
                    return false;
                }
                
                return true;
            });
        
        console.log(`从表格获取 ${listItems.length} 条符合条件的推文`);
    } else {
        // Use original tweetStore logic
        listItems = Array.from(tweetStore.values()).filter(t => {
        if (t.status !== 'list') return false;

        // Check Age
        const ageHours = (Date.now() - t.scrapedAt) / (1000 * 60 * 60);
        if (ageHours > maxTweetAge) return false;

        return true;
    });
    }

    if (listItems.length === 0) {
        console.log("No tweets to reply.");
        
        // Check if this was KOL 24h reply mode
        if (kol24hReplyState && kol24hReplyState.active) {
            showNotification('没有找到24小时内的推文', true);
            stopKOL24hReply();
            return;
        }
        
        // If in cycle, start snooze phase
        if (aiProcessState.inCycle) {
            startSnoozePhase();
        } else {
            stopAI();
        }
        return;
    }

    aiProcessState.list = listItems;
    aiProcessState.currentIndex = 0;

    // Store config for use in processNextAIReply
    aiProcessState.systemPrompt = systemPrompt;
    aiProcessState.autoLike = autoLike;
    aiProcessState.autoRepost = autoRepost;
    aiProcessState.replyDelayMin = replyDelayMin;
    aiProcessState.replyDelayMax = replyDelayMax;

    processNextAIReply();
}

function startSnoozePhase() {
    if (!aiProcessState.active) return;

    const intervalMinutes = aiConfig.autoRunInterval;
    const endTime = Date.now() + intervalMinutes * 60 * 1000;

    // Animated Button: Snoozing
    startAIBtn.innerHTML = `
    <div class="jumping-text">
            <span>S</span><span>n</span><span>o</span><span>o</span><span>z</span><span>i</span><span>n</span><span>g</span>
        </div>
    `;

    // Countdown Function
    const updateCountdown = () => {
        if (!aiProcessState.active) return;

        const remaining = endTime - Date.now();
        if (remaining <= 0) {
            aiStatusDiv.textContent = chrome.i18n.getMessage('status_restarting_cycle');
            return;
        }

        const hours = Math.floor(remaining / (1000 * 60 * 60));
        const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((remaining % (1000 * 60)) / 1000);

        const hStr = hours > 0 ? `${hours} h ` : '';
        const mStr = `${minutes} m `;
        const sStr = `${seconds} `;

        aiStatusDiv.textContent = chrome.i18n.getMessage('status_snoozing', [hStr + mStr + sStr]);
    };

    // Initial call
    updateCountdown();

    // Start Interval
    if (aiProcessState.countdownTimer) clearInterval(aiProcessState.countdownTimer);
    aiProcessState.countdownTimer = setInterval(updateCountdown, 1000);

    // Wait for interval (Timeout)
    if (aiProcessState.snoozeTimer) clearTimeout(aiProcessState.snoozeTimer);
    aiProcessState.snoozeTimer = setTimeout(() => {
        if (!aiProcessState.active) return;

        clearInterval(aiProcessState.countdownTimer);
        console.log("Snooze over, restarting cycle...");
        startAICycle(); // Restart loop
    }, intervalMinutes * 60 * 1000);
}

if (aiAutoRunIntervalInput) {
    aiAutoRunIntervalInput.addEventListener('input', (e) => {
        aiConfig.autoRunInterval = parseInt(e.target.value);
        localStorage.setItem('aiAutoRunInterval', aiConfig.autoRunInterval);
    });
}

// Hover-Stop Logic for Start AI Button
let dropdownHideTimeout = null;

// === KOL 24h Reply Function ===
const startKOL24hReplyBtn = document.getElementById('startKOL24hReplyBtn');
const pauseKOL24hReplyBtn = document.getElementById('pauseKOL24hReplyBtn');
const stopKOL24hReplyBtn = document.getElementById('stopKOL24hReplyBtn');

// Start KOL 24h Reply
async function startKOL24hReply() {
    if (!aiConfig.apiKey) {
        showNotification('请先配置AI设置', true);
        return;
    }

    let kols = Array.from(kolStore.values());
    if (kols.length === 0) {
        showNotification('请先添加KOL', true);
        return;
    }
    // 优先扫描间隔最长的 KOL：按上次扫描时间升序（未扫过的视为最早）
    kols.sort((a, b) => (a.lastScannedAt || 0) - (b.lastScannedAt || 0));

    // Save original maxTweetAge and set 24h limit temporarily
    kol24hReplyState.originalMaxTweetAge = aiConfig.maxTweetAge;
    aiConfig.maxTweetAge = 24; // Force 24h limit

    kol24hReplyState.active = true;
    kol24hReplyState.paused = false;

    // Update UI
    if (startKOL24hReplyBtn) {
        startKOL24hReplyBtn.style.display = 'none';
        startKOL24hReplyBtn.disabled = true;
    }
    if (pauseKOL24hReplyBtn) pauseKOL24hReplyBtn.style.display = 'inline-block';
    if (stopKOL24hReplyBtn) stopKOL24hReplyBtn.style.display = 'inline-block';

    // Show progress
    updateAIProgress(0, kols.length, '开始扫描KOL列表...', 'kol24h');

    // Start KOL scan with AI reply
    aiProcessState.active = true;
    aiProcessState.inCycle = false;
    aiProcessState.stoppedByUser = false;

    // Initialize KOL scan state
    kolScanState.active = true;
    kolScanState.kols = kols;
    kolScanState.currentIndex = 0;

    // Start scanning
    processNextKOL();
}

// Stop KOL 24h Reply
function stopKOL24hReply() {
    kol24hReplyState.active = false;
    kol24hReplyState.paused = false;
    
    // Restore original maxTweetAge
    if (kol24hReplyState.originalMaxTweetAge !== null) {
        aiConfig.maxTweetAge = kol24hReplyState.originalMaxTweetAge;
        kol24hReplyState.originalMaxTweetAge = null;
    }
    
    // Stop KOL scan
    if (kolScanState.active) {
        kolScanState.active = false;
        kolScanState.kols = [];
        kolScanState.currentIndex = 0;
        if (kolScanState.timerId) {
            clearTimeout(kolScanState.timerId);
            kolScanState.timerId = null;
        }
        if (kolScanState.intervalId) {
            clearInterval(kolScanState.intervalId);
            kolScanState.intervalId = null;
        }
    }
    
    // Stop AI process
    aiProcessState.active = false;

    // Update UI
    if (startKOL24hReplyBtn) {
        startKOL24hReplyBtn.style.display = 'inline-block';
        startKOL24hReplyBtn.disabled = false;
        startKOL24hReplyBtn.textContent = '回复kol列表';
    }
    if (pauseKOL24hReplyBtn) pauseKOL24hReplyBtn.style.display = 'none';
    if (stopKOL24hReplyBtn) stopKOL24hReplyBtn.style.display = 'none';

    hideGlobalProgress();

    showNotification('KOL 24h回复已停止', false);
}

// Pause KOL 24h Reply
function pauseKOL24hReply() {
    if (!kol24hReplyState.active || kol24hReplyState.paused) return;
    kol24hReplyState.paused = true;
    if (startKOL24hReplyBtn) {
        startKOL24hReplyBtn.style.display = 'inline-block';
        startKOL24hReplyBtn.disabled = false;
        startKOL24hReplyBtn.textContent = '继续';
    }
    if (pauseKOL24hReplyBtn) pauseKOL24hReplyBtn.style.display = 'none';
    showNotification('KOL 24h回复已暂停', false);
}

// Resume KOL 24h Reply
function resumeKOL24hReply() {
    if (!kol24hReplyState.active || !kol24hReplyState.paused) return;
    kol24hReplyState.paused = false;
    if (startKOL24hReplyBtn) {
        startKOL24hReplyBtn.style.display = 'none';
        startKOL24hReplyBtn.textContent = '回复kol列表';
    }
    if (pauseKOL24hReplyBtn) pauseKOL24hReplyBtn.style.display = 'inline-block';
    processNextKOL();
}

// Wire up KOL 24h Reply buttons
if (startKOL24hReplyBtn) {
    startKOL24hReplyBtn.addEventListener('click', () => {
        if (kol24hReplyState.active && kol24hReplyState.paused) {
            resumeKOL24hReply();
        } else if (kol24hReplyState.active) {
            stopKOL24hReply();
        } else {
            startKOL24hReply();
        }
    });
}

if (pauseKOL24hReplyBtn) {
    pauseKOL24hReplyBtn.addEventListener('click', () => {
        if (kol24hReplyState.active && !kol24hReplyState.paused) {
            pauseKOL24hReply();
        }
    });
}

if (stopKOL24hReplyBtn) {
    stopKOL24hReplyBtn.addEventListener('click', () => {
        stopKOL24hReply();
    });
}

if (startAIBtn) {
    startAIBtn.addEventListener('click', () => {
        if (!aiProcessState.active) startAICycle();
    });
}

// Dropdown controls for Pause state
// Logic: Show dropdown when mouse is anywhere in the container (button or dropdown)
// Hide only after mouse leaves the ENTIRE container for 600ms
if (aiBtnContainer && aiBtnDropdown) {
    let isMouseInContainer = false;

    // Track mouse entering the container
    aiBtnContainer.addEventListener('mouseenter', () => {
        isMouseInContainer = true;
        // Clear any pending hide timeout
        if (dropdownHideTimeout) {
            clearTimeout(dropdownHideTimeout);
            dropdownHideTimeout = null;
        }
        // Show dropdown only when paused
        if (aiProcessState.active && aiProcessState.paused) {
            aiBtnDropdown.classList.add('show');
        }
    });

    // Track mouse leaving the container
    aiBtnContainer.addEventListener('mouseleave', () => {
        isMouseInContainer = false;
        // Delay hiding by 600ms
        dropdownHideTimeout = setTimeout(() => {
            // Only hide if mouse is truly outside
            if (!isMouseInContainer) {
                aiBtnDropdown.classList.remove('show');
            }
        }, 600);
    });

    // Re-entering container cancels hide
    aiBtnDropdown.addEventListener('mouseenter', () => {
        isMouseInContainer = true;
        if (dropdownHideTimeout) {
            clearTimeout(dropdownHideTimeout);
            dropdownHideTimeout = null;
        }
    });

    aiBtnDropdown.addEventListener('mouseleave', () => {
        // Only start hide timer if mouse left dropdown but might still be in container
        // The container's mouseleave will handle the actual hiding
    });
}

// Note: Resume is now handled by clicking the main button when paused

// Pause/Resume Button Handler (AI 表格推文)：暂停与恢复共用此按钮
if (pauseAIBtn) {
    pauseAIBtn.addEventListener('click', () => {
        if (!aiProcessState.active) return;
        if (aiProcessState.paused) {
            resumeAI();
            showNotification('AI 已恢复', false);
        } else {
            pauseAI();
            showNotification('AI 已暂停', false);
        }
    });
}

// Stop Button Handler
if (stopAIBtn) {
    stopAIBtn.addEventListener('click', () => {
        try {
            if (aiProcessState.active) {
                if (aiBtnDropdown) aiBtnDropdown.classList.remove('show');
                stopAI();
                showNotification('AI 已完全停止', false);
            }
            if (kol24hReplyState && kol24hReplyState.active) {
                stopKOL24hReply();
                showNotification('KOL 24h 已停止', false);
            }
        } catch (e) {
            console.error('Stop AI error:', e);
            showNotification('停止失败: ' + (e.message || e), true);
        }
    });
}

// Hover-Stop Logic for Scan Button
if (startKOLScanBtn) {
    startKOLScanBtn.addEventListener('click', () => {
        if (kolScanState.active) {
            stopKOLScan();
        } else {
            startKOLScan();
        }
    });
}

function stopAI() {
    aiProcessState.active = false;
    aiProcessState.paused = false;
    aiProcessState.currentPhase = 'idle';
    aiProcessState.list = [];
    aiProcessState.currentIndex = 0;

    // 若正在 KOL 24h，一并停止
    if (kol24hReplyState && kol24hReplyState.active) {
        try {
            stopKOL24hReply();
        } catch (e) {
            console.error("Error stopping KOL 24h:", e);
        }
    }

    // Stop KOL Scan if running
    if (kolScanState.active) {
        try {
            stopKOLScan();
        } catch (e) {
            console.error("Error stopping KOL scan:", e);
        }
    }

    // 恢复主按钮显示，隐藏暂停/停止
    if (startAIBtn) {
        startAIBtn.style.display = 'inline-block';
        startAIBtn.disabled = false;
        startAIBtn.innerHTML = chrome.i18n.getMessage('btn_start_ai') || '回复表格推文';
        startAIBtn.classList.remove('active-state');
        startAIBtn.classList.remove('paused-state');
    }
    if (stopAIBtn) stopAIBtn.style.display = 'none';
    if (pauseAIBtn) {
        pauseAIBtn.style.display = 'none';
        pauseAIBtn.textContent = '暂停';
    }

    if (aiBtnDropdown) aiBtnDropdown.classList.remove('show');
    if (aiStatusDiv) aiStatusDiv.textContent = chrome.i18n.getMessage('status_stopped') || '已停止';
    hideGlobalProgress();

    aiProcessState.stoppedByUser = true;
    if (aiProcessState.snoozeTimer) clearTimeout(aiProcessState.snoozeTimer);
    if (aiProcessState.countdownTimer) clearInterval(aiProcessState.countdownTimer);
}

// NEW: Pause AI - preserves progress（主按钮已隐藏，只改暂停按钮为「恢复」）
function pauseAI() {
    if (!aiProcessState.active || aiProcessState.paused) return;

    aiProcessState.paused = true;
    console.log(`AI Paused at phase: ${aiProcessState.currentPhase}, index: ${aiProcessState.currentIndex} `);

    if (pauseAIBtn) pauseAIBtn.textContent = '恢复';
    if (aiStatusDiv) aiStatusDiv.textContent = chrome.i18n.getMessage('status_paused') || '已暂停 - 点击恢复';

    if (aiProcessState.currentPhase === 'snoozing' && aiProcessState.countdownTimer) {
        clearInterval(aiProcessState.countdownTimer);
    }
    if (aiBtnDropdown) aiBtnDropdown.classList.add('show');
}

// NEW: Resume AI - continues from saved progress
function resumeAI() {
    if (!aiProcessState.active || !aiProcessState.paused) return;

    aiProcessState.paused = false;
    console.log(`AI Resumed at phase: ${aiProcessState.currentPhase}, index: ${aiProcessState.currentIndex} `);

    if (pauseAIBtn) pauseAIBtn.textContent = '暂停';
    if (aiBtnDropdown) aiBtnDropdown.classList.remove('show');
    if (aiStatusDiv) aiStatusDiv.textContent = chrome.i18n.getMessage('status_resuming') || '恢复中...';

    // Resume based on current phase
    switch (aiProcessState.currentPhase) {
        case 'scanning':
            processNextKOL();
            break;
        case 'replying':
            processNextAIReply();
            break;
        case 'snoozing':
            // Re-enter snooze will restart the timer from where it was
            // For simplicity, restart snooze phase
            startSnoozePhase();
            break;
        default:
            processNextAIReply();
            break;
    }
}

async function processNextAIReply() {
    if (!aiProcessState.active) return;
    if (aiProcessState.paused) return; // NEW: Skip if paused

    aiProcessState.currentPhase = 'replying'; // NEW: Track phase

    if (aiProcessState.currentIndex >= aiProcessState.list.length) {
        console.log("All replies in list processed.");
        onReplyPhaseComplete();
        return;
    }

    const tweet = aiProcessState.list[aiProcessState.currentIndex];
    const currentIndex = aiProcessState.currentIndex + 1;
    const totalCount = aiProcessState.list.length;
    aiStatusDiv.textContent = `Processing ${currentIndex}/${totalCount}: @${tweet.username || 'User'}`;
    
    // Update progress in KOLs view
    updateAIProgress(currentIndex, totalCount, `正在处理: @${tweet.username || 'User'}`);

    // 1. Navigate to Tweet
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        // Check pause/stop state before navigation
        if (!aiProcessState.active || aiProcessState.paused) {
            console.log('AI stopped or paused before navigation');
            return;
        }

        if (tabs[0]) {
            const tabId = tabs[0].id;
            chrome.tabs.update(tabId, { url: tweet.url });

            // Wait for load
            const checkTabStatus = setInterval(() => {
                // Check pause/stop state
                if (!aiProcessState.active || aiProcessState.paused) {
                    clearInterval(checkTabStatus);
                    console.log('AI stopped or paused during tab load');
                    return;
                }

                chrome.tabs.get(tabId, (tab) => {
                    if (chrome.runtime.lastError || !tab) {
                        clearInterval(checkTabStatus);
                        return;
                    }

                    if (tab.status === 'complete') {
                        clearInterval(checkTabStatus);

                        // Check pause/stop state before content processing
                        if (!aiProcessState.active || aiProcessState.paused) {
                            console.log('AI stopped or paused after tab load');
                            return;
                        }

                        // 打开推文页后等待：使用设置项（2-15 秒），默认 5-8 秒；不从 0 开始
                        const pageMin = Math.max(2, parseInt(aiConfig.pageLoadWaitMin) || 5);
                        const pageMax = Math.min(15, Math.max(pageMin, parseInt(aiConfig.pageLoadWaitMax) || 8));
                        const pageWaitMs = Math.floor(Math.random() * (pageMax - pageMin + 1) + pageMin) * 1000;
                        setTimeout(async () => {
                            // Check pause/stop state
                            if (!aiProcessState.active || aiProcessState.paused) {
                                console.log('AI stopped or paused before scraping');
                                return;
                            }

                            // 2. Scrape Content（等待已在上面完成）
                            try {
                                const response = await chrome.tabs.sendMessage(tabId, { action: 'SCRAPE_TWEET_CONTENT' });

                                // Check pause/stop state after scraping
                                if (!aiProcessState.active || aiProcessState.paused) {
                                    console.log('AI stopped or paused after scraping');
                                    return;
                                }

                                // PRIORITY 0: Check if tweet URL is already in repliedUrls (highest priority check)
                                // Normalize URL for comparison (handle both Sheets and regular tweets)
                                const tweetUrl = tweet.url || tweet.normalizedUrl || '';
                                if (tweetUrl) {
                                    const normalizedUrl = tweetUrl.replace(/\/$/, '').split('?')[0];
                                    const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                                    const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                                    if (repliedUrls.has(normalizedUrl)) {
                                        console.log(`[Priority Skip] Tweet URL already in repliedUrls - skipping:`, normalizedUrl);
                                        aiStatusDiv.textContent = `跳过 - 已回复过`;
                                        updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `跳过 - 已回复过`);
                                        aiProcessState.currentIndex++;
                                        setTimeout(() => {
                                            processNextAIReply();
                                        }, 500);
                                        return;
                                    }
                                }

                                // SCREENING MECHANISM 2: Scan replies to check if current user has already replied
                                // Wait additional 1 second for replies to load after scrolling
                                await new Promise(resolve => setTimeout(resolve, 1000));
                                try {
                                    const scanResponse = await chrome.tabs.sendMessage(tabId, { action: 'SCAN_REPLIES' });
                                    if (scanResponse && scanResponse.hasReplied) {
                                        console.log(`[Screening Skip] Found own reply when scanning - marking as replied and skipping`);
                                        aiStatusDiv.textContent = `跳过 - 扫描发现已回复`;
                                        updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `跳过 - 扫描发现已回复`);
                                        
                                        // Mark as replied to avoid retrying
                                        if (tweetUrl) {
                                            const normalizedUrlForMark = tweetUrl.replace(/\/$/, '').split('?')[0];
                                            const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                                            const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                                            repliedUrls.add(normalizedUrlForMark);
                                            safeSetRepliedUrls(repliedUrls);
                                            console.log('[Screening Skip] Marked as replied (scan found own reply):', normalizedUrlForMark);
                                        }
                                        
                                        // Update local state
                                        const data = tweetStore.get(tweet.id);
                                        if (data) {
                                            data.interactions = data.interactions || {};
                                            data.interactions.reply = true;
                                            tweetStore.set(tweet.id, data);
                                        }
                                        
                                        aiProcessState.currentIndex++;
                                        setTimeout(() => {
                                            processNextAIReply();
                                        }, 500);
                                        return;
                                    }
                                } catch (scanError) {
                                    console.warn('[Screening] Failed to scan replies, continuing with normal flow:', scanError);
                                    // Continue with normal flow if scan fails
                                }

                                // PRIORITY 1: Check if tweet is already liked - skip if so
                                if (response && response.isLiked) {
                                    console.log(`[Priority Skip] Tweet is already liked - marking as replied and skipping`);
                                    aiStatusDiv.textContent = `跳过 - 已点赞`;
                                    updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `跳过 - 已点赞`);
                                    
                                    // Mark as replied to avoid retrying (use consistent URL normalization)
                                    const tweetUrlForMark = tweet.url || tweet.normalizedUrl || '';
                                    if (tweetUrlForMark) {
                                        const normalizedUrlForMark = tweetUrlForMark.replace(/\/$/, '').split('?')[0];
                                        const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                                        const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                                        repliedUrls.add(normalizedUrlForMark);
                                        safeSetRepliedUrls(repliedUrls);
                                        console.log('[Priority Skip] Marked as replied (liked):', normalizedUrlForMark);
                                        
                                        if (tweet.threadId) {
                                            const repliedThreadIdsData = localStorage.getItem('repliedThreadIds');
                                            const repliedThreadIds = repliedThreadIdsData ? new Set(JSON.parse(repliedThreadIdsData)) : new Set();
                                            repliedThreadIds.add(tweet.threadId);
                                            safeSetRepliedThreadIds(repliedThreadIds);
                                        }
                                    }
                                    
                                    // Update local state to mark as replied
                                    const data = tweetStore.get(tweet.id);
                                    if (data) {
                                        data.interactions = data.interactions || {};
                                        data.interactions.reply = true; // Mark as replied
                                        data.interactions.like = true; // Already liked
                                        tweetStore.set(tweet.id, data);
                                    }
                                    
                                    // Move to next tweet
                                    aiProcessState.currentIndex++;
                                    setTimeout(() => {
                                        processNextAIReply();
                                    }, 500);
                                    return;
                                }

                                // PRIORITY 2: Check if tweet is already replied to (from page detection)
                                if (response && response.isReplied) {
                                    console.log(`[Priority Skip] Tweet is already replied (detected from page) - marking as replied and skipping`);
                                    aiStatusDiv.textContent = `跳过 - 页面检测已回复`;
                                    updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `跳过 - 页面检测已回复`);
                                    
                                    // Mark as replied to avoid retrying (use consistent URL normalization)
                                    const tweetUrlForMark = tweet.url || tweet.normalizedUrl || '';
                                    if (tweetUrlForMark) {
                                        const normalizedUrlForMark = tweetUrlForMark.replace(/\/$/, '').split('?')[0];
                                        const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                                        const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                                        repliedUrls.add(normalizedUrlForMark);
                                        safeSetRepliedUrls(repliedUrls);
                                        console.log('[Priority Skip] Marked as replied (page detection):', normalizedUrlForMark);
                                    }
                                    
                                    // Update local state
                                    const data = tweetStore.get(tweet.id);
                                    if (data) {
                                        data.interactions = data.interactions || {};
                                        data.interactions.reply = true;
                                        tweetStore.set(tweet.id, data);
                                    }
                                    
                                    // Move to next tweet
                                    aiProcessState.currentIndex++;
                                    setTimeout(() => {
                                        processNextAIReply();
                                    }, 500);
                                    return;
                                }

                                // Check if this is own tweet - skip if so
                                if (response && response.isOwnTweet) {
                                    console.log(`Skipping reply - this is your own tweet (@${response.tweetAuthor})`);
                                    aiStatusDiv.textContent = `跳过 - 自己的推文`;
                                    updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `跳过 - 自己的推文: @${response.tweetAuthor}`);
                                    
                                    // Mark as replied to avoid retrying
                                    if (tweet.fromSheets && tweet.normalizedUrl) {
                                        const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                                        const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                                        repliedUrls.add(tweet.normalizedUrl);
                                        safeSetRepliedUrls(repliedUrls);
                                        
                                        if (tweet.threadId) {
                                            const repliedThreadIdsData = localStorage.getItem('repliedThreadIds');
                                            const repliedThreadIds = repliedThreadIdsData ? new Set(JSON.parse(repliedThreadIdsData)) : new Set();
                                            repliedThreadIds.add(tweet.threadId);
                                            safeSetRepliedThreadIds(repliedThreadIds);
                                        }
                                    }
                                    
                                    // Move to next tweet
                                    aiProcessState.currentIndex++;
                                    setTimeout(() => {
                                        processNextAIReply();
                                    }, 1000);
                                    return;
                                }

                                if (response && response.content) {
                                    // 3. Call AI
                                    aiStatusDiv.textContent = `Generating reply for @${tweet.username || 'User'}...`;
                                    updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `正在生成回复: @${tweet.username || 'User'}`);
                                    // Use latest systemPrompt from aiConfig to ensure blacklist updates are applied
                                    const currentSystemPrompt = aiConfig.systemPrompt || aiProcessState.systemPrompt || DEFAULT_SYSTEM_PROMPT;
                                    let replyText = await callAI(aiConfig.provider, aiConfig.apiKey, currentSystemPrompt, response.content);
                                    if (replyText) {
                                        replyText = (replyText || '').trim();
                                        // 去掉尾部明显无意义的单字/数字行（API 截断或异常时常见）
                                        const lines = replyText.split(/\n/);
                                        while (lines.length > 1 && /^[\s\u4e00-\u9fa5a-zA-Z0-9]{1}$/.test(lines[lines.length - 1].trim())) {
                                            lines.pop();
                                        }
                                        replyText = lines.join('\n').trim();
                                    }

                                    // Check pause/stop state after AI call
                                    if (!aiProcessState.active || aiProcessState.paused) {
                                        console.log('AI stopped or paused after AI generation');
                                        return;
                                    }

                                    if (replyText) {
                                        // 4. Perform Actions (with main tweet check)
                                        aiStatusDiv.textContent = `Checking main tweet...`;
                                        updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `正在检查主推文: @${tweet.username || 'User'}`);
                                        let actionResult;
                                        try {
                                            actionResult = await chrome.tabs.sendMessage(tabId, {
                                                action: 'PERFORM_ACTIONS',
                                                payload: {
                                                    replyText: replyText,
                                                    doLike: aiProcessState.autoLike,
                                                    doRepost: aiProcessState.autoRepost,
                                                    replyDelay: { min: parseInt(aiConfig.replyDelayMin) || 3, max: parseInt(aiConfig.replyDelayMax) || 7 },
                                                    likeDelay: { min: parseInt(aiConfig.likeDelayMin) || 1, max: parseInt(aiConfig.likeDelayMax) || 5 },
                                                    postReplyWaitMin: parseInt(aiConfig.postReplyWaitMin) || 5,
                                                    postReplyWaitMax: parseInt(aiConfig.postReplyWaitMax) || 15
                                                }
                                            });
                                        } catch (sendErr) {
                                            // 操作耗时过长或页面刷新导致「message port closed」/连接断开，按账号限制处理：暂停并提示刷新
                                            const msg = (sendErr && sendErr.message) ? sendErr.message : String(sendErr);
                                            console.warn('[Tweet Reply] sendMessage failed (port closed or tab reload):', msg);
                                            aiStatusDiv.textContent = `已暂停 - 连接断开，请刷新页面后重试`;
                                            aiProcessState.active = false;
                                            if (typeof stopAI === 'function') stopAI();
                                            showNotification('与页面连接已断开（可能因 X 报错/刷新）。请刷新页面后重试。', true);
                                            return;
                                        }

                                        // 检测到 X 账号限制横幅：暂停并提示刷新，不标记已回复以便刷新后重试
                                        if (actionResult && !actionResult.success && actionResult.error && (actionResult.error.includes('ACCOUNT_RESTRICTION') || actionResult.error.includes('不允许执行这项操作'))) {
                                            console.warn('[Tweet Reply] X account restriction detected - pausing:', actionResult.error);
                                            aiStatusDiv.textContent = `已暂停 - 账号限制，请刷新页面后重试`;
                                            aiProcessState.active = false;
                                            if (typeof stopAI === 'function') stopAI();
                                            showNotification('检测到 X 账号限制提示，已暂停。请刷新页面后重试。', true);
                                            return;
                                        }
                                        // Check if action was skipped (not main tweet)
                                        // Mark as replied anyway so these tweets won't appear again on next run.
                                        if (actionResult && !actionResult.success && actionResult.error && actionResult.error.includes('Not main tweet')) {
                                            console.warn('[Tweet Reply] Skipped reply - not main tweet, marking as processed so it won\'t reappear:', actionResult.error);
                                            aiStatusDiv.textContent = `跳过 - 非主推文（已归档）`;
                                            
                                            // Mark as replied so next run won't process these again
                                            if (tweet.fromSheets && tweet.normalizedUrl) {
                                                const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                                                const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                                                repliedUrls.add(tweet.normalizedUrl);
                                                safeSetRepliedUrls(repliedUrls);
                                                if (tweet.threadId) {
                                                    const repliedThreadIdsData = localStorage.getItem('repliedThreadIds');
                                                    const repliedThreadIds = repliedThreadIdsData ? new Set(JSON.parse(repliedThreadIdsData)) : new Set();
                                                    repliedThreadIds.add(tweet.threadId);
                                                    safeSetRepliedThreadIds(repliedThreadIds);
                                                }
                                            }
                                            
                                            aiProcessState.currentIndex++;
                                            if (!aiProcessState.active || aiProcessState.paused) {
                                                return;
                                            }
                                            processNextAIReply();
                                            return;
                                        }
                                        
                                        // For other errors, still mark as replied to avoid infinite retry
                                        if (actionResult && !actionResult.success) {
                                            console.warn('[Tweet Reply] Action failed with error:', actionResult.error);
                                            aiStatusDiv.textContent = `跳过 - 操作失败`;
                                            
                                            // Mark as replied to avoid infinite retry (only for non-main-tweet errors we skip marking)
                                            if (tweet.fromSheets && tweet.normalizedUrl) {
                                                const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                                                const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                                                repliedUrls.add(tweet.normalizedUrl);
                                                safeSetRepliedUrls(repliedUrls);
                                                
                                                if (tweet.threadId) {
                                                    const repliedThreadIdsData = localStorage.getItem('repliedThreadIds');
                                                    const repliedThreadIds = repliedThreadIdsData ? new Set(JSON.parse(repliedThreadIdsData)) : new Set();
                                                    repliedThreadIds.add(tweet.threadId);
                                                    safeSetRepliedThreadIds(repliedThreadIds);
                                                }
                                            }
                                            
                                            // Move to next tweet
                                            aiProcessState.currentIndex++;
                                            if (!aiProcessState.active || aiProcessState.paused) {
                                                return;
                                            }
                                            processNextAIReply();
                                            return;
                                        }

                                        // Check pause/stop state after actions
                                        if (!aiProcessState.active || aiProcessState.paused) {
                                            console.log('AI stopped or paused after posting');
                                            return;
                                        }

                                        // Only mark as replied if action was successful
                                        let replySuccess = false;
                                        if (actionResult && actionResult.success !== false) {
                                            replySuccess = true;
                                        }

                                        // Mark as replied ONLY if reply was successful
                                        if (replySuccess && tweet.fromSheets && tweet.normalizedUrl) {
                                            const repliedUrlsData = localStorage.getItem('repliedTweetUrls');
                                            const repliedUrls = repliedUrlsData ? new Set(JSON.parse(repliedUrlsData)) : new Set();
                                            repliedUrls.add(tweet.normalizedUrl);
                                            safeSetRepliedUrls(repliedUrls);
                                            console.log('Marked tweet as replied (success):', tweet.normalizedUrl);
                                            
                                            // Also mark thread ID as replied to avoid replying to same thread
                                            if (tweet.threadId) {
                                                const repliedThreadIdsData = localStorage.getItem('repliedThreadIds');
                                                const repliedThreadIds = repliedThreadIdsData ? new Set(JSON.parse(repliedThreadIdsData)) : new Set();
                                                repliedThreadIds.add(tweet.threadId);
                                                safeSetRepliedThreadIds(repliedThreadIds);
                                                console.log('Marked thread as replied:', tweet.threadId);
                                            }
                                        }

                                        // Update Local State
                                        const data = tweetStore.get(tweet.id);
                                        if (data) {
                                            data.interactions.reply = replySuccess; // Only mark as replied if successful
                                            if (aiProcessState.autoLike && replySuccess) data.interactions.like = true;
                                            if (aiProcessState.autoRepost && replySuccess) data.interactions.retweet = true;
                                            if (replySuccess) data.replyText = replyText;
                                            tweetStore.set(tweet.id, data);

                                            // Update UI Card if visible
                                            const card = listList.querySelector(`.tweet-card[data-id="${tweet.id}"]`);
                                            if (card) {
                                                if (data.interactions.reply) card.querySelector('.interaction-btn.reply').classList.add('active');
                                                if (data.interactions.like) card.querySelector('.interaction-btn.like').classList.add('active');
                                                if (data.interactions.retweet) card.querySelector('.interaction-btn.retweet').classList.add('active');

                                                // Auto-Archive after successful reply
                                                console.log(`Auto-archiving tweet ${tweet.id}...`);
                                                moveToArchive(tweet.id, card);
                                            }
                                            
                                            // Add to Interaction Trace (互动轨迹)
                                            // Use response.content (scraped from page) as primary source
                                            // For sheets tweets, also try tweet.text/fullText or sheetData
                                            let tweetContent = response?.content || '';
                                            if (!tweetContent && tweet.fromSheets) {
                                                // For sheets tweets, get content from tweet data
                                                tweetContent = tweet.text || tweet.fullText || '';
                                                if (!tweetContent && tweet.sheetData) {
                                                    tweetContent = tweet.sheetData['推文全文'] || tweet.sheetData['Tweet Full Text'] || tweet.sheetData['fullText'] || '';
                                                }
                                            }
                                            if (!tweetContent) {
                                                tweetContent = tweet.content || data.content || '';
                                            }
                                            
                                            // Only add to interaction trace if reply was successful
                                            if (replySuccess) {
                                                console.log('[addPostToReport] Adding tweet:', {
                                                    id: tweet.id,
                                                    kolName: tweet.username || data.username,
                                                    contentLength: tweetContent.length,
                                                    hasResponseContent: !!response?.content,
                                                    fromSheets: tweet.fromSheets,
                                                    hasText: !!(tweet.text || tweet.fullText),
                                                    hasReplyText: !!replyText
                                                });
                                                addPostToReport({
                                                    tweetId: tweet.id,
                                                    kolName: tweet.username || data.username || 'Unknown',
                                                    kolLink: tweet.url || data.url || tweet.normalizedUrl || '',
                                                    normalizedUrl: tweet.normalizedUrl || tweet.url || data.url || '',
                                                    timestamp: tweet.timestamp || data.timestamp || Date.now(),
                                                    content: tweetContent, // Use scraped content, or from sheets data
                                                    replyText: replyText || '' // AI回复内容
                                                });
                                                console.log(`Added tweet to interaction trace: ${tweet.id}`);
                                                
                                                // Real-time update interaction trace if currently viewing it
                                                if (viewReport && viewReport.classList.contains('active')) {
                                                    console.log('[Real-time update] Updating interaction trace');
                                                    renderDailyReportDebounced(true); // Use debounced version to preserve scroll
                                                }
                                                
                                                // Update progress
                                                updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `已回复: @${tweet.username || 'User'}`);
                                            } else {
                                                console.warn('Reply was not successful, not adding to interaction trace');
                                            }
                                        } else if (tweet.fromSheets && replySuccess) {
                                            // For tweets from sheets that aren't in tweetStore, still add to interaction trace
                                            // Only add if reply was successful
                                            // Use response.content (scraped from page) as primary source
                                            // Then try tweet.text/fullText or sheetData
                                            let sheetsContent = response?.content || '';
                                            if (!sheetsContent) {
                                                sheetsContent = tweet.text || tweet.fullText || '';
                                                if (!sheetsContent && tweet.sheetData) {
                                                    sheetsContent = tweet.sheetData['推文全文'] || tweet.sheetData['Tweet Full Text'] || tweet.sheetData['fullText'] || '';
                                                }
                                            }
                                            
                                            console.log('[addPostToReport] Adding sheets tweet:', {
                                                normalizedUrl: tweet.normalizedUrl,
                                                kolName: tweet.username,
                                                contentLength: sheetsContent.length,
                                                hasResponseContent: !!response?.content,
                                                hasText: !!tweet.text,
                                                hasSheetData: !!tweet.sheetData,
                                                hasReplyText: !!replyText
                                            });
                                            addPostToReport({
                                                tweetId: tweet.id || tweet.normalizedUrl || '',
                                                kolName: tweet.username || 'Unknown',
                                                kolLink: tweet.url || tweet.normalizedUrl || '',
                                                normalizedUrl: tweet.normalizedUrl || tweet.url || '',
                                                timestamp: tweet.timestamp || Date.now(),
                                                content: sheetsContent, // Use content from sheets data
                                                replyText: replyText || '' // AI回复内容
                                            });
                                            console.log(`Added sheets tweet to interaction trace: ${tweet.normalizedUrl}`);
                                            
                                            // Real-time update interaction trace if currently viewing it
                                            if (viewReport && viewReport.classList.contains('active')) {
                                                console.log('[Real-time update] Updating interaction trace');
                                                renderDailyReportDebounced(true); // Use debounced version to preserve scroll
                                            }
                                            
                                            // Update progress
                                            updateAIProgress(aiProcessState.currentIndex + 1, aiProcessState.list.length, `已回复: @${tweet.username || 'User'}`);
                                        }
                                    } else {
                                        console.error('AI failed to generate reply');
                                    }
                                }
                            } catch (e) {
                                console.error('Error processing tweet:', e);
                                // Don't mark as replied if there was an error
                            }

                            // Note: Marking as replied is now done only when reply is successful (see above)
                            // This prevents duplicate replies when errors occur
                            
                            aiProcessState.currentIndex++;

                            // Check pause/stop state before processing next
                            if (!aiProcessState.active || aiProcessState.paused) {
                                console.log('AI stopped or paused, not processing next tweet');
                                return;
                            }

                            // 每条回复完成后的主要等待已在 content 中按「每条回复完成后等待」设置执行，此处仅短延时后跳下一条
                            setTimeout(function () {
                                if (!aiProcessState.active || aiProcessState.paused) return;
                                processNextAIReply();
                            }, 500);
                        }, pageWaitMs);
                    }
                });
            }, 1000);
        }
    });
}

function onReplyPhaseComplete() {
    console.log("Reply phase complete.");
    
    // Update progress to show completion
    if (aiProcessState.list && aiProcessState.list.length > 0) {
        updateAIProgress(aiProcessState.list.length, aiProcessState.list.length, '所有推文处理完成！');
    }

    // Check if this was KOL 24h reply mode
    if (kol24hReplyState && kol24hReplyState.active) {
        // KOL 24h reply completed
        showNotification(`KOL 24h回复完成，共处理 ${aiProcessState.list ? aiProcessState.list.length : 0} 条推文`, false);
        stopKOL24hReply();
        return;
    }

    // If in cycle, start snooze phase
    if (aiProcessState.inCycle) {
        startSnoozePhase();
    } else {
        // Single run complete
        stopAI();
    }
}

async function callAI(provider, apiKey, systemPrompt, tweetContent, retryCount = 0) {
    const MAX_RETRIES = 3;

    try {
        let url, body, headers;

        if (provider === 'openai' || provider === 'deepseek' || provider === 'grok' || provider === 'gpt-5-nano') {
            if (provider === 'openai') {
                url = aiConfig.apiUrl || 'https://api.openai.com/v1/chat/completions';
            } else if (provider === 'gpt-5-nano') {
                url = aiConfig.apiUrl || 'https://api.openai.com/v1/chat/completions'; // Use standard endpoint or custom
            } else if (provider === 'deepseek') {
                url = aiConfig.apiUrl || 'https://api.deepseek.com/chat/completions';
            } else if (provider === 'grok') {
                url = aiConfig.apiUrl || 'https://api.x.ai/v1/chat/completions';
            }

            headers = {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            };

            let modelName = 'gpt-3.5-turbo';
            if (provider === 'deepseek') modelName = 'deepseek-chat';
            if (provider === 'grok') modelName = 'grok-beta';
            if (provider === 'gpt-5-nano') modelName = 'gpt-5-nano'; // User requested specific model name

            body = JSON.stringify({
                model: modelName,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: `Tweet: "${tweetContent}"\n\nGenerate a reply:` }
                ],
                temperature: 0.7
            });

            // Removed special handling for GPT-5 Nano as it was causing errors
        } else if (provider === 'gemini') {
            url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-preview:generateContent?key=${apiKey}`;
            headers = {
                'Content-Type': 'application/json'
            };
            body = JSON.stringify({
                contents: [{
                    parts: [{
                        text: `${systemPrompt}\n\nTweet: "${tweetContent}"\n\nReply:`
                    }]
                }],
                generationConfig: {
                    thinkingConfig: {
                        thinkingLevel: "low"
                    }
                }
            });
        } else if (provider === 'gemini-flash') {
            url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;
            headers = {
                'Content-Type': 'application/json'
            };
            body = JSON.stringify({
                contents: [{
                    parts: [{
                        text: `${systemPrompt}\n\nTweet: "${tweetContent}"\n\nReply:`
                    }]
                }]
            });
        }

        const response = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: body
        });

        const data = await response.json();
        console.log('AI Response Data (Full):', JSON.stringify(data, null, 2)); // Log pretty JSON

        let replyText = '';
        if (provider === 'gemini' || provider === 'gemini-flash') {
            replyText = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
        } else if (provider === 'gpt-5-nano') {
            // Parse GPT-5 Nano specific structure
            if (data.output && Array.isArray(data.output)) {
                const messageItem = data.output.find(item => item.type === 'message');
                if (messageItem && messageItem.content && Array.isArray(messageItem.content)) {
                    const textItem = messageItem.content.find(c => c.type === 'output_text');
                    if (textItem) {
                        replyText = textItem.text || '';
                    }
                }
            }
            // Fallback
            if (!replyText) {
                replyText = JSON.stringify(data);
            }
        } else {
            replyText = data.choices?.[0]?.message?.content || '';
        }

        // Check and regenerate if blacklisted words are found
        if (replyText) {
            console.log('[Blacklist Check] Checking reply for blacklisted words...');
            const blacklistCheck = checkBlacklistedWords(replyText, systemPrompt);
            if (blacklistCheck.hasBlacklisted) {
                console.log(`[Blacklist Check] Blacklisted words detected: ${blacklistCheck.words.join(', ')}`);
                if (retryCount < MAX_RETRIES - 1) {
                    // Regenerate with enhanced prompt that explicitly avoids blacklisted words
                    console.log(`[Blacklist Check] Regenerating reply (attempt ${retryCount + 2}/${MAX_RETRIES})...`);
                    const enhancedSystemPrompt = enhanceSystemPromptWithBlacklist(systemPrompt, blacklistCheck.words);
                    console.log('[Blacklist Check] Enhanced system prompt:', enhancedSystemPrompt.substring(0, 200) + '...');
                    // Add a small delay before retry to avoid rate limiting
                    await new Promise(resolve => setTimeout(resolve, 500));
                    return callAI(provider, apiKey, enhancedSystemPrompt, tweetContent, retryCount + 1);
                } else {
                    // Last resort: remove blacklisted words (but log a warning)
                    console.warn(`[Blacklist Check] Max retries (${MAX_RETRIES}) reached. Removing blacklisted words as fallback: ${blacklistCheck.words.join(', ')}`);
                    replyText = filterBlacklistedWords(replyText, systemPrompt);
                    console.log('[Blacklist Check] Filtered reply:', replyText);
                }
            } else {
                console.log('[Blacklist Check] No blacklisted words found in reply');
            }
        }

        return replyText;

    } catch (error) {
        const isNetworkError = !!(error && (error.message.includes('Failed to fetch') || error.message.includes('NetworkError') || error.name === 'TypeError'));
        console.error(`AI API Error (Attempt ${retryCount + 1}/${MAX_RETRIES}):`, error);

        // 网络错误：2/4/6 秒重试，最多 3 次后再跳过
        const NETWORK_RETRY_DELAYS = [2000, 4000, 6000];
        if (isNetworkError && retryCount < NETWORK_RETRY_DELAYS.length) {
            const delay = NETWORK_RETRY_DELAYS[retryCount];
            console.log(`[callAI] 网络错误，${delay / 1000}s 后重试 (${retryCount + 1}/3)...`);
            showNotification(`网络错误，${delay / 1000}秒后重试 (${retryCount + 1}/3)`, true);
            await new Promise(resolve => setTimeout(resolve, delay));
            return callAI(provider, apiKey, systemPrompt, tweetContent, retryCount + 1);
        }

        showNotification(`AI Error: ${error.message}`, true);
        return null;
    }
}

// Hardcoded blacklist - always active（含换行符，发出去易乱码）
const HARDCODED_BLACKLIST = [
    '\n',      // 换行符，禁止出现
    '格局打开',
    '未来可期',
    '真香',
    '稳了',
    'HODL',
    '革命',
    '未来',
    '香',
    '格局',
    '硬道理',
    '走起',
    '这波',
    '硬核',
    '会玩',
    '静待',
    '花开',
    '才是',
    '绝了'
];

// Check if reply contains blacklisted words
function checkBlacklistedWords(replyText, systemPrompt) {
    if (!replyText) {
        return { hasBlacklisted: false, words: [], blacklist: [] };
    }

    // Start with hardcoded blacklist
    let blacklist = [...HARDCODED_BLACKLIST];
    console.log('[Blacklist Check] Hardcoded blacklist:', blacklist);

    // Extract additional blacklist from System Prompt (if provided)
    if (systemPrompt) {
        // Try multiple patterns to match different formats
        const blacklistPatterns = [
            /生成词黑名单[：:]\s*([\s\S]*?)(?=\n\s*(?:[^\s\n]|$)|$)/i,
            /黑名单[：:]\s*([\s\S]*?)(?=\n\s*(?:[^\s\n]|$)|$)/i,
            /禁止使用[：:]\s*([\s\S]*?)(?=\n\s*(?:[^\s\n]|$)|$)/i,
            /不要使用[：:]\s*([\s\S]*?)(?=\n\s*(?:[^\s\n]|$)|$)/i,
            // Also try matching everything after "生成词黑名单:" until end or next major section
            /生成词黑名单[：:]\s*([\s\S]+?)(?=\n\n|\n[^\s\n]{2,}[：:]|$)/i
        ];

        let extractedBlacklist = [];
        for (const pattern of blacklistPatterns) {
            const match = systemPrompt.match(pattern);
            if (match) {
                console.log('[Blacklist Extract] Pattern matched:', pattern.toString());
                const blacklistSection = match[1];
                console.log('[Blacklist Extract] Raw section:', blacklistSection);
                
                extractedBlacklist = blacklistSection
                    .split('\n')
                    .map(line => line.trim())
                    .filter(line => {
                        return line.length > 0 && 
                               !line.match(/^[：:]/) && 
                               !line.match(/^生成词黑名单/i) &&
                               !line.match(/^黑名单/i) &&
                               !line.match(/^禁止使用/i) &&
                               !line.match(/^不要使用/i);
                    });
                
                console.log('[Blacklist Extract] After split and filter:', extractedBlacklist);
                
                const expandedBlacklist = [];
                extractedBlacklist.forEach(item => {
                    if (item.includes('，') || item.includes(',') || item.includes('、')) {
                        const parts = item.split(/[，,、]/).map(p => p.trim()).filter(p => p);
                        expandedBlacklist.push(...parts);
                    } else {
                        expandedBlacklist.push(item);
                    }
                });
                extractedBlacklist = expandedBlacklist;
                console.log('[Blacklist Extract] Extracted from System Prompt:', extractedBlacklist);
                
                // Merge with hardcoded blacklist (avoid duplicates)
                extractedBlacklist.forEach(word => {
                    if (word && !blacklist.includes(word)) {
                        blacklist.push(word);
                    }
                });
                break;
            }
        }
        
        if (extractedBlacklist.length === 0) {
            console.log('[Blacklist Extract] No additional blacklist found in System Prompt');
        }
    }

    console.log('[Blacklist Check] Extracted blacklist:', blacklist);
    console.log('[Blacklist Check] Checking reply:', replyText);

    // Check if reply contains any blacklisted words
    const foundWords = [];
    blacklist.forEach(word => {
        if (word) {
            const isChinese = /[\u4e00-\u9fa5]/.test(word);
            let regex;
            
            if (isChinese) {
                regex = new RegExp(word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
            } else {
                regex = new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'gi');
            }
            
            if (regex.test(replyText)) {
                foundWords.push(word);
                console.log(`[Blacklist Check] Found blacklisted word: "${word}"`);
            }
        }
    });

    const result = {
        hasBlacklisted: foundWords.length > 0,
        words: foundWords,
        blacklist: blacklist
    };
    
    console.log('[Blacklist Check] Result:', result);
    return result;
}

// Enhance system prompt with explicit blacklist instruction
function enhanceSystemPromptWithBlacklist(systemPrompt, blacklistedWords) {
    if (!blacklistedWords || blacklistedWords.length === 0) {
        return systemPrompt;
    }
    // 换行符在提示里显示为「换行符」，便于模型理解
    const displayWords = blacklistedWords.map(function (w) {
        return (w === '\n' || w === '\r') ? '换行符' : w;
    });

    // Check if blacklist instruction already exists
    if (systemPrompt.includes('禁止使用') || systemPrompt.includes('不要使用')) {
        const instruction = '\n\n重要：请确保回复中绝对不要包含以下词汇：' + displayWords.join('、') + '。如果回复中包含这些词汇，请用其他表达方式替换。回复请用单行，不要换行。';
        return systemPrompt + instruction;
    } else {
        const instruction = '\n\n重要提示：回复时请绝对避免使用以下词汇或短语：' + displayWords.join('、') + '。如果原本想使用这些词汇，请用其他自然、通顺的表达方式替换，确保回复完整且流畅。回复请用单行，不要换行。';
        return systemPrompt + instruction;
    }
}

// Filter blacklisted words from AI reply (fallback method - only used if regeneration fails)
function filterBlacklistedWords(replyText, systemPrompt) {
    if (!replyText) {
        return replyText;
    }
    // 先合并硬编码黑名单（含换行符），再从 systemPrompt 提取
    let blacklist = [...HARDCODED_BLACKLIST];

    if (!systemPrompt) {
        // 仅硬编码黑名单时，只做换行替换
        return blacklist.filter(function (w) { return w === '\n' || w === '\r'; }).length
            ? replyText.replace(/\s*[\r\n]+\s*/g, ' ').trim()
            : replyText;
    }

    // Extract blacklist from System Prompt
    const blacklistPatterns = [
        /生成词黑名单[：:]\s*([\s\S]*?)(?=\n\s*[^\s\n]|$)/i,  // Match until next non-empty line or end
        /黑名单[：:]\s*([\s\S]*?)(?=\n\s*[^\s\n]|$)/i,
        /禁止使用[：:]\s*([\s\S]*?)(?=\n\s*[^\s\n]|$)/i,
        /不要使用[：:]\s*([\s\S]*?)(?=\n\s*[^\s\n]|$)/i
    ];

    for (const pattern of blacklistPatterns) {
        const match = systemPrompt.match(pattern);
        if (match) {
            const blacklistSection = match[1];
            const extracted = blacklistSection
                .split('\n')
                .map(function (line) { return line.trim(); })
                .filter(function (line) {
                    return line.length > 0 &&
                           !line.match(/^[：:]/) &&
                           !line.match(/^生成词黑名单/i) &&
                           !line.match(/^黑名单/i);
                });
            const expandedBlacklist = [];
            extracted.forEach(function (item) {
                if (item.includes('，') || item.includes(',') || item.includes('、')) {
                    const parts = item.split(/[，,、]/).map(function (p) { return p.trim(); }).filter(function (p) { return p; });
                    expandedBlacklist.push.apply(expandedBlacklist, parts);
                } else {
                    expandedBlacklist.push(item);
                }
            });
            expandedBlacklist.forEach(function (item) {
                if (item && blacklist.indexOf(item) === -1) blacklist.push(item);
            });
            break;
        }
    }

    console.log('Blacklist extracted:', blacklist);

    // Filter out blacklisted words/phrases from reply（换行符替换为空格）
    let filteredReply = replyText;
    blacklist.forEach(function (word) {
        if (!word) return;
        const isNewline = word === '\n' || word === '\r';
        let regex;
        if (isNewline) {
            regex = /\s*[\r\n]+\s*/g;
        } else {
            const isChinese = /[\u4e00-\u9fa5]/.test(word);
            if (isChinese) {
                regex = new RegExp(word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
            } else {
                regex = new RegExp('\\b' + word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'gi');
            }
        }
        filteredReply = filteredReply.replace(regex, isNewline ? ' ' : '');
    });

    // Clean up extra spaces and newlines that might result from removals
    filteredReply = filteredReply
        .replace(/\s+/g, ' ') // Multiple spaces to single space
        .replace(/\n\s*\n\s*\n/g, '\n\n') // Multiple newlines to double newline
        .trim();

    if (filteredReply !== replyText) {
        console.log('Reply filtered. Original:', replyText);
        console.log('Filtered:', filteredReply);
    }

    return filteredReply;
}

// --- Trash Cleanup ---
function cleanupTrash() {
    const retentionMs = 30 * 24 * 60 * 60 * 1000; // 30 days
    const now = Date.now();
    let cleanedCount = 0;

    for (const [id, data] of tweetStore) {
        if (data.status === 'trash') {
            if (now - data.deletedAt > retentionMs) {
                tweetStore.delete(id);
                cleanedCount++;
            }
        }
    }

    if (cleanedCount > 0) {
        console.log(`Cleaned up ${cleanedCount} expired trash items.`);
        saveTweets(); // Persist changes
    }
}

// Run initialization on load
async function initializeApp() {
    console.log('Initializing app...');

    // 1. Load Groups first (KOLs depend on groups)
    await loadGroups();
    console.log('Groups loaded');

    // 2. Load KOLs
    await loadKOLs();
    console.log('KOLs loaded');

    // 3. Load Tweets
    await loadTweets();
    console.log('Tweets loaded');

    // 4. Cleanup old trash
    cleanupTrash();

    // 5. Initialize date pickers with today's date (local time)
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0]; // YYYY-MM-DD format

    // Format local datetime for datetime-local input: YYYY-MM-DDTHH:MM
    const formatLocalDatetime = (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    };
    const nowStr = formatLocalDatetime(today);

    if (reportDatePicker) {
        reportDatePicker.value = todayStr;
    }
    if (summaryDatetimeInput) {
        summaryDatetimeInput.value = nowStr;
    }

    // 6. Load Apps Script code
    loadAppsScriptCode();

    // 7. Load project blocklist
    await loadProjectBlocklist();

    console.log('App initialization complete');
}

// NOTE: initializeApp() is called at the end of the file after all functions are defined

// --- Persistence ---

// Tweet Store Persistence Configuration
const TWEET_STORAGE_CONFIG = {
    maxItems: 1000,           // Maximum number of tweets to keep
    maxAgeDays: 30,           // Maximum age in days
    debounceMs: 500,          // Debounce delay for saving
    storageKey: 'tweetStore'  // Chrome storage key
};

let saveTweetsTimeout = null;

// Debounced save function to avoid excessive writes
function saveTweets() {
    if (saveTweetsTimeout) {
        clearTimeout(saveTweetsTimeout);
    }
    saveTweetsTimeout = setTimeout(() => {
        saveTweetsImmediate();
    }, TWEET_STORAGE_CONFIG.debounceMs);
}

// Immediate save function
function saveTweetsImmediate() {
    // Clean up old data before saving
    cleanupTweetStore();

    const tweets = Array.from(tweetStore.values());
    const data = JSON.stringify(tweets);

    // Check data size (Chrome storage.local limit is ~5MB)
    const sizeInBytes = new Blob([data]).size;
    const sizeInMB = sizeInBytes / (1024 * 1024);

    console.log(`Saving ${tweets.length} tweets (${sizeInMB.toFixed(2)} MB)`);

    // If data is too large, aggressive cleanup
    if (sizeInMB > 4) {
        console.warn('Tweet data exceeds 4MB, performing aggressive cleanup...');
        aggressiveCleanup();
        const cleanedTweets = Array.from(tweetStore.values());
        const cleanedData = JSON.stringify(cleanedTweets);
        chrome.storage.local.set({ [TWEET_STORAGE_CONFIG.storageKey]: cleanedData });
    } else {
        chrome.storage.local.set({ [TWEET_STORAGE_CONFIG.storageKey]: data });
    }
}

// Load tweets from storage on startup
function loadTweets() {
    return new Promise((resolve) => {
        chrome.storage.local.get([TWEET_STORAGE_CONFIG.storageKey], (result) => {
            if (result[TWEET_STORAGE_CONFIG.storageKey]) {
                try {
                    const tweets = JSON.parse(result[TWEET_STORAGE_CONFIG.storageKey]);
                    tweets.forEach(tweet => {
                        tweetStore.set(tweet.id, tweet);
                    });

                    // Render loaded tweets to appropriate lists
                    renderLoadedTweets();

                    console.log(`Loaded ${tweets.length} tweets from storage`);
                } catch (e) {
                    console.error('Failed to load tweets:', e);
                }
            }
            resolve();
        });
    });
}

// Render loaded tweets to their respective lists
function renderLoadedTweets() {
    tweetStore.forEach((tweet, id) => {
        if (tweet.status === 'scanner') {
            addTweetCard(tweet, scannerList);
        } else if (tweet.status === 'list') {
            addTweetCard(tweet, listList);
        } else if (tweet.status === 'archive') {
            addTweetCard(tweet, archiveList);
        }
        // Trash items are not rendered (they'll be shown when switching to trash tab)
    });

    // Update empty states
    if (Array.from(tweetStore.values()).some(t => t.status === 'scanner')) {
        removeEmptyState(scannerList);
    }
    if (Array.from(tweetStore.values()).some(t => t.status === 'list')) {
        removeEmptyState(listList);
    }
    if (Array.from(tweetStore.values()).some(t => t.status === 'archive')) {
        removeEmptyState(archiveList);
    }
}

// Clean up old tweets based on time and count limits
function cleanupTweetStore() {
    const now = Date.now();
    const maxAgeMs = TWEET_STORAGE_CONFIG.maxAgeDays * 24 * 60 * 60 * 1000;
    const cutoffTime = now - maxAgeMs;

    // First pass: Remove items older than maxAgeDays (except archived)
    let removedByAge = 0;
    for (const [id, tweet] of tweetStore) {
        // Only clean up scanner and list items by age, keep archive longer
        if ((tweet.status === 'scanner' || tweet.status === 'list') && tweet.timestamp < cutoffTime) {
            tweetStore.delete(id);
            removedByAge++;
        }
    }

    // Second pass: If still over limit, remove oldest items first
    if (tweetStore.size > TWEET_STORAGE_CONFIG.maxItems) {
        const tweets = Array.from(tweetStore.entries());

        // Sort by timestamp (oldest first), prioritize removing scanner items
        tweets.sort((a, b) => {
            // Prioritize removing scanner items over list/archive
            const statusPriority = { 'scanner': 0, 'list': 1, 'trash': 2, 'archive': 3 };
            const aPriority = statusPriority[a[1].status] || 0;
            const bPriority = statusPriority[b[1].status] || 0;
            if (aPriority !== bPriority) return aPriority - bPriority;

            // Then by timestamp (oldest first)
            return (a[1].timestamp || 0) - (b[1].timestamp || 0);
        });

        // Remove oldest items until under limit
        const toRemove = tweetStore.size - TWEET_STORAGE_CONFIG.maxItems;
        for (let i = 0; i < toRemove && i < tweets.length; i++) {
            tweetStore.delete(tweets[i][0]);
        }

        console.log(`Removed ${toRemove} oldest tweets to stay under limit`);
    }

    if (removedByAge > 0) {
        console.log(`Removed ${removedByAge} tweets older than ${TWEET_STORAGE_CONFIG.maxAgeDays} days`);
    }
}

// Aggressive cleanup when storage is nearly full
function aggressiveCleanup() {
    const targetSize = Math.floor(TWEET_STORAGE_CONFIG.maxItems * 0.7); // Keep 70%

    const tweets = Array.from(tweetStore.entries());

    // Sort: scanner first, then list, then trash, archive last; oldest first within each
    tweets.sort((a, b) => {
        const statusPriority = { 'scanner': 0, 'trash': 1, 'list': 2, 'archive': 3 };
        const aPriority = statusPriority[a[1].status] || 0;
        const bPriority = statusPriority[b[1].status] || 0;
        if (aPriority !== bPriority) return aPriority - bPriority;
        return (a[1].timestamp || 0) - (b[1].timestamp || 0);
    });

    // Clear and rebuild with only the newest items
    tweetStore.clear();
    const keepCount = Math.min(targetSize, tweets.length);

    // Add back from the end (newest/most important)
    for (let i = tweets.length - keepCount; i < tweets.length; i++) {
        tweetStore.set(tweets[i][0], tweets[i][1]);
    }

    console.log(`Aggressive cleanup: kept ${tweetStore.size} tweets`);
}
// === KOL & Group Storage (chrome.storage.local for reliability) ===

const STORAGE_KEYS = {
    kols: 'kolStore',
    groups: 'groupStore'
};

let saveKOLsTimeout = null;
let saveGroupsTimeout = null;

// Debounced save for KOLs (using local storage for reliability)
function saveKOLs() {
    if (saveKOLsTimeout) clearTimeout(saveKOLsTimeout);
    saveKOLsTimeout = setTimeout(() => {
        const kols = Array.from(kolStore.values());
        chrome.storage.local.set({ [STORAGE_KEYS.kols]: JSON.stringify(kols) }, () => {
            if (chrome.runtime.lastError) {
                console.error('Failed to save KOLs:', chrome.runtime.lastError);
            } else {
                console.log(`Saved ${kols.length} KOLs to local storage`);
            }
        });
    }, 500);
}

// Load KOLs from storage
function loadKOLs() {
    return new Promise((resolve) => {
        chrome.storage.local.get([STORAGE_KEYS.kols], (result) => {
            if (result[STORAGE_KEYS.kols]) {
                parseAndLoadKOLs(result[STORAGE_KEYS.kols]);
                resolve();
            } else {
                // Try migrating from old localStorage
                migrateKOLsFromLocalStorage();
                resolve();
            }
        });
    });
}

function parseAndLoadKOLs(data) {
    try {
        // Handle both string (old format) and array (new format) data
        const kols = typeof data === 'string' ? JSON.parse(data) : data;
        if (!Array.isArray(kols)) {
            console.error('KOL data is not an array');
            return;
        }
        let migrated = false;
        kols.forEach(kol => {
            // Migration: Assign to default group if no groupId
            if (!kol.groupId) {
                kol.groupId = 'default';
                migrated = true;
            }
            kolStore.set(kol.link, kol);
            addKOLCard(kol);
        });
        if (migrated) saveKOLs();
        if (kolStore.size > 0) {
            removeEmptyState(kolList);
        }
        console.log(`Loaded ${kols.length} KOLs from local storage`);
    } catch (e) {
        console.error('Failed to parse KOLs:', e);
    }
}

// Migrate KOLs from old localStorage
function migrateKOLsFromLocalStorage() {
    const stored = localStorage.getItem('kols');
    if (stored) {
        try {
            const kols = JSON.parse(stored);
            kols.forEach(kol => {
                if (!kol.groupId) kol.groupId = 'default';
                kolStore.set(kol.link, kol);
                addKOLCard(kol);
            });
            if (kolStore.size > 0) {
                removeEmptyState(kolList);
            }
            // Save to new storage
            saveKOLs();
            // Remove old localStorage data
            localStorage.removeItem('kols');
            console.log(`Migrated ${kols.length} KOLs from localStorage to chrome.storage.local`);
        } catch (e) {
            console.error('Failed to migrate KOLs from localStorage:', e);
        }
    }
}

// Debounced save for Groups (using local storage for reliability)
function saveGroups() {
    if (saveGroupsTimeout) clearTimeout(saveGroupsTimeout);
    saveGroupsTimeout = setTimeout(() => {
        const groups = Array.from(groupStore.values());
        chrome.storage.local.set({ [STORAGE_KEYS.groups]: JSON.stringify(groups) }, () => {
            if (chrome.runtime.lastError) {
                console.error('Failed to save groups:', chrome.runtime.lastError);
            } else {
                console.log(`Saved ${groups.length} groups to local storage`);
            }
        });
    }, 500);
}

// Load Groups from storage
function loadGroups() {
    return new Promise((resolve) => {
        chrome.storage.local.get([STORAGE_KEYS.groups], (result) => {
            if (result[STORAGE_KEYS.groups]) {
                parseAndLoadGroups(result[STORAGE_KEYS.groups]);
                ensureDefaultGroup();
                renderStrategyList();
                resolve();
            } else {
                // Try migrating from old localStorage
                migrateGroupsFromLocalStorage();
                ensureDefaultGroup();
                renderStrategyList();
                resolve();
            }
        });
    });
}

function parseAndLoadGroups(data) {
    try {
        const groups = JSON.parse(data);
        groups.forEach(group => {
            groupStore.set(group.id, group);
        });
        console.log(`Loaded ${groups.length} groups from storage`);
    } catch (e) {
        console.error('Failed to parse groups:', e);
    }
}

// Migrate Groups from old localStorage
function migrateGroupsFromLocalStorage() {
    const stored = localStorage.getItem('groups');
    if (stored) {
        try {
            const groups = JSON.parse(stored);
            groups.forEach(group => {
                groupStore.set(group.id, group);
            });
            // Save to new storage
            saveGroups();
            // Remove old localStorage data
            localStorage.removeItem('groups');
            console.log(`Migrated ${groups.length} groups from localStorage to chrome.storage.local`);
        } catch (e) {
            console.error('Failed to migrate groups from localStorage:', e);
        }
    }
}

// Ensure default group always exists
function ensureDefaultGroup() {
    if (!groupStore.has('default')) {
        const defaultGroup = {
            id: 'default',
            name: chrome.i18n.getMessage('group_default_name') || 'Default Strategy',
            color: '#666',
            config: { ...aiConfig }
        };
        groupStore.set('default', defaultGroup);
        saveGroups();
    }
}

// --- Strategy UI Logic ---
function renderStrategyList() {
    if (!strategyList) return;
    strategyList.innerHTML = '';

    groupStore.forEach(group => {
        const card = document.createElement('div');
        card.className = 'strategy-card';
        card.setAttribute('draggable', 'true'); // Enable dragging
        card.dataset.id = group.id; // Store ID for reordering

        if (group.id === 'default') card.classList.add('active'); // Highlight default for now

        card.innerHTML = `
            <div class="strategy-info">
                <div class="strategy-color-dot" style="background-color: ${group.color || '#666'};"></div>
                <div class="strategy-name">${group.name}</div>
            </div>
            <button class="icon-btn strategy-settings-btn" title="${chrome.i18n.getMessage('btn_settings')}">
                <svg class="icon-svg" viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L3.15 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.58 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
            </button>
        `;

        // Click to edit
        card.querySelector('.strategy-settings-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            openStrategySettings(group.id);
        });

        // Drag and Drop Events
        card.addEventListener('dragstart', (e) => {
            card.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
        });

        card.addEventListener('dragend', () => {
            card.classList.remove('dragging');
            document.querySelectorAll('.strategy-card').forEach(c => c.classList.remove('drag-over'));
            saveGroupOrder(); // Save new order
        });

        card.addEventListener('dragover', (e) => {
            e.preventDefault(); // Allow dropping
            const afterElement = getDragAfterElement(strategyList, e.clientY);
            const draggable = document.querySelector('.dragging');
            if (afterElement == null) {
                strategyList.appendChild(draggable);
            } else {
                strategyList.insertBefore(draggable, afterElement);
            }
        });

        strategyList.appendChild(card);
    });

    // Update Select Options in Add KOL Modal
    if (kolGroupSelect) {
        kolGroupSelect.innerHTML = '';
        groupStore.forEach(group => {
            const option = document.createElement('option');
            option.value = group.id;
            option.textContent = group.name;
            kolGroupSelect.appendChild(option);
        });
    }
}

function openStrategySettings(groupId) {
    const group = groupStore.get(groupId);
    if (!group) return;

    strategyIdInput.value = group.id;
    strategyNameInput.value = group.name;
    strategyPromptInput.value = group.config.systemPrompt || aiConfig.prompt; // Fallback to global
    strategyMaxTweetAgeInput.value = group.config.maxTweetAge || 24; // Default 24h
    strategyAutoLikeCheckbox.checked = group.config.autoLike || false;
    strategyAutoRepostCheckbox.checked = group.config.autoRepost || false;
    strategyActiveStartInput.value = group.config.activeHoursStart || '08:00';
    strategyActiveEndInput.value = group.config.activeHoursEnd || '23:00';
    strategyAllDayCheckbox.checked = group.config.allDay || false;

    // Set color
    const color = group.color || '#1d9bf0';
    for (const radio of strategyColorInputs) {
        if (radio.value === color) {
            radio.checked = true;
            break;
        }
    }

    // Toggle inputs
    toggleActiveHoursInputs(strategyAllDayCheckbox.checked);

    // Disable delete for default group
    deleteStrategyBtn.style.display = (groupId === 'default') ? 'none' : 'block';

    strategySettingsModal.classList.remove('hidden');
}

// Event Listeners for Strategy
if (addGroupBtn) {
    addGroupBtn.addEventListener('click', () => {
        strategyIdInput.value = ''; // New group
        strategyNameInput.value = '';
        strategyPromptInput.value = aiConfig.prompt;
        strategyAutoLikeCheckbox.checked = false;
        strategyAutoRepostCheckbox.checked = false;
        strategyActiveStartInput.value = '08:00';
        strategyActiveEndInput.value = '23:00';
        strategyAllDayCheckbox.checked = false;
        // Default color
        if (strategyColorInputs.length > 0) strategyColorInputs[0].checked = true;
        toggleActiveHoursInputs(false);
        deleteStrategyBtn.style.display = 'none';
        strategySettingsModal.classList.remove('hidden');
    });
}

if (cancelStrategyBtn) {
    cancelStrategyBtn.addEventListener('click', () => {
        strategySettingsModal.classList.add('hidden');
    });
}

if (saveStrategyBtn) {
    saveStrategyBtn.addEventListener('click', () => {
        const id = strategyIdInput.value || 'group_' + Date.now();
        const name = strategyNameInput.value || '未命名分组';

        let color = '#1d9bf0';
        for (const radio of strategyColorInputs) {
            if (radio.checked) {
                color = radio.value;
                break;
            }
        }

        const newConfig = {
            systemPrompt: strategyPromptInput.value,
            maxTweetAge: parseInt(strategyMaxTweetAgeInput.value) || 24,
            autoLike: strategyAutoLikeCheckbox.checked,
            autoRepost: strategyAutoRepostCheckbox.checked,
            activeHoursStart: strategyActiveStartInput.value,
            activeHoursEnd: strategyActiveEndInput.value,
            allDay: strategyAllDayCheckbox.checked
        };


        const group = {
            id: id,
            name: name,
            color: color,
            config: newConfig
        };

        groupStore.set(id, group);
        saveGroups();
        renderStrategyList();
        strategySettingsModal.classList.add('hidden');

        // Refresh KOL list to update badges if name changed
        const kols = Array.from(kolStore.values());
        kolList.innerHTML = '';
        kols.forEach(kol => addKOLCard(kol));
    });
}

if (deleteStrategyBtn) {
    deleteStrategyBtn.addEventListener('click', () => {
        const id = strategyIdInput.value;
        if (id && id !== 'default') {
            if (confirm('确定要删除这个策略组吗？组内的 KOL 将被移动到默认组。')) {
                // Migrate KOLs to default
                let migratedCount = 0;
                kolStore.forEach(kol => {
                    if (kol.groupId === id) {
                        kol.groupId = 'default';
                        migratedCount++;
                    }
                });
                if (migratedCount > 0) saveKOLs();

                groupStore.delete(id);
                saveGroups();
                renderStrategyList();
                strategySettingsModal.classList.add('hidden');

                // Refresh KOL list
                const kols = Array.from(kolStore.values());
                kolList.innerHTML = '';
                kols.forEach(kol => addKOLCard(kol));
            }
        }
    });
}

// Batch Add Logic
if (kolBatchAddBtn) {
    kolBatchAddBtn.addEventListener('click', () => {
        batchKOLInput.value = '';
        batchAddKOLModal.classList.remove('hidden');

    });
}

if (cancelBatchKOLBtn) {
    cancelBatchKOLBtn.addEventListener('click', () => {
        batchAddKOLModal.classList.add('hidden');
    });
}

if (saveBatchKOLBtn) {
    saveBatchKOLBtn.addEventListener('click', () => {
        const text = batchKOLInput.value.trim();
        if (!text) {
            batchAddKOLModal.classList.add('hidden');
            return;
        }

        const lines = text.split('\n').filter(line => line.trim() !== '');
        let addedCount = 0;

        lines.forEach(line => {
            const link = line.trim();
            // Basic validation
            if (link.includes('twitter.com') || link.includes('x.com')) {
                // Extract username
                const match = link.match(/(?:twitter\.com|x\.com)\/([^\/]+)/);
                let name = 'Unknown';
                if (match && match[1]) {
                    name = match[1];
                }

                const kolData = {
                    name: name,
                    note: '',
                    link: link,
                    avatar: '', // No avatar for batch add yet
                    addedAt: Date.now()
                };

                kolStore.set(link, kolData);
                addKOLCard(kolData);
                addedCount++;
            }
        });


        if (addedCount > 0) {
            removeEmptyState(kolList);
            saveKOLs(); // Save changes
            showNotification(`已批量添加 ${addedCount} 个 KOL`, false);
        } else {
            showNotification('No valid links found.', true);
        }

        batchAddKOLModal.classList.add('hidden');
    });
}
// Toggle Active Hours Inputs
if (strategyAllDayCheckbox) {
    strategyAllDayCheckbox.addEventListener('change', (e) => {
        toggleActiveHoursInputs(e.target.checked);
    });
}

function toggleActiveHoursInputs(isAllDay) {
    if (isAllDay) {
        strategyActiveStartInput.disabled = true;
        strategyActiveEndInput.disabled = true;
        strategyActiveStartInput.style.opacity = '0.5';
        strategyActiveEndInput.style.opacity = '0.5';
    } else {
        strategyActiveStartInput.disabled = false;
        strategyActiveEndInput.disabled = false;
        strategyActiveStartInput.style.opacity = '1';
        strategyActiveEndInput.style.opacity = '1';
    }
}

// Helper for Drag and Drop
function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.strategy-card:not(.dragging)')];

    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function saveGroupOrder() {
    const newOrder = [];
    const cards = document.querySelectorAll('.strategy-card');
    cards.forEach(card => {
        const id = card.dataset.id;
        if (groupStore.has(id)) {
            newOrder.push(groupStore.get(id));
        }
    });

    // Rebuild Map in new order
    groupStore.clear();
    newOrder.forEach(group => {
        groupStore.set(group.id, group);
    });

    saveGroups(); // Persist to localStorage
}

// ================================
// Daily Report Functions
// ================================

// 全局进度条：固定底部，四个功能共用（AI表格/KOL24h/评论回复/评论者首条）
function showGlobalProgress(opts) {
    if (!globalProgressStrip || !globalProgressTitle || !globalProgressMessage || !globalProgressCount || !globalProgressBar) return;
    const type = opts.type || 'ai';
    const titles = { ai: '🤖 AI自动回复进度', kol24h: '📋 KOL列表24h', commentReply: '💬 评论回复进度', scanAndReply: '🔍 回复评论者首条推文' };
    globalProgressTitle.textContent = opts.title != null ? opts.title : (titles[type] || titles.ai);
    globalProgressCount.textContent = `${opts.current ?? 0}/${opts.total ?? 0}`;
    globalProgressMessage.textContent = opts.message || '处理中...';
    const total = opts.total || 0;
    const current = opts.current || 0;
    const percentage = total > 0 ? Math.min(100, Math.round((current / total) * 100)) : 0;
    globalProgressBar.style.width = `${percentage}%`;
    globalProgressBar.setAttribute('aria-valuenow', percentage);
    const hasSub = opts.subLabel != null && opts.subTotal != null && opts.subTotal > 0;
    if (globalProgressSubRow && globalProgressSubLabel && globalProgressSubCount && globalProgressSubBarWrap && globalProgressSubBar) {
        if (hasSub) {
            globalProgressStrip.classList.add('has-sub');
            globalProgressSubLabel.textContent = opts.subLabel || '当前';
            globalProgressSubCount.textContent = `${opts.subCurrent ?? 0}/${opts.subTotal}`;
            const subPct = opts.subTotal > 0 ? Math.min(100, Math.round(((opts.subCurrent ?? 0) / opts.subTotal) * 100)) : 0;
            globalProgressSubBar.style.width = `${subPct}%`;
            globalProgressSubBar.setAttribute('aria-valuenow', subPct);
        } else {
            globalProgressStrip.classList.remove('has-sub');
        }
    }
    globalProgressStrip.classList.add('visible');
    globalProgressStrip.setAttribute('aria-hidden', 'false');
    document.body.classList.add('global-progress-visible');
}

function hideGlobalProgress() {
    if (!globalProgressStrip) return;
    globalProgressStrip.classList.remove('visible');
    globalProgressStrip.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('global-progress-visible');
}

// 暴露给 comment-reply.js 使用
if (typeof window !== 'undefined') {
    window.updateGlobalProgress = showGlobalProgress;
    window.hideGlobalProgress = hideGlobalProgress;
}

// Update AI progress display（写入底部固定进度条；sub 可选：{ label, current, total } 显示单条/当前单位子进度）
function updateAIProgress(current, total, message, type, sub) {
    const opts = { type: type || 'ai', current, total, message };
    if (sub && (sub.label != null || sub.subLabel != null) && sub.total != null) {
        opts.subLabel = sub.subLabel != null ? sub.subLabel : sub.label;
        opts.subCurrent = sub.current ?? 0;
        opts.subTotal = sub.total;
    }
    showGlobalProgress(opts);
}

// Get date string in YYYY-MM-DD format from timestamp (local timezone)
function getDateString(timestamp) {
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Helper function to generate a one-sentence summary from tweet content (fallback)
function generateTweetSummary(content) {
    if (!content || !content.trim()) {
        return '';
    }
    
    // Try to extract first sentence (ending with 。！？\n)
    const firstSentence = content.match(/^[^。！？\n]+[。！？\n]/);
    if (firstSentence) {
        return firstSentence[0].trim();
    }
    
    // If no sentence ending found, take first 80 characters
    if (content.length > 80) {
        // Try to break at word boundary (space, punctuation)
        const truncated = content.substring(0, 80);
        const lastSpace = truncated.lastIndexOf(' ');
        const lastPunct = Math.max(
            truncated.lastIndexOf('，'),
            truncated.lastIndexOf('。'),
            truncated.lastIndexOf('！'),
            truncated.lastIndexOf('？'),
            truncated.lastIndexOf(','),
            truncated.lastIndexOf('.'),
            truncated.lastIndexOf('!'),
            truncated.lastIndexOf('?')
        );
        const breakPoint = Math.max(lastSpace, lastPunct);
        if (breakPoint > 40) {
            return truncated.substring(0, breakPoint + 1).trim() + '...';
        }
        return truncated.trim() + '...';
    }
    
    return content.trim();
}

// Generate AI-powered tweet summary (similar to XAI's extractPostKeyInfo)
async function generateAITweetSummary(content, kolName, provider, apiKey) {
    if (!content || !content.trim() || !provider || !apiKey) {
        return null;
    }
    
    const summaryPrompt = `请用一句话总结以下推文的核心内容，格式要求：
1. 以"@${kolName}"开头
2. 使用第三人称描述（如"分享"、"提及"、"指出"、"表示"等）
3. 概括推文的主要观点、提及的项目或关键信息
4. 保持简洁，控制在60字以内
5. 如果推文提及项目，必须包含项目名或代币符号

推文内容：
${content}

请直接输出总结，不要添加其他说明文字。示例格式：@用户名 分享个人感悟并提及项目名进展，指出其特点或价值。`;

    try {
        // Use Gemini Flash for faster and cheaper summary generation
        if (provider === 'gemini' || provider === 'gemini-flash') {
            const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: summaryPrompt }] }],
                    generationConfig: { maxOutputTokens: 150, temperature: 0.7 }
                })
            });

            if (!response.ok) {
                const errorText = await response.text().catch(() => '');
                throw new Error(`API错误 ${response.status}: ${errorText.substring(0, 100)}`);
            }

            const data = await response.json();
            const summary = data.candidates?.[0]?.content?.parts?.[0]?.text;
            if (summary) {
                return summary.trim();
            }
        }
        // Other providers: use callAI
        else {
            const summary = await callAI(provider, apiKey, '你是一个内容总结助手，请用简洁的一句话概括推文核心内容。', summaryPrompt);
            if (summary) {
                return summary.trim();
            }
        }
    } catch (e) {
        console.error('[generateAITweetSummary] Failed to generate AI summary:', e);
    }

    // Fallback: return null to use simple summary
    return null;
}

// Helper function to get content from sheets store
function getContentFromSheets(tweetId, kolLink, normalizedUrl) {
    if (!sheetsTweetsStore || sheetsTweetsStore.size === 0) {
        return null;
    }
    
    // Try to find in sheetsTweetsStore by URL
    let sheetTweet = null;
    
    // Try by normalized URL first
    if (normalizedUrl) {
        const normalized = normalizedUrl.replace(/\/$/, '').split('?')[0];
        sheetTweet = sheetsTweetsStore.get(normalized);
    }
    
    // Try by kolLink if not found
    if (!sheetTweet && kolLink) {
        const normalizedKolLink = kolLink.replace(/\/$/, '').split('?')[0];
        sheetTweet = sheetsTweetsStore.get(normalizedKolLink);
    }
    
    // Try by tweetId (construct URL or find by ID)
    if (!sheetTweet && tweetId) {
        // Try to find by iterating (fallback)
        for (const [url, data] of sheetsTweetsStore.entries()) {
            const sheetTweetId = data['推文ID'] || data['Tweet ID'] || data['id'] || '';
            if (sheetTweetId === tweetId || url.includes(tweetId)) {
                sheetTweet = data;
                break;
            }
        }
    }
    
    if (sheetTweet) {
        const content = sheetTweet['推文全文'] || sheetTweet['Tweet Full Text'] || sheetTweet['fullText'] || sheetTweet['推文内容'] || '';
        if (content && content.trim()) {
            console.log('[getContentFromSheets] Found content from sheets, length:', content.length);
            return content;
        }
    }
    
    return null;
}

// Add post to daily report
function addPostToReport(postData) {
    const dateKey = getDateString(postData.timestamp);

    if (!dailyReportStore.has(dateKey)) {
        dailyReportStore.set(dateKey, { posts: [], summary: null });
    }

    const report = dailyReportStore.get(dateKey);

    // Get content - try from postData first, then from sheets
    let content = postData.content || '';
    if (!content || !content.trim()) {
        const sheetsContent = getContentFromSheets(postData.tweetId, postData.kolLink, postData.normalizedUrl);
        if (sheetsContent) {
            content = sheetsContent;
            console.log('[addPostToReport] Using content from sheets for:', postData.kolName);
        }
    }
    
    // Generate simple summary first (fallback)
    const simpleSummary = generateTweetSummary(content);

    // Check if post already exists
    const exists = report.posts.some(p => p.tweetId === postData.tweetId);
    if (!exists) {
        const newPost = {
            tweetId: postData.tweetId,
            kolName: postData.kolName,
            kolLink: postData.kolLink,
            normalizedUrl: postData.normalizedUrl || postData.kolLink,
            timestamp: postData.timestamp,
            content: simpleSummary, // Store simple summary first, will be updated by AI
            fullContent: content, // Store full content for reference
            replyText: postData.replyText || '', // AI回复内容
            addedAt: Date.now() // This is the reply time
        };
        
        report.posts.push(newPost);
        dailyReportStore.set(dateKey, report);
        saveDailyReports();
        console.log(`Added post to report for ${dateKey}: @${postData.kolName}, content length: ${content.length}`);
    } else {
        // Update existing post with reply text and content if provided
        const existingPost = report.posts.find(p => p.tweetId === postData.tweetId);
        if (existingPost) {
            if (postData.replyText) {
                existingPost.replyText = postData.replyText;
            }
            // Always update content if provided or if current content is empty
            if ((postData.content && postData.content.trim()) || (!existingPost.content || !existingPost.content.trim())) {
                const newContent = postData.content || content;
                if (newContent && newContent.trim()) {
                    // Use simple summary (no AI generation)
                    existingPost.content = simpleSummary; // Use simple summary
                    existingPost.fullContent = newContent; // Store full content
                    existingPost.normalizedUrl = postData.normalizedUrl || existingPost.normalizedUrl || existingPost.kolLink;
                    console.log(`Updated content for existing post: @${postData.kolName}`);
                }
            }
            if (!existingPost.addedAt) {
                existingPost.addedAt = Date.now(); // Set reply time if not set
            }
            dailyReportStore.set(dateKey, report);
            saveDailyReports();
            console.log(`Updated post for ${dateKey}: @${postData.kolName}`);
        }
    }
}

// [已移除] AI总结功能 - 已改为显示推文部分内容
// Asynchronously generate AI summary and update the post
// async function generateAndUpdateAISummary(tweetId, content, kolName, dateKey) {
//     // Check if AI config is available
//     if (!aiConfig || !aiConfig.provider || !aiConfig.apiKey) {
//         console.log('[generateAndUpdateAISummary] AI config not available, skipping AI summary');
//         return;
//     }
//     
//     try {
//         console.log(`[generateAndUpdateAISummary] Generating AI summary for @${kolName}...`);
//         const aiSummary = await generateAITweetSummary(content, kolName, aiConfig.provider, aiConfig.apiKey);
//         
//         if (aiSummary) {
//             // Update the post with AI summary
//             const report = dailyReportStore.get(dateKey);
//             if (report) {
//                 const post = report.posts.find(p => p.tweetId === tweetId);
//                 if (post) {
//                     post.content = aiSummary;
//                     dailyReportStore.set(dateKey, report);
//                     saveDailyReports();
//                     console.log(`[generateAndUpdateAISummary] Updated AI summary for @${kolName}: ${aiSummary.substring(0, 50)}...`);
//                     
//                     // Real-time update interaction trace if currently viewing it
//                     if (viewReport && viewReport.classList.contains('active')) {
//                         console.log('[generateAndUpdateAISummary] Real-time updating interaction trace');
//                         renderDailyReportDebounced(true); // Use debounced version to preserve scroll
//                     }
//                 }
//             }
//     } else {
//             console.log(`[generateAndUpdateAISummary] AI summary generation failed for @${kolName}, keeping simple summary`);
//         }
//     } catch (error) {
//         console.error(`[generateAndUpdateAISummary] Error generating AI summary for @${kolName}:`, error);
//     }
// }

// Debounce timer for renderDailyReport to avoid frequent updates
let renderDailyReportDebounceTimer = null;

// Render all interaction traces, sorted by reply time (newest first)
function renderDailyReport(dateStr, preserveScroll = true) {
    if (!reportPostsList) {
        console.warn('reportPostsList not found');
        return;
    }

    // Save scroll position before re-rendering (only if preserveScroll is true)
    let savedScrollTop = 0;
    let wasScrolled = false;
    if (preserveScroll) {
        const scrollContainer = reportPostsList.parentElement || reportPostsList;
        savedScrollTop = scrollContainer.scrollTop || reportPostsList.scrollTop || 0;
        wasScrolled = savedScrollTop > 0;
    }

    console.log('[renderDailyReport] Rendering all interaction traces');
    console.log('[renderDailyReport] dailyReportStore keys:', Array.from(dailyReportStore.keys()));

    // Collect all posts from all dates
    const allPosts = [];
    dailyReportStore.forEach((report, dateKey) => {
        if (report && report.posts && report.posts.length > 0) {
            report.posts.forEach(post => {
                // Only include posts that have reply text (actually replied)
                if (post.replyText) {
                    console.log('[renderDailyReport] Post data:', {
                        kolName: post.kolName,
                        content: post.content,
                        contentLength: post.content?.length || 0,
                        replyText: post.replyText?.substring(0, 50),
                        timestamp: post.timestamp
                    });
                    allPosts.push({
                        ...post,
                        replyTimestamp: post.addedAt || post.timestamp // Use addedAt as reply time, fallback to timestamp
                    });
                }
            });
        }
    });

    console.log('[renderDailyReport] Total posts with replies:', allPosts.length);

    if (allPosts.length === 0) {
        reportPostsList.innerHTML = `<div class="empty-state">${chrome.i18n.getMessage('report_no_posts') || '暂无互动记录'}</div>`;
        return;
    }

    // Sort by reply time (newest first)
    allPosts.sort((a, b) => (b.replyTimestamp || 0) - (a.replyTimestamp || 0));

    // Render all posts in flat list (no grouping, no collapsing)
    let html = '';
    allPosts.forEach((post, index) => {
        // Format tweet time: MM/DD HH:mm
        const tweetDate = new Date(post.timestamp);
        const tweetTimeStr = `${String(tweetDate.getMonth() + 1).padStart(2, '0')}/${String(tweetDate.getDate()).padStart(2, '0')} ${String(tweetDate.getHours()).padStart(2, '0')}:${String(tweetDate.getMinutes()).padStart(2, '0')}`;
        
        // Format reply time: MM/DD HH:mm
        const replyDate = new Date(post.replyTimestamp || post.timestamp);
        const replyTimeStr = `${String(replyDate.getMonth() + 1).padStart(2, '0')}/${String(replyDate.getDate()).padStart(2, '0')} ${String(replyDate.getHours()).padStart(2, '0')}:${String(replyDate.getMinutes()).padStart(2, '0')}`;
        
        // Get content and display summary - check if AI summary exists
        const replyDisplay = post.replyText || '';
        let contentDisplay = post.content || '';
        let fullContent = post.fullContent || '';
        
        // Determine full content source if missing
        if (!fullContent || !fullContent.trim()) {
            if (post.content && post.content.trim() && post.content.length > 100) {
                // If content is too long (old data with full content), use it as fullContent
                fullContent = post.content;
            } else {
                // Try to get from sheets
                const sheetsContent = getContentFromSheets(post.tweetId, post.kolLink, post.normalizedUrl);
                if (sheetsContent) {
                    fullContent = sheetsContent;
                }
            }
        }
        
        // Generate simple summary from full content if needed
        if (fullContent && fullContent.trim() && !contentDisplay) {
            // No summary at all, generate simple one
            contentDisplay = generateTweetSummary(fullContent);
            
            // Update the post in store
            const dateKey = getDateString(post.timestamp);
            const report = dailyReportStore.get(dateKey);
            if (report) {
                const existingPost = report.posts.find(p => p.tweetId === post.tweetId);
                if (existingPost) {
                    existingPost.content = contentDisplay;
                    existingPost.fullContent = fullContent;
                    dailyReportStore.set(dateKey, report);
                    saveDailyReports();
                }
            }
        } else if (!contentDisplay || !contentDisplay.trim()) {
            // Still no content, show placeholder
            if (post.tweetId) {
                contentDisplay = '[推文内容已丢失，点击跳转查看]';
            } else {
                contentDisplay = '[内容不可用]';
            }
        }
        
        // Build tweet link
        let tweetLink = '';
        if (post.tweetId && post.kolName) {
            tweetLink = `https://x.com/${post.kolName}/status/${post.tweetId}`;
        } else if (post.kolLink) {
            tweetLink = post.kolLink;
        }

        // Split content into two lines (approximately 100 chars per line for smaller font)
        const maxCharsPerLine = 100;
        let line1Content = '';
        let line2Content = '';
        
        if (contentDisplay.length <= maxCharsPerLine) {
            line1Content = contentDisplay;
            line2Content = '';
        } else if (contentDisplay.length <= maxCharsPerLine * 2) {
            line1Content = contentDisplay.substring(0, maxCharsPerLine);
            line2Content = contentDisplay.substring(maxCharsPerLine);
        } else {
            line1Content = contentDisplay.substring(0, maxCharsPerLine);
            line2Content = contentDisplay.substring(maxCharsPerLine, maxCharsPerLine * 2) + '...';
        }

        html += `
            <div class="report-post-item" style="padding: 10px; margin-bottom: 8px; border-bottom: 1px solid var(--border-color);">
                <div style="display: flex; align-items: flex-start; gap: 8px;">
                    <div style="flex: 1; min-width: 0;">
                        <div style="font-size: 11px; color: var(--text-color); line-height: 1.4; margin-bottom: 2px;">
                            <span style="color: var(--text-secondary);">${tweetTimeStr}</span>
                            <span style="color: var(--primary-color); margin-left: 4px;">@${post.kolName || 'Unknown'}</span>
                            ${line1Content ? `<span style="margin-left: 4px;">${line1Content}</span>` : ''}
                                </div>
                        ${line2Content ? `
                        <div style="font-size: 11px; color: var(--text-color); line-height: 1.4; margin-bottom: 2px; padding-left: ${tweetTimeStr.length * 6 + 20}px;">
                            ${line2Content}
                            </div>
                        ` : ''}
                        <div style="font-size: 11px; color: var(--text-secondary); line-height: 1.4;">
                            <span style="color: var(--text-secondary);">${replyTimeStr}</span>
                            <span style="margin-left: 4px;">回复内容：${replyDisplay}</span>
                        </div>
                    </div>
                    ${tweetLink ? `
                    <button class="tweet-link-btn" data-tweet-link="${tweetLink}" 
                        style="flex-shrink: 0; padding: 4px 6px; background: transparent; border: 1px solid var(--border-color); border-radius: 4px; cursor: pointer; color: var(--text-secondary); display: flex; align-items: center; justify-content: center;"
                        title="跳转到推文">
                        <svg class="icon-svg" viewBox="0 0 24 24" style="width: 12px; height: 12px;">
                            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6m4-3h6v6m-11 5L21 3" fill="none" stroke="currentColor" stroke-width="2"/>
                        </svg>
                    </button>
                    ` : ''}
                </div>
            </div>
        `;
    });
    
    reportPostsList.innerHTML = html;

    // Add click handlers for tweet link buttons
    reportPostsList.querySelectorAll('.tweet-link-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            const link = btn.getAttribute('data-tweet-link');
            if (link) {
                console.log('[renderDailyReport] Opening tweet link:', link);
                window.open(link, '_blank');
            }
        });
    });

    // Restore scroll position after re-rendering (only if preserveScroll is true)
    if (preserveScroll) {
        // Use requestAnimationFrame to ensure DOM is fully updated
        requestAnimationFrame(() => {
            const scrollContainer = reportPostsList.parentElement || reportPostsList;
            if (wasScrolled && savedScrollTop > 0) {
                // Restore the saved scroll position
                scrollContainer.scrollTop = savedScrollTop;
                if (reportPostsList.scrollTop !== undefined) {
                    reportPostsList.scrollTop = savedScrollTop;
                }
                console.log('[renderDailyReport] Restored scroll position:', savedScrollTop);
            }
        });
    }
}

// Debounced version of renderDailyReport for real-time updates
function renderDailyReportDebounced(preserveScroll = true) {
    // Clear existing timer
    if (renderDailyReportDebounceTimer) {
        clearTimeout(renderDailyReportDebounceTimer);
    }
    
    // Set new timer (debounce for 500ms)
    renderDailyReportDebounceTimer = setTimeout(() => {
        renderDailyReport(undefined, preserveScroll);
        renderDailyReportDebounceTimer = null;
    }, 500);
}

// Date picker removed - no longer needed



// Extract key info from a single post
// Gemini: uses Flash for extraction (token optimization)
// Other AIs: use same provider (no optimization, for consistency/debugging)
async function extractPostKeyInfo(content, kolName, provider, apiKey) {
    const extractPrompt = `请从以下推文中提取关键信息，必须按照固定格式输出所有字段：

【推文内容】
${content}

【必须输出的格式】（每个字段都要填写，不能省略）：
话题：[推文讨论的主题，如：DeFi/AI/Meme/基础设施/空投等]
情绪：[看多/看空/中性]
提及项目：[必须用$符号标注项目代币，如 $BTC, $ETH, $SOL, $ORDER, $APEX 等。仔细查找推文中@提及的项目名、链接中的项目名、讨论的协议名。如果确实没有则写"无"]
是否营销：[是/否，如果带邀请链接、推广码、活动链接则为"是"]
一句话摘要：[用30字内概括核心内容，必须包含项目名]`;

    try {
        // Gemini: Use Flash for extraction (cheaper and faster)
        if (provider === 'gemini' || provider === 'gemini-flash') {
            const model = provider === 'gemini-flash' ? 'gemini-3-flash-preview' : 'gemini-3-pro-preview';
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: extractPrompt }] }],
                    generationConfig: {
                        maxOutputTokens: 8000,
                        thinkingConfig: { includeThoughts: false } // Disable thinking to save tokens
                    }
                })
            });

            const data = await response.json();
            const extracted = data.candidates?.[0]?.content?.parts?.[0]?.text;
            if (extracted) return extracted.trim();
        }
        // Other providers: use callAI with same provider
        else {
            const extracted = await callAI(provider, apiKey, '你是一个内容分析助手，请严格按照要求的格式提取信息。', extractPrompt);
            if (extracted) return extracted.trim();
        }
    } catch (e) {
        console.error('Extract failed:', e);
    }

    // Fallback: return truncated content
    return content.substring(0, 80) + '...';
}

// Generate 7-day AI summary
if (generate7DaySummaryBtn) {
    generate7DaySummaryBtn.addEventListener('click', async () => {
        const dateStr = reportDatePicker ? reportDatePicker.value : getDateString(Date.now());
        const posts = getPostsForDateRange(dateStr, 7);

        if (posts.length === 0) {
            showNotification('过去7日无帖子可分析', true);
            return;
        }

        if (!aiConfig.apiKey) {
            showNotification(chrome.i18n.getMessage('notification_api_key_required'), true);
            return;
        }

        generate7DaySummaryBtn.disabled = true;
        generate7DaySummaryBtn.textContent = '生成中...';

        try {
            const postsText = posts.map(p => {
                const date = new Date(p.timestamp).toLocaleDateString('zh-CN');
                return `@${p.kolName} (${date}): ${p.content}`;
            }).join('\n\n');

            const systemPrompt = `你是一个加密货币市场分析专家。请分析以下过去7天KOL的推文，生成专业的周度分析报告。

重要要求：
1. 分析时必须明确引用KOL名字，例如"@xxx 认为..."、"@yyy 多次提到$ABC..."
2. 不要空洞分析，要具体指出谁说了什么

请严格按照以下HTML格式输出：

<h3>📊 ${dateStr} KOL互动周报</h3>

<h4>1. 🏷️ 本周热门关键词 (按提及次数排序)</h4>
<p>列出本周KOL们提及最多的项目代币、板块、话题，格式：$TOKEN (X次)、板块名 (Y次)</p>

<h4>2. 🔄 叙事轮动复盘</h4>
<ul>
<li><strong>本周主线</strong>：资金/注意力从 [上周板块] 转移到了 [本周板块]，具体引用谁在讨论</li>
<li><strong>证伪板块</strong>：上周热炒但本周已无人提及的板块</li>
</ul>

<h4>3. 🧠 深度逻辑合集 (Smart Money View)</h4>
<p>汇总本周高质量的分析帖，必须标注是谁发布的：</p>
<ul>
<li><strong>宏观/赛道</strong>：@xxx 认为...，@yyy 预测...</li>
<li><strong>技术/基建</strong>：@zzz 分析了...</li>
</ul>

<h4>4. 🚨 本周营销预警</h4>
<p>列出本周疑似付费推广的帖子，标明是哪位KOL在哪天发布的</p>`;

            const summary = await callAI(aiConfig.provider, aiConfig.apiKey, systemPrompt, postsText);

            if (summary) {
                const summaryKey = `7day_${dateStr}`;
                dailyReportStore.set(summaryKey, { posts: [], summary: summary });
                saveDailyReports();
                renderDailyReport(dateStr, false); // Reset scroll when generating summary
                showNotification('7日总结生成成功', false);
            } else {
                showNotification('生成失败，请重试', true);
            }
        } catch (error) {
            console.error('Failed to generate 7-day summary:', error);
            showNotification('生成失败: ' + error.message, true);
        } finally {
            generate7DaySummaryBtn.disabled = false;
            generate7DaySummaryBtn.textContent = chrome.i18n.getMessage('btn_generate_summary') || '生成总结';
        }
    });
}

// Persistence for daily reports
function saveDailyReports() {
    const reportsArray = Array.from(dailyReportStore.entries()).map(([key, value]) => ({
        date: key,
        ...value
    }));
    localStorage.setItem('dailyReports', JSON.stringify(reportsArray));
}

function loadDailyReports() {
    const stored = localStorage.getItem('dailyReports');
    if (stored) {
        try {
            const reports = JSON.parse(stored);
            console.log('[loadDailyReports] Loading', reports.length, 'reports from storage');
            reports.forEach(report => {
                dailyReportStore.set(report.date, {
                    posts: report.posts || [],
                    summary: report.summary || null
                });
                console.log('[loadDailyReports] Loaded report for', report.date, 'with', (report.posts || []).length, 'posts');
            });
            console.log('[loadDailyReports] Total dates in store:', Array.from(dailyReportStore.keys()));
        } catch (e) {
            console.error('Failed to load daily reports:', e);
        }
    } else {
        console.log('[loadDailyReports] No stored reports found');
    }
}

// Load reports on startup
loadDailyReports();

// ================================
// List Action Buttons
// ================================

// State for list AI reply
let listAIState = {
    active: false,
    currentIndex: 0,
    list: []
};

// Start AI Reply for List Items
function startListAIReply() {
    if (listAIState.active) {
        // Already running, stop it
        stopListAIReply();
        return;
    }

    if (!aiConfig.apiKey) {
        showNotification(chrome.i18n.getMessage('notification_api_key_required'), true);
        return;
    }

    // Get all tweets in list
    const listItems = Array.from(tweetStore.values()).filter(t => t.status === 'list');

    if (listItems.length === 0) {
        showNotification('列表中没有可回复的推文', true);
        return;
    }

    listAIState.active = true;
    listAIState.list = listItems;
    listAIState.currentIndex = 0;

    // Update button UI
    listAIReplyBtn.classList.add('active-state');
    listAIReplyBtn.innerHTML = `
        <div class="jumping-text">
            <span>A</span><span>i</span><span>n</span><span>g</span>
        </div>
    `;

    showNotification(`开始 AI 回复 ${listItems.length} 条推文...`, false);
    processNextListAIReply();
}

function stopListAIReply() {
    listAIState.active = false;
    listAIState.list = [];
    listAIState.currentIndex = 0;

    // Reset button UI
    listAIReplyBtn.classList.remove('active-state');
    listAIReplyBtn.innerHTML = `
        <svg class="icon-svg" viewBox="0 0 24 24">
            <path d="M12 2c1.1 0 2 .9 2 2h5.5c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2h-15c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2H10c0-1.1.9-2 2-2zm0 2c-.55 0-1 .45-1 1s.45 1 1 1 1-.45 1-1-.45-1-1-1zm-7 6h14v-2H5v2zm0 2v8h14v-8H5zm2 2h2v2H7v-2zm8 0h2v2h-2v-2z"/>
        </svg>
    `;
}

async function processNextListAIReply() {
    if (!listAIState.active) return;

    if (listAIState.currentIndex >= listAIState.list.length) {
        // All done
        showNotification(`AI 回复完成，共处理 ${listAIState.list.length} 条推文`, false);
        stopListAIReply();
        return;
    }

    const tweet = listAIState.list[listAIState.currentIndex];

    // Get KOL for this tweet to determine strategy
    let kolGroup = groupStore.get('default');
    const tweetUsername = tweet.username?.toLowerCase();

    if (tweetUsername) {
        // Find matching KOL by username
        for (const kol of kolStore.values()) {
            const kolUsernameMatch = kol.link.match(/(?:twitter\.com|x\.com)\/([^\/]+)/);
            if (kolUsernameMatch && kolUsernameMatch[1].toLowerCase() === tweetUsername) {
                kolGroup = groupStore.get(kol.groupId || 'default') || groupStore.get('default');
                break;
            }
        }
    }

    const groupConfig = kolGroup.config || {};

    // Build system prompt from default + group
    // Priority: aiConfig.systemPrompt (global) > group systemPrompt > default group systemPrompt
    const defaultGroup = groupStore.get('default');
    const defaultPrompt = defaultGroup ? (defaultGroup.config.systemPrompt || '') : '';
    const groupPrompt = kolGroup.id !== 'default' ? (groupConfig.systemPrompt || '') : '';
    
    // Use global aiConfig.systemPrompt if available, otherwise build from groups
    let systemPrompt = aiConfig.systemPrompt || defaultPrompt;
    if (!aiConfig.systemPrompt && groupPrompt) {
        systemPrompt += `\n\n${groupPrompt}`;
    } else if (aiConfig.systemPrompt && groupPrompt) {
        // If global prompt exists, append group prompt to it
        systemPrompt += `\n\n${groupPrompt}`;
    }

    const autoLike = groupConfig.autoLike || false;
    const autoRepost = groupConfig.autoRepost || false;

    // Navigate and reply
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0] || !listAIState.active) return;

        const tabId = tabs[0].id;
        chrome.tabs.update(tabId, { url: tweet.url });

        const checkTabStatus = setInterval(() => {
            if (!listAIState.active) {
                clearInterval(checkTabStatus);
                return;
            }

            chrome.tabs.get(tabId, async (tab) => {
                if (chrome.runtime.lastError || !tab) {
                    clearInterval(checkTabStatus);
                    return;
                }

                if (tab.status === 'complete') {
                    clearInterval(checkTabStatus);

                    // Wait for content to render
                    setTimeout(async () => {
                        if (!listAIState.active) return;

                        try {
                            const response = await chrome.tabs.sendMessage(tabId, { action: 'SCRAPE_TWEET_CONTENT' });

                            // Check if this is own tweet - skip if so
                            if (response && response.isOwnTweet) {
                                console.log(`Skipping reply - this is your own tweet (@${response.tweetAuthor})`);
                                
                                // Mark as processed and move to next
                                listAIState.currentIndex++;
                                if (listAIState.currentIndex < listAIState.list.length) {
                                    setTimeout(() => {
                                        processNextListAIReply();
                                    }, 1000);
                                } else {
                                    stopListAIReply();
                                }
                                return;
                            }

                            if (response && response.content) {
                                const replyText = await callAI(aiConfig.provider, aiConfig.apiKey, systemPrompt, response.content);

                                if (!listAIState.active) return;

                                if (replyText) {
                                    const replyDelayMin = parseInt(aiConfig.replyDelayMin) || 3;
                                    const replyDelayMax = parseInt(aiConfig.replyDelayMax) || 7;
                                    const likeDelayMin = parseInt(aiConfig.likeDelayMin) || 1;
                                    const likeDelayMax = parseInt(aiConfig.likeDelayMax) || 5;

                                    await chrome.tabs.sendMessage(tabId, {
                                        action: 'PERFORM_ACTIONS',
                                        payload: {
                                            replyText: replyText,
                                            doLike: autoLike,
                                            doRepost: autoRepost,
                                            replyDelay: { min: replyDelayMin, max: replyDelayMax },
                                            likeDelay: { min: likeDelayMin, max: likeDelayMax },
                                            postReplyWaitMin: parseInt(aiConfig.postReplyWaitMin) || 5,
                                            postReplyWaitMax: parseInt(aiConfig.postReplyWaitMax) || 15
                                        }
                                    });

                                    // Update local state and archive
                                    const data = tweetStore.get(tweet.id);
                                    if (data) {
                                        data.interactions.reply = true;
                                        if (autoLike) data.interactions.like = true;
                                        if (autoRepost) data.interactions.retweet = true;
                                        tweetStore.set(tweet.id, data);

                                        // Auto-archive
                                        const card = listList.querySelector(`.tweet-card[data-id="${tweet.id}"]`);
                                        if (card) {
                                            moveToArchive(tweet.id, card);
                                        }
                                    }
                                }
                            }
                        } catch (e) {
                            console.error('Error processing list AI reply:', e);
                        }

                        // Move to next
                        listAIState.currentIndex++;

                        // Random delay before next (3-5s)
                        const delay = 3000 + Math.random() * 2000;
                        setTimeout(() => {
                            processNextListAIReply();
                        }, delay);
                    }, 5000);
                }
            });
        }, 500);
    });
}

// Clear List to Trash
function clearListToTrash() {
    const listItems = Array.from(tweetStore.values()).filter(t => t.status === 'list');

    if (listItems.length === 0) {
        showNotification('列表已为空', false);
        return;
    }

    // Move all to trash
    let clearedCount = 0;
    listItems.forEach(tweet => {
        tweet.status = 'trash';
        tweet.deletedAt = Date.now();
        tweetStore.set(tweet.id, tweet);

        // Remove card from list
        const card = listList.querySelector(`.tweet-card[data-id="${tweet.id}"]`);
        if (card) {
            card.remove();
        }
        clearedCount++;
    });

    saveTweets();
    checkEmptyState(listList);

    showNotification(`已将 ${clearedCount} 条推文移至垃圾箱`, false);
}

// Wire up click handlers
if (listAIReplyBtn) {
    listAIReplyBtn.addEventListener('click', startListAIReply);
}

if (listClearBtn) {
    listClearBtn.addEventListener('click', clearListToTrash);
}


// === Summary View (归纳整理) Functions ===

// Blocklist: Loaded dynamically from external file
let PROJECT_BLOCKLIST = new Set();

// Load blocklist from external JSON file
async function loadProjectBlocklist() {
    try {
        const response = await fetch(chrome.runtime.getURL('src/project_blocklist.json'));
        const data = await response.json();
        if (data.blocklist && Array.isArray(data.blocklist)) {
            PROJECT_BLOCKLIST = new Set(data.blocklist.map(s => s.toLowerCase()));
            console.log(`Loaded ${PROJECT_BLOCKLIST.size} blocked projects`);
        }
    } catch (e) {
        console.error('Failed to load project blocklist:', e);
    }
}

// Helper function to check if a project should be blocked
function isProjectBlocked(projectName) {
    if (!projectName) return false;
    // Remove ALL non-alphanumeric characters (including underscores)
    const normalized = projectName.toLowerCase().replace(/[^a-z0-9]/g, '');
    return PROJECT_BLOCKLIST.has(normalized);
}

// AI prompt for extracting project info from tweets
const PROJECT_EXTRACTION_PROMPT = `你是一个加密货币/Web3领域专家。请分析以下推文，提取其中提到的**Web3原生项目**信息。

【推文内容】
{TWEET_CONTENT}

【KOL信息】
作者名: {AUTHOR_NAME}
作者ID: @{AUTHOR_USERNAME}

请严格按照以下JSON格式输出，不要有任何其他文字：
{
  "projects": [
    {
      "name": "项目名称（如 Uniswap、Solana、Arbitrum 等）",
      "officialHandle": "@官方推特ID（如推文中有@提及则使用，否则请识别该项目的官方推特）"
    }
  ],
  "summary": "一句话概括推文核心内容（不超过50字，不要带@符号）"
}

**必须排除以下类型（不要放入projects数组）**：
- 中心化交易所：Binance、OKX、Bybit、Bitget、Coinbase、Kraken、KuCoin、Gate、HTX、Huobi、MEXC 等
- 传统科技公司：Google、Apple、Microsoft、Amazon、Meta、Tesla、Nvidia、OpenAI、Anthropic、Adobe 等
- 传统金融机构：BlackRock、JPMorgan、Goldman Sachs、Fidelity、Grayscale、Visa、Mastercard、PayPal 等
- 基础代币/非项目：Bitcoin、BTC、ETH、USDT、USDC 等
- 媒体账号：CoinDesk、CoinTelegraph、Bloomberg、Reuters、Forbes 等

注意：
1. 只提取Web3原生项目（DeFi、NFT、Layer2、GameFi、DAO、基础设施等）
2. 如果推文中直接@了项目官方账号，优先使用该账号作为officialHandle
3. 如果推文中只提到项目名但没有@，请识别该项目的官方推特账号
4. 如果推文提到多个项目，projects数组中应包含所有项目
5. 如果没有识别到任何Web3原生项目，返回空的projects数组
6. summary中的项目名不需要@符号，直接用项目名即可`;

// Calculate heat score for a tweet
// Formula: (浏览量×1 + 评论×100 + 转推×100 + 点赞×50) / 100，四舍五入
function calculateHeatScore(tweet) {
    const views = parseFloat(tweet.views) || 0;
    const replies = parseFloat(tweet.replies) || 0;
    const retweets = parseFloat(tweet.retweets) || 0;
    const likes = parseFloat(tweet.likes) || 0;

    const rawScore = (views * 1) + (replies * 100) + (retweets * 100) + (likes * 50);
    return Math.round(rawScore / 100);
}

// Extract project info from a tweet using AI
async function extractProjectsFromTweet(tweet, provider, apiKey) {
    const prompt = PROJECT_EXTRACTION_PROMPT
        .replace('{TWEET_CONTENT}', tweet.content || '')
        .replace('{AUTHOR_NAME}', tweet.authorName || tweet.username || '')
        .replace('{AUTHOR_USERNAME}', tweet.username || '');

    try {
        // Use Gemini for extraction
        if (provider === 'gemini' || provider === 'gemini-flash') {
            const model = provider === 'gemini-flash' ? 'gemini-3-flash-preview' : 'gemini-3-pro-preview';
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: prompt }] }],
                    generationConfig: {
                        maxOutputTokens: 8000,
                        temperature: 0.1,  // Low temperature for more consistent output
                        thinkingConfig: { includeThoughts: false } // Disable thinking to save tokens
                    }
                })
            });

            const data = await response.json();
            const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
            if (text) {
                // Extract JSON from response (handle markdown code blocks and cleanup)
                let jsonStr = text;
                const jsonMatch = text.match(/\{[\s\S]*\}/);
                if (jsonMatch) {
                    jsonStr = jsonMatch[0];
                }

                try {
                    return JSON.parse(jsonStr);
                } catch (parseError) {
                    console.warn('JSON parse failed, trying cleanup:', parseError);
                    // Try improved cleanup: remove potential markdown markers or comments
                    try {
                        // Sometimes AI adds comments like // ... inside JSON which invalidates it
                        const cleaned = jsonStr.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
                        return JSON.parse(cleaned);
                    } catch (e2) {
                        console.error('Failed to parse AI JSON response:', text);
                    }
                }
            }
        } else {
            // Other providers: use callAI
            const result = await callAI(provider, apiKey, '请严格按JSON格式输出，不要有其他文字。', prompt);
            if (result) {
                const jsonMatch = result.match(/\{[\s\S]*\}/);
                if (jsonMatch) {
                    try {
                        return JSON.parse(jsonMatch[0]);
                    } catch (e) {
                        console.error('Failed to parse AI JSON (other provider):', result);
                    }
                }
            }
        }
    } catch (e) {
        console.error('Extract projects failed:', e);
    }

    // Fallback: return empty projects with truncated content as summary
    return {
        projects: [],
        summary: (tweet.content || '').substring(0, 50) + '...'
    };
}

// Store processed project groups for UI and copying
let processedProjectGroups = new Map(); // Map<projectName, {officialHandle, tweets: [{tweet, summary, heatScore}]}>
let lastSummaryDate = '';

// Fetch tweet data from Google Sheets
async function fetchSheetsData() {
    const url = googleSheetsConfig.scriptUrl;
    if (!url) {
        throw new Error('请先在 AI 配置中设置 Google Sheets URL');
    }

    const response = await fetch(`${url}?action=getData`, {
        method: 'GET',
        mode: 'cors'
    });

    if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    if (!data.success) {
        throw new Error(data.error || '获取数据失败');
    }

    return data.tweets || [];
}

// Update summary status display
function updateSummaryStatus(message, type = 'normal') {
    if (!summaryStatus) return;
    summaryStatus.textContent = message;
    summaryStatus.className = 'status-bar';
    if (type === 'loading') summaryStatus.classList.add('loading');
    if (type === 'success') summaryStatus.classList.add('success');
    if (type === 'error') summaryStatus.classList.add('error');
}

// Store the last generated summary for copying (legacy, will be removed in Phase 3)
let lastGeneratedSummary = '';
let lastSummaryTimeRange = '';

// Generate summary post - Phase 1: Project-based grouping
async function generateSummaryPost() {
    // Validate settings
    if (!aiConfig.apiKey) {
        showNotification('请先在 AI 配置中设置 API Key', true);
        return;
    }

    if (!googleSheetsConfig.scriptUrl) {
        showNotification('请先在 AI 配置中设置 Google Sheets URL', true);
        return;
    }

    // Update UI - start loading
    updateSummaryStatus('正在从 Google Sheets 读取数据...', 'loading');
    if (summaryResult) summaryResult.innerHTML = '<div class="empty-state">加载中...</div>';
    if (summaryActions) summaryActions.classList.add('hidden');
    if (generateSummaryPostBtn) generateSummaryPostBtn.disabled = true;

    try {
        // Step 1: Fetch data from Google Sheets
        const allTweets = await fetchSheetsData();

        if (allTweets.length === 0) {
            updateSummaryStatus('表格中没有推文数据', 'error');
            if (summaryResult) summaryResult.innerHTML = '<div class="empty-state">Google Sheets 中没有推文数据，请先同步推文。</div>';
            return;
        }

        // Step 1.5: Filter tweets by datetime (24 hours before selected time)
        let endTime = Date.now();
        let timeLabel = '当前时间';
        let dateStr = new Date().toLocaleDateString('zh-CN');

        if (summaryDatetimeInput && summaryDatetimeInput.value) {
            endTime = new Date(summaryDatetimeInput.value).getTime();
            timeLabel = summaryDatetimeInput.value.replace('T', ' ');
            dateStr = new Date(summaryDatetimeInput.value).toLocaleDateString('zh-CN');
        }

        const startTime = endTime - (24 * 60 * 60 * 1000);

        const tweets = allTweets.filter(t => {
            let tweetTime = 0;
            if (t.timestamp) {
                if (typeof t.timestamp === 'number') {
                    tweetTime = t.timestamp;
                } else if (typeof t.timestamp === 'string') {
                    tweetTime = new Date(t.timestamp).getTime();
                }
            }
            return !tweetTime || (tweetTime >= startTime && tweetTime <= endTime);
        });

        if (tweets.length === 0) {
            updateSummaryStatus(`该时间段内没有推文 (${timeLabel} 前24小时)`, 'error');
            if (summaryResult) summaryResult.innerHTML = `<div class="empty-state">在 ${timeLabel} 前24小时内没有找到推文。请选择其他时间或同步更多推文。</div>`;
            return;
        }

        // Limit to 200 tweets to control AI costs
        const tweetsToProcess = tweets.slice(0, 200);
        updateSummaryStatus(`正在分析 ${tweetsToProcess.length} 条推文（共 ${tweets.length} 条）...`, 'loading');

        // Step 2: Process each tweet - extract projects and calculate heat score
        const projectMap = new Map(); // Map<projectKey, {name, officialHandle, tweets: []}>
        let processedCount = 0;

        for (const tweet of tweetsToProcess) {
            processedCount++;
            if (processedCount % 5 === 0) {
                updateSummaryStatus(`正在分析推文 ${processedCount}/${tweetsToProcess.length}...`, 'loading');
            }

            // Calculate heat score
            const heatScore = calculateHeatScore(tweet);

            // Extract projects using AI
            const extracted = await extractProjectsFromTweet(tweet, aiConfig.provider, aiConfig.apiKey);

            // If no projects found, skip this tweet for project grouping
            if (!extracted.projects || extracted.projects.length === 0) {
                console.log(`No projects found in tweet: ${tweet.content?.substring(0, 50)}...`);
                continue;
            }

            // Add tweet to each mentioned project
            for (const project of extracted.projects) {
                const projectKey = project.name.toLowerCase().trim();

                // Skip blocked projects (exchanges, tech giants, etc.)
                if (isProjectBlocked(project.name)) {
                    console.log(`Skipping blocked project: ${project.name}`);
                    continue;
                }

                if (!projectMap.has(projectKey)) {
                    projectMap.set(projectKey, {
                        name: project.name,
                        officialHandle: project.officialHandle || `@${project.name}`,
                        tweets: []
                    });
                }

                const projectData = projectMap.get(projectKey);
                // Update official handle if we found a new one (prefer @-prefixed handles)
                if (project.officialHandle && project.officialHandle.startsWith('@')) {
                    projectData.officialHandle = project.officialHandle;
                }

                projectData.tweets.push({
                    tweet: tweet,
                    summary: extracted.summary,
                    heatScore: heatScore,
                    kolName: tweet.authorName || tweet.username,
                    kolHandle: tweet.username ? `@${tweet.username}` : ''
                });
            }

            // Small delay to avoid rate limiting
            await new Promise(resolve => setTimeout(resolve, 100));
        }

        // Step 3: Sort by heat score and take top 15 for each project
        for (const [key, data] of projectMap) {
            data.tweets.sort((a, b) => b.heatScore - a.heatScore);
            data.tweets = data.tweets.slice(0, 15);
        }

        // Store for UI rendering (Phase 2) and copying (Phase 3)
        processedProjectGroups = projectMap;
        lastSummaryDate = dateStr;
        lastSummaryTimeRange = `${timeLabel} 前24小时`;

        // Step 4: Render results (Phase 1 - simple text output for testing)
        updateSummaryStatus(`✓ 分析完成！发现 ${projectMap.size} 个项目`, 'success');

        if (summaryResult) {
            if (projectMap.size === 0) {
                summaryResult.innerHTML = '<div class="empty-state">未识别到任何项目。请确保推文中包含项目相关内容。</div>';
            } else {
                // Phase 2: Render UI Cards
                renderProjectGroups(projectMap);
            }
        }

        // Show action buttons
        if (summaryActions) summaryActions.classList.remove('hidden');

        console.log('Processed project groups:', processedProjectGroups);

    } catch (error) {
        console.error('Generate summary failed:', error);
        updateSummaryStatus(`✗ 生成失败: ${error.message}`, 'error');
        if (summaryResult) {
            summaryResult.innerHTML = `<div class="empty-state">生成失败: ${error.message}</div>`;
        }
    } finally {
        if (generateSummaryPostBtn) generateSummaryPostBtn.disabled = false;
    }
}

// Copy summary to clipboard
async function copySummaryToClipboard() {
    // Get date from picker
    let dateStr = '';
    if (summaryDatetimeInput && summaryDatetimeInput.value) {
        const date = new Date(summaryDatetimeInput.value);
        dateStr = `${date.getMonth() + 1}月${date.getDate()}日`;
    } else {
        const now = new Date();
        dateStr = `${now.getMonth() + 1}月${now.getDate()}日`;
    }

    // Chinese number mapping
    const chineseNumbers = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十',
        '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十'];

    // Collect selected tweets from UI, grouped by project
    const projectTweets = new Map(); // Map<projectHandle, {tweets: []}>

    const projectCards = document.querySelectorAll('.project-card');
    projectCards.forEach(card => {
        const header = card.querySelector('.project-header');
        const projectHandle = header?.querySelector('.project-handle')?.textContent || '';

        const tweetItems = card.querySelectorAll('.summary-tweet-item');
        tweetItems.forEach(item => {
            const checkbox = item.querySelector('.tweet-checkbox');
            if (checkbox && checkbox.checked) {
                // Get tweet data from UI
                const kolName = item.querySelector('.tweet-kol')?.textContent || '';
                const kolHandle = item.querySelector('.tweet-handle')?.textContent || '';
                const summaryEl = item.querySelector('.tweet-summary-text');
                // Get full summary from data attribute, fallback to textContent
                const summary = summaryEl?.dataset?.fullSummary || summaryEl?.textContent || '';
                const link = item.querySelector('.tweet-link-ref')?.href || '';

                if (!projectTweets.has(projectHandle)) {
                    projectTweets.set(projectHandle, { tweets: [] });
                }
                projectTweets.get(projectHandle).tweets.push({
                    kolName,
                    kolHandle,
                    summary,
                    link
                });
            }
        });
    });

    if (projectTweets.size === 0) {
        showNotification('请至少选择一条推文', true);
        return;
    }

    // Build formatted output
    let output = '';
    let projectIndex = 0;

    projectTweets.forEach((data, projectHandle) => {
        const projectNumber = chineseNumbers[projectIndex] || (projectIndex + 1);
        output += `${dateStr} 热门项目 ${projectNumber} ${projectHandle} 推文整理\n`;

        data.tweets.forEach((tweet, tweetIndex) => {
            output += `${tweetIndex + 1}. ${tweet.kolName} ${tweet.kolHandle} ${tweet.summary}\n`;
            output += `${tweet.link}\n\n`;
        });

        projectIndex++;
    });

    try {
        await navigator.clipboard.writeText(output.trim());
        showNotification('归纳帖已复制到剪贴板', false);
        if (copySummaryBtn) {
            const originalText = copySummaryBtn.textContent;
            copySummaryBtn.textContent = '✓ 已复制!';
            setTimeout(() => {
                copySummaryBtn.textContent = originalText;
            }, 2000);
        }
    } catch (err) {
        showNotification('复制失败，请手动选择复制', true);
    }
}

// Wire up summary view event handlers
if (generateSummaryPostBtn) {
    generateSummaryPostBtn.addEventListener('click', generateSummaryPost);
}



if (copySummaryBtn) {
    copySummaryBtn.addEventListener('click', copySummaryToClipboard);
}

// Save summary to Google Sheets
async function saveSummaryToSheet() {
    if (!lastGeneratedSummary) {
        showNotification('没有可保存的内容，请先生成归纳帖', true);
        return;
    }

    if (!googleSheetsConfig.scriptUrl) {
        showNotification('请先在 AI 配置中设置 Google Sheets URL', true);
        return;
    }

    if (saveSummaryBtn) {
        saveSummaryBtn.disabled = true;
        saveSummaryBtn.textContent = '保存中...';
    }

    try {
        const response = await fetch(googleSheetsConfig.scriptUrl, {
            method: 'POST',
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'saveSummary',
                content: lastGeneratedSummary,
                timeRange: lastSummaryTimeRange || '未指定'
            })
        });

        if (response.ok) {
            const result = await response.json();
            if (result.success) {
                showNotification('归纳帖已保存到表格', false);
                if (saveSummaryBtn) {
                    saveSummaryBtn.textContent = '✓ 已保存!';
                    setTimeout(() => {
                        saveSummaryBtn.textContent = '💾 保存到表格';
                    }, 2000);
                }
            } else {
                throw new Error(result.error || '保存失败');
            }
        } else {
            throw new Error('HTTP ' + response.status);
        }
    } catch (error) {
        console.error('Save summary failed:', error);
        showNotification('保存失败: ' + error.message, true);
    } finally {
        if (saveSummaryBtn) {
            saveSummaryBtn.disabled = false;
            if (saveSummaryBtn.textContent === '保存中...') {
                saveSummaryBtn.textContent = '💾 保存到表格';
            }
        }
    }
}

if (saveSummaryBtn) {
    saveSummaryBtn.addEventListener('click', saveSummaryToSheet);
}

// Render project groups into UI (Phase 2)
function renderProjectGroups(projectMap) {
    if (!summaryResult) return;
    summaryResult.innerHTML = '';

    // Helper: Calculate project heat with KOL bonus
    // Formula: Sum(tweet heat) × (1 + (numKOLs - 1) × 0.20)
    function calculateProjectHeat(project) {
        const baseHeat = project.tweets.reduce((sum, t) => sum + t.heatScore, 0);
        const numKOLs = project.tweets.length;
        const multiplier = 1 + (numKOLs - 1) * 0.20;
        return Math.round(baseHeat * multiplier);
    }

    const sortedProjects = Array.from(projectMap.values()).sort((a, b) => {
        // Calculate total heat with KOL bonus for sorting
        const scoreA = calculateProjectHeat(a);
        const scoreB = calculateProjectHeat(b);
        return scoreB - scoreA;
    });

    sortedProjects.forEach((project, projectIndex) => {
        // Project Card
        const card = document.createElement('div');
        card.className = 'project-card';

        // Total Project Heat with KOL bonus
        const totalHeat = calculateProjectHeat(project);

        // Determine if this project should be selected by default (top 10)
        const isTop10 = projectIndex < 10;

        // Header - compact version with checkbox
        const header = document.createElement('div');
        header.className = 'project-header';

        // Project checkbox
        const projectCheckbox = document.createElement('input');
        projectCheckbox.type = 'checkbox';
        projectCheckbox.className = 'project-checkbox';
        projectCheckbox.checked = isTop10;

        header.innerHTML = `
            <div class="project-info">
                <span class="project-handle">${project.officialHandle}</span>
            </div>
            <div class="header-actions">
                <span class="project-heat"><span class="heat-icon">🔥</span><span class="heat-value">${totalHeat.toFixed(0)}</span></span>
                <span class="tweet-count">${project.tweets.length}</span>
                <svg class="toggle-icon" viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/></svg>
            </div>
        `;

        // Insert checkbox at the beginning
        header.insertBefore(projectCheckbox, header.firstChild);

        // Content
        const content = document.createElement('div');
        content.className = 'project-content';

        // Store references to tweet checkboxes for bulk toggle
        const tweetCheckboxes = [];

        project.tweets.forEach(item => {
            const tweetRow = document.createElement('div');
            tweetRow.className = 'summary-tweet-item';

            // Checkbox
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'tweet-checkbox';
            checkbox.checked = isTop10; // Only top 10 projects selected by default

            // Checkbox event (for future selection logic)
            checkbox.addEventListener('change', () => {
                item.selected = checkbox.checked;
                // Update project checkbox state
                updateProjectCheckboxState();
            });
            // Init selected state
            item.selected = isTop10;

            tweetCheckboxes.push({ checkbox, item });

            const detail = document.createElement('div');
            detail.className = 'tweet-detail';

            // Compact inline format with truncated summary
            const shortSummary = item.summary.length > 13 ? item.summary.substring(0, 13) + '...' : item.summary;
            const needsMore = item.summary.length > 13;
            const fullSummary = item.summary;

            // Build HTML - summary text will be updated in place
            detail.innerHTML = `<span class="tweet-kol">${item.kolName}</span><span class="tweet-handle">${item.kolHandle}</span><span class="tweet-summary-text" data-full-summary="${fullSummary.replace(/"/g, '&quot;')}">${shortSummary}</span>${needsMore ? '<span class="summary-more">更多</span>' : ''}<span class="tweet-meta-row"><a href="${item.tweet.url}" target="_blank" class="tweet-link-ref">链接</a><span class="item-heat">🔥${item.heatScore.toFixed(0)}</span></span>`;

            // Add click handler for "more" button - toggle text content in place
            if (needsMore) {
                const moreBtn = detail.querySelector('.summary-more');
                const summarySpan = detail.querySelector('.tweet-summary-text');
                let isExpanded = false;
                if (moreBtn && summarySpan) {
                    moreBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        isExpanded = !isExpanded;
                        summarySpan.textContent = isExpanded ? fullSummary : shortSummary;
                        moreBtn.textContent = isExpanded ? '收起' : '更多';
                    });
                }
            }

            tweetRow.appendChild(checkbox);
            tweetRow.appendChild(detail);
            content.appendChild(tweetRow);
        });

        // Function to update project checkbox based on tweet checkboxes
        function updateProjectCheckboxState() {
            const allChecked = tweetCheckboxes.every(tc => tc.checkbox.checked);
            const someChecked = tweetCheckboxes.some(tc => tc.checkbox.checked);
            projectCheckbox.checked = allChecked;
            projectCheckbox.indeterminate = someChecked && !allChecked;
        }

        // Project checkbox click handler - toggle all tweets
        projectCheckbox.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent header collapse
        });
        projectCheckbox.addEventListener('change', () => {
            const newState = projectCheckbox.checked;
            tweetCheckboxes.forEach(tc => {
                tc.checkbox.checked = newState;
                tc.item.selected = newState;
            });
        });

        // Toggle collapse on header click (but not checkbox)
        header.addEventListener('click', (e) => {
            if (e.target !== projectCheckbox) {
                card.classList.toggle('collapsed');
            }
        });

        card.appendChild(header);
        card.appendChild(content);
        summaryResult.appendChild(card);
    });
}

// === Start App Initialization ===
// Must be at the end of the file after all functions are defined

// Initialize Comment Reply Config (before initializeApp to ensure config is loaded)
if (typeof initCommentReplyConfig === 'function') {
    initCommentReplyConfig();
}

initializeApp();
