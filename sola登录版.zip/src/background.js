// Allows users to open the side panel by clicking on the action toolbar icon
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

// === Authorization Check on Startup ===
// Note: Authorization check will be performed in sidepanel.js when the panel opens
// This is because we need access to the current tab to get the user's username
// The sidepanel.js will handle the authorization check automatically

// Listen for extension installation/update
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        console.log('Extension installed - authorization check will run when sidepanel opens');
    } else if (details.reason === 'update') {
        console.log('Extension updated - authorization check will run when sidepanel opens');
    }
});
