let observer = null;
let isListening = false;

// Snowflake ID to Date conversion
function getTweetTimestamp(tweetId) {
    // Twitter Snowflake ID format:
    // (timestamp - 1288834974657) << 22 | (datacenterId) << 17 | (workerId) << 12 | (sequence)
    // We need to parse the BigInt and shift right by 22 bits, then add the Twitter epoch.
    try {
        const id = BigInt(tweetId);
        const timestamp = (id >> 22n) + 1288834974657n;
        return Number(timestamp);
    } catch (e) {
        console.error("Error parsing tweet ID:", tweetId, e);
        return Date.now(); // Fallback
    }
}

// Helper to parse engagement numbers (e.g., "1.2K" -> 1200)
function parseEngagementNumber(text) {
    if (!text || text.trim() === '') return 0;
    text = text.trim().toLowerCase();

    // Handle K (thousands) and M (millions)
    if (text.endsWith('k')) {
        return Math.round(parseFloat(text.slice(0, -1)) * 1000);
    } else if (text.endsWith('m')) {
        return Math.round(parseFloat(text.slice(0, -1)) * 1000000);
    }

    // Regular number
    const num = parseInt(text.replace(/,/g, ''), 10);
    return isNaN(num) ? 0 : num;
}

// Extract engagement metrics from a tweet article element
function extractEngagementFromArticle(article) {
    const metrics = {
        content: '',
        likes: 0,
        replies: 0,
        retweets: 0,
        views: 0
    };

    if (!article) return metrics;

    // Tweet content
    const tweetTextEl = article.querySelector('[data-testid="tweetText"]');
    if (tweetTextEl) {
        metrics.content = tweetTextEl.innerText || '';
    }

    // Replies (comment button)
    const replyBtn = article.querySelector('[data-testid="reply"]');
    if (replyBtn) {
        const replySpan = replyBtn.querySelector('span[data-testid="app-text-transition-container"]');
        if (replySpan) {
            metrics.replies = parseEngagementNumber(replySpan.textContent);
        }
    }

    // Retweets
    const retweetBtn = article.querySelector('[data-testid="retweet"]');
    if (retweetBtn) {
        const retweetSpan = retweetBtn.querySelector('span[data-testid="app-text-transition-container"]');
        if (retweetSpan) {
            metrics.retweets = parseEngagementNumber(retweetSpan.textContent);
        }
    }

    // Likes
    const likeBtn = article.querySelector('[data-testid="like"]');
    if (likeBtn) {
        const likeSpan = likeBtn.querySelector('span[data-testid="app-text-transition-container"]');
        if (likeSpan) {
            metrics.likes = parseEngagementNumber(likeSpan.textContent);
        }
    }

    // Views (analytics link or view count display)
    const analyticsLink = article.querySelector('a[href*="/analytics"]');
    if (analyticsLink) {
        const viewSpan = analyticsLink.querySelector('span[data-testid="app-text-transition-container"]');
        if (viewSpan) {
            metrics.views = parseEngagementNumber(viewSpan.textContent);
        }
    }

    // Alternative: Views displayed inline (newer X UI)
    if (metrics.views === 0) {
        const viewsContainer = article.querySelector('[aria-label*="views"], [aria-label*="View"]');
        if (viewsContainer) {
            const text = viewsContainer.getAttribute('aria-label') || '';
            const viewMatch = text.match(/([\d,.]+[KMkm]?)\s*[Vv]iew/);
            if (viewMatch) {
                metrics.views = parseEngagementNumber(viewMatch[1]);
            }
        }
    }

    return metrics;
}

// 判断单条 article 是否为置顶帖（用于回复评论者首条推文跳过置顶、滚动停止判断等）
// X 不同版本/语言置顶标签位置不一，多途径检测
function isArticlePinned(article) {
    if (!article) return false;
    const text = (s) => (s || '').trim();
    // 1. socialContext 区域（常见位置）
    const ctx = article.querySelector('[data-testid="socialContext"]');
    if (ctx && /\b(Pinned|置顶|Pin|固定)\b/i.test(text(ctx.innerText))) return true;
    // 2. 任意子元素的 aria-label
    const byAria = article.querySelector('[aria-label*="Pinned"], [aria-label*="置顶"], [aria-label*="Pin"], [aria-label*="固定"]');
    if (byAria) return true;
    // 3. 推文头部文案（前 1200 字，覆盖用户名行+标签）
    const headerText = (article.innerText || '').slice(0, 1200);
    if (/\b(Pinned|置顶|Pin|固定|Pinned\s*Tweet)\b/i.test(headerText)) return true;
    // 4. 存在「仅含置顶文案」的小块（标签多为独立 span/div，文案很短）
    const all = article.querySelectorAll('span, div');
    for (const el of all) {
        const t = text(el.textContent);
        if (t.length > 0 && t.length <= 25 && /^(Pinned|置顶|Pin|固定|Pinned\s*Tweet)$/i.test(t)) return true;
    }
    return false;
}

// 从单条 article 获取 tweetId、timestamp、isPinned（用于滚动停止判断：出现非置顶且超过 hoursLimit 的推文即停）
function getArticleTweetInfo(article) {
    const timeLink = article.querySelector('a[href*="/status/"] time');
    if (!timeLink) return null;
    const anchor = timeLink.closest('a');
    if (!anchor) return null;
    const href = anchor.href;
    const match = href.match(/(?:twitter\.com|x\.com)\/([^\/]+)\/status\/(\d+)/);
    if (!match) return null;
    const tweetId = match[2];
    let timestamp = getTweetTimestamp(tweetId);
    const datetime = timeLink.getAttribute('datetime');
    if (datetime) {
        const parsed = new Date(datetime).getTime();
        if (!isNaN(parsed)) timestamp = parsed;
    }
    const isPinned = isArticlePinned(article);
    return { tweetId, timestamp, isPinned };
}

function extractTweetLinks() {
    const links = [];
    const processedIds = new Set();

    // Find all tweet articles
    const articles = document.querySelectorAll('article[data-testid="tweet"]');

    articles.forEach(article => {
        // Find the tweet link within this article
        const timeLink = article.querySelector('a[href*="/status/"] time');
        if (!timeLink) return;

        const anchor = timeLink.closest('a');
        if (!anchor) return;

        const href = anchor.href;
        const match = href.match(/(?:twitter\.com|x\.com)\/([^\/]+)\/status\/(\d+)/);

        if (match) {
            const username = match[1];
            const tweetId = match[2];

            // Skip if already processed (avoid duplicates)
            if (processedIds.has(tweetId)) return;
            processedIds.add(tweetId);

            // Detect if this is a reply
            // Check for "Replying to" text or reply indicator
            let isReply = false;
            const replyIndicator = article.querySelector('[data-testid="reply"]');
            const socialContext = article.querySelector('[data-testid="socialContext"]');

            // Check for "Replying to @username" text
            const replyingToText = article.innerText.includes('Replying to') ||
                article.innerText.includes('回复');

            // Check if tweet URL contains /status/ but appears in a reply context
            // Replies typically show "Replying to @user" above the content
            if (replyingToText) {
                isReply = true;
            }

            // Detect retweet/repost（回复评论者首条推文需跳过转发的推文，只回复本人发布的）
            const isRetweet = (() => {
                const ctx = article.querySelector('[data-testid="socialContext"]');
                const ctxText = (ctx && ctx.innerText) ? ctx.innerText.trim() : '';
                const headText = (article.innerText || '').slice(0, 500);
                return /\b(Reposted|转发了|reposted)\b/i.test(ctxText) || /\b(Reposted|转发了|reposted)\b/i.test(headText);
            })();

            // Basic validation
            if (username && tweetId) {
                // Extract engagement metrics from this article
                const engagement = extractEngagementFromArticle(article);
                // Detect pinned tweet（回复评论者首条推文需跳过置顶；socialContext + 顶部文案双重判断）
                const isPinned = isArticlePinned(article);

                links.push({
                    id: tweetId,
                    username: username,
                    url: href,
                    timestamp: getTweetTimestamp(tweetId),
                    content: engagement.content,
                    likes: engagement.likes,
                    replies: engagement.replies,
                    retweets: engagement.retweets,
                    views: engagement.views,
                    isReply: isReply,
                    isPinned: isPinned,
                    isRetweet: isRetweet
                });
            }
        }
    });

    return links;
}

function startListening() {
    if (isListening) return;
    isListening = true;
    console.log("X Link Collector: Started listening");

    // Initial scan
    const initialLinks = extractTweetLinks();
    if (initialLinks.length > 0) {
        chrome.runtime.sendMessage({ type: 'NEW_TWEETS', payload: initialLinks });
    }

    // Set up MutationObserver
    observer = new MutationObserver((mutations) => {
        // We could optimize by checking mutations, but for now, re-scanning is safer 
        // to catch all dynamically loaded content. 
        // To avoid performance issues, we can debounce or just scan. 
        // Given the requirement is "real-time", we'll scan.
        // Optimization: Check if addedNodes contain relevant elements? 
        // For simplicity and robustness in a chat scroll scenario, scanning the whole DOM 
        // or a specific container is usually fine unless the DOM is massive.
        // Let's try to be slightly smarter: only scan if nodes were added.
        let nodesAdded = false;
        for (const mutation of mutations) {
            if (mutation.addedNodes.length > 0) {
                nodesAdded = true;
                break;
            }
        }

        if (nodesAdded) {
            const links = extractTweetLinks();
            if (links.length > 0) {
                chrome.runtime.sendMessage({ type: 'NEW_TWEETS', payload: links });
            }
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

function stopListening() {
    if (!isListening) return;
    isListening = false;
    console.log("X Link Collector: Stopped listening");

    if (observer) {
        observer.disconnect();
        observer = null;
    }
}

// === Unified Message Handler ===
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Scanner actions
    if (message.action === 'START_LISTENING') {
        startListening();
        sendResponse({ success: true });
        return false;
    }

    if (message.action === 'STOP_LISTENING') {
        stopListening();
        sendResponse({ success: true });
        return false;
    }

    if (message.action === 'SIMULATE_SCROLL') {
        simulateBrowsingScroll().then(() => {
            sendResponse({ success: true });
        });
        return true; // Keep channel open for async
    }

    if (message.action === 'START_SCANNER_SCROLL') {
        startScannerAutoScroll();
        sendResponse({ success: true });
        return false;
    }

    if (message.action === 'STOP_SCANNER_SCROLL') {
        stopScannerAutoScroll();
        sendResponse({ success: true });
        return false;
    }

    // Profile scraper
    if (message.action === 'GET_PROFILE_INFO') {
        const profileInfo = scrapeProfileInfo();
        sendResponse(profileInfo);
        return false;
    }

    // Get current username
    if (message.action === 'GET_CURRENT_USERNAME') {
        const username = getCurrentUserUsername();
        sendResponse({ username: username });
        return false;
    }

    // AI Automation
    if (message.action === 'SCRAPE_TWEET_CONTENT') {
        const content = scrapeTweetContent();
        const tweetAuthor = getTweetAuthorUsername();
        const currentUser = getCurrentUserUsername();
        const isLiked = checkIfTweetLiked(); // Check if tweet is already liked
        const isReplied = checkIfTweetReplied(); // Check if tweet is already replied to
        sendResponse({ 
            content: content,
            tweetAuthor: tweetAuthor,
            currentUser: currentUser,
            isOwnTweet: tweetAuthor && currentUser && tweetAuthor === currentUser,
            isLiked: isLiked, // Include liked status
            isReplied: isReplied // Include replied status
        });
        return false;
    }

    // Comment Reply - Get own tweets
    if (message.action === 'SCRAPE_OWN_TWEETS') {
        scrapeOwnTweets(message.payload).then((tweets) => {
            sendResponse({ tweets: tweets });
        }).catch((error) => {
            sendResponse({ tweets: [], error: error.message });
        });
        return true; // Keep channel open for async
    }

    // Comment Reply - Get tweet comments
    if (message.action === 'SCRAPE_TWEET_COMMENTS') {
        scrapeTweetComments(message.payload).then((comments) => {
            sendResponse({ comments: comments });
        }).catch((error) => {
            sendResponse({ comments: [], error: error.message });
        });
        return true; // Keep channel open for async
    }

    // Scan replies to check if current user has already replied
    if (message.action === 'SCAN_REPLIES') {
        scanRepliesForCurrentUser().then((hasReplied) => {
            sendResponse({ hasReplied: hasReplied });
        }).catch((error) => {
            console.error('[SCAN_REPLIES] Error:', error);
            sendResponse({ hasReplied: false, error: error.message });
        });
        return true; // Keep channel open for async
    }

    if (message.action === 'PERFORM_ACTIONS') {
        performActions(message.payload).then((result) => {
            sendResponse(result || { success: true });
        }).catch((error) => {
            sendResponse({ success: false, error: error.message });
        });
        return true; // Keep channel open for async
    }

    if (message.action === 'PASTE_AND_REPLY') {
        performActions({
            replyText: message.text,
            doLike: message.doLike,
            doRepost: message.doRepost,
            replyDelay: { min: 1, max: 3 },
            likeDelay: { min: 1, max: 2 }
        }).then(() => {
            sendResponse({ success: true });
        });
        return true; // Keep channel open for async
    }



    // Extract tweets for scan and reply
    if (message.action === 'EXTRACT_TWEETS_FOR_REPLY') {
        const tweets = extractTweetLinks();
        sendResponse({ tweets: tweets });
        return false;
    }

    // 获取推文的评论者列表（去重）
    if (message.action === 'GET_TWEET_COMMENTERS') {
        scrapeTweetComments({ maxComments: 100, hoursLimit: 168 }).then((comments) => {
            // 提取唯一的评论者用户名
            const commenters = [...new Set(comments.map(c => c.username).filter(Boolean))];
            sendResponse({ commenters: commenters });
        }).catch((error) => {
            console.error('[GET_TWEET_COMMENTERS] Error:', error);
            sendResponse({ commenters: [], error: error.message });
        });
        return true;
    }

    // 获取用户主页第一条非置顶推文
    if (message.action === 'GET_FIRST_NON_PINNED_TWEET') {
        getFirstNonPinnedTweet().then((tweet) => {
            sendResponse({ tweet: tweet });
        }).catch((error) => {
            console.error('[GET_FIRST_NON_PINNED_TWEET] Error:', error);
            sendResponse({ tweet: null, error: error.message });
        });
        return true;
    }

    // KOL 24h: 在当前个人主页滚动加载推文，提取 24h 内且排除置顶，返回列表
    if (message.action === 'SCROLL_AND_EXTRACT_PROFILE_TWEETS') {
        scrollAndExtractProfileTweets(message.payload || {}).then((result) => {
            sendResponse(result);
        }).catch((err) => {
            console.error('[SCROLL_AND_EXTRACT_PROFILE_TWEETS]', err);
            sendResponse({ tweets: [], error: err.message });
        });
        return true;
    }

    // Unknown message - don't keep channel open
    return false;
});



// --- Profile Scraper ---
function scrapeProfileInfo() {
    const url = window.location.href;
    const match = url.match(/(?:twitter\.com|x\.com)\/([^\/]+)(?:\/.*)?$/);

    if (!match) return null;

    const username = match[1];
    const reserved = ['home', 'explore', 'notifications', 'messages', 'search', 'settings', 'i', 'compose'];
    if (reserved.includes(username)) return null;

    const profileLink = `https://x.com/${username}`;
    let name = '';
    let avatar = '';

    // Strategy 1: Profile Page Header
    const profileNameEl = document.querySelector('[data-testid="UserName"] span span');
    if (profileNameEl) {
        name = profileNameEl.textContent;
        const avatarLink = document.querySelector(`a[href="/${username}/photo"]`);
        if (avatarLink) {
            const img = avatarLink.querySelector('img');
            if (img) avatar = img.src;
        }
        if (!avatar) {
            const avatarImg = document.querySelector('a[href*="/photo"] img[src*="profile_images"]');
            if (avatarImg) avatar = avatarImg.src;
        }
    }
    // Strategy 2: Tweet Page Author
    else {
        const tweetArticle = document.querySelector('article[data-testid="tweet"]');
        if (tweetArticle) {
            const tweetNameEl = tweetArticle.querySelector('[data-testid="User-Name"] span span');
            if (tweetNameEl) name = tweetNameEl.textContent;
            const tweetAvatarImg = tweetArticle.querySelector('[data-testid="Tweet-User-Avatar"] img');
            if (tweetAvatarImg) avatar = tweetAvatarImg.src;
        }
        // Strategy 3: Document Title Fallback
        if (!name) {
            const title = document.title;
            const profileMatch = title.match(/^(.+) \(@/);
            const tweetMatch = title.match(/^(.+) on X:/);
            if (profileMatch) name = profileMatch[1];
            else if (tweetMatch) name = tweetMatch[1];
        }
    }

    return {
        name: name || username,
        link: profileLink,
        avatar: avatar
    };
}

// Get current logged-in user's username
function getCurrentUserUsername() {
    // Try multiple methods to get current user's username
    
    // Method 1: From navigation bar profile link
    const navProfileLink = document.querySelector('nav a[href*="/"][data-testid="AppTabBar_Profile_Link"]');
    if (navProfileLink) {
        const href = navProfileLink.getAttribute('href');
        const match = href.match(/\/([^\/]+)$/);
        if (match && match[1] && match[1] !== 'home' && match[1] !== 'explore') {
            return match[1].toLowerCase();
        }
    }
    
    // Method 2: From sidebar profile link
    const sidebarProfileLink = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]');
    if (sidebarProfileLink) {
        const profileLink = sidebarProfileLink.querySelector('a[href*="/"]');
        if (profileLink) {
            const href = profileLink.getAttribute('href');
            const match = href.match(/\/([^\/]+)$/);
            if (match && match[1]) {
                return match[1].toLowerCase();
            }
        }
    }
    
    // Method 3: From tweet author link on current page (if we're viewing a tweet)
    const tweetAuthorLink = document.querySelector('article[data-testid="tweet"] a[href*="/"][role="link"]');
    if (tweetAuthorLink) {
        const href = tweetAuthorLink.getAttribute('href');
        const match = href.match(/\/([^\/]+)$/);
        if (match && match[1]) {
            // Check if this link is in the navigation area (current user)
            const isNavLink = tweetAuthorLink.closest('nav') || tweetAuthorLink.closest('[data-testid="SideNav"]');
            if (isNavLink) {
                return match[1].toLowerCase();
            }
        }
    }
    
    // Method 4: From document title (fallback)
    const title = document.title;
    const titleMatch = title.match(/\(@(\w+)\)/);
    if (titleMatch) {
        return titleMatch[1].toLowerCase();
    }
    
    return null;
}

// Get tweet author username from the current page
function getTweetAuthorUsername() {
    // Find the main tweet article
    const mainArticle = document.querySelector('article[tabindex="-1"]') || document.querySelector('article[data-testid="tweet"]');
    if (!mainArticle) return null;
    
    // Find the author link in the tweet
    const authorLink = mainArticle.querySelector('a[href*="/"][role="link"]');
    if (authorLink) {
        const href = authorLink.getAttribute('href');
        const match = href.match(/\/([^\/]+)$/);
        if (match && match[1]) {
            return match[1].toLowerCase();
        }
    }
    
    // Fallback: Extract from URL if we're on a status page
    const urlMatch = window.location.href.match(/(?:twitter\.com|x\.com)\/([^\/]+)\/status/);
    if (urlMatch) {
        return urlMatch[1].toLowerCase();
    }
    
    return null;
}

// --- AI Automation Functions ---
function scrapeTweetContent() {
    // We assume we are on the tweet detail page
    // The main tweet is usually the first article, or the one with specific props
    // On detail page, the main tweet is usually distinguishable.
    // Let's look for the tweet that is NOT a reply to the main tweet (if any)
    // Actually, on a permalink page, the main tweet is the one that the URL points to.
    // It usually has a larger font or is the "focal" tweet.

    // Simple heuristic: The first tweet article on the page that is not a "parent" tweet (if we are viewing a thread)
    // But often the parent is shown first.
    // Let's try to find the tweet text of the tweet that matches the URL ID?
    // Or just grab the text of the main focused tweet.
    // Twitter uses `aria-labelledby` or similar, but it's complex.

    // Selector for the main tweet text on a status page
    const tweetTextEl = document.querySelector('article[tabindex="-1"] [data-testid="tweetText"]');
    if (tweetTextEl) {
        return tweetTextEl.innerText;
    }

    // Fallback: First tweet text
    const firstTweetText = document.querySelector('[data-testid="tweetText"]');
    return firstTweetText ? firstTweetText.innerText : '';
}

// Get status ID from an article (must use timestamp link = this tweet's permalink, not quoted tweet link)
function getArticleStatusId(article) {
    const timeLink = article.querySelector('a[href*="/status/"] time');
    if (timeLink) {
        const anchor = timeLink.closest('a');
        if (anchor) {
            const href = anchor.getAttribute('href') || '';
            const match = href.match(/\/status\/(\d+)/);
            if (match) return match[1];
        }
    }
    const links = article.querySelectorAll('a[href*="/status/"]');
    for (const link of links) {
        const href = link.getAttribute('href') || '';
        const match = href.match(/\/status\/(\d+)/);
        if (match) return match[1];
    }
    return null;
}

// Check if an article is a reply (to another tweet). Align with sola stable: reply = "Replying to" or "回复" in article.
function isArticleReply(article) {
    // 用 textContent 确保拿到所有子节点文字（含链接内的 @用户名），避免「回复」和「@」分在不同节点时漏判
    const articleText = (article.textContent || article.innerText || '').trim();
    const headerPart = articleText.slice(0, 350);

    // 英文界面常见 "Replying to @user" / "Reply to @user"
    if (/Replying to|Reply to\s*@/i.test(articleText)) {
        console.log('[isMainTweet] Article contains Replying to/Reply to @ - reply tweet');
        return true;
    }
    if (articleText.includes('回复给')) {
        console.log('[isMainTweet] Article text contains 回复给 - reply tweet');
        return true;
    }
    // 回复推文头部常见 "回复 @用户" 或 "回复 @A 和 @B"
    if (/回复\s*@|回复@/.test(articleText)) {
        console.log('[isMainTweet] Article text contains 回复 @ - reply tweet');
        return true;
    }
    // sola：头部 300 字内同时出现「回复」和 @ 即视为评论/回复推文
    if (headerPart.includes('回复') && /@\w+/.test(headerPart)) {
        console.log('[isMainTweet] Article header contains 回复 and @ - reply tweet (sola logic)');
        return true;
    }

    const socialContext = article.querySelector('[data-testid="socialContext"]');
    if (socialContext) {
        const ctxText = (socialContext.textContent || socialContext.innerText || '').trim();
        if (/Replying to|Reply to|回复给|回复\s*@/i.test(ctxText)) {
            console.log('[isMainTweet] socialContext indicates reply:', ctxText.slice(0, 50));
            return true;
        }
    }
    const tweetTextEl = article.querySelector('[data-testid="tweetText"]');
    const text = tweetTextEl ? (tweetTextEl.textContent || '').trim() : '';
    const replyingToIndicator = article.querySelector('span[dir="ltr"]');
    if (replyingToIndicator) {
        const indicatorText = replyingToIndicator.textContent || '';
        if ((/Replying to|Reply to|回复给|回复\s*@|回复@/.test(indicatorText)) && text.match(/^@\w+\s/)) {
            return true;
        }
    }
    return false;
}

// 若可以上滚且上方还有推文，则视为评论页（当前是评论/回复推文）。返回 Promise<boolean>。
function hasTweetAboveCurrent(urlStatusId) {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    if (scrollTop <= 0) return Promise.resolve(false);
    const beforeScroll = scrollTop;
    window.scrollBy(0, -Math.min(400, scrollTop));
    return new Promise(function (resolve) {
        setTimeout(function () {
            const articles = document.querySelectorAll('article[data-testid="tweet"]');
            const firstId = articles.length > 0 ? getArticleStatusId(articles[0]) : null;
            const hasAbove = firstId != null && firstId !== urlStatusId;
            if (hasAbove) console.log('[isMainTweet] Can scroll up and tweet above (first ID !== URL) - treat as comment');
            window.scrollTo(0, beforeScroll);
            setTimeout(function () { resolve(hasAbove); }, 200);
        }, 450);
    });
}

// Check if current page is showing the main tweet (not a reply or thread continuation)
// 与 sola 一致：评论/串楼页时第一个 article 是主推文，当前 URL 是评论 ID → 第一个 article ID !== URL → 直接跳过
// 补充：若可以上滚且上方还有推文，也识别为评论
async function isMainTweet() {
    const url = window.location.href;
    console.log('[isMainTweet] Checking URL:', url);
    
    const urlMatch = url.match(/\/status\/(\d+)/);
    if (!urlMatch) {
        console.log('[isMainTweet] No status ID in URL');
        return false;
    }
    const urlStatusId = urlMatch[1];
    console.log('[isMainTweet] URL status ID:', urlStatusId);
    
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    if (articles.length === 0) {
        console.log('[isMainTweet] No articles found');
        return false;
    }
    console.log('[isMainTweet] Found', articles.length, 'articles');
    
    const firstArticle = articles[0];
    const firstArticleStatusId = getArticleStatusId(firstArticle);
    
    // sola 逻辑：URL 的 status ID 必须等于「第一个 article」的 status ID；否则视为评论页或串楼
    if (firstArticleStatusId && firstArticleStatusId !== urlStatusId) {
        console.log('[isMainTweet] URL does not match first article (sola logic: comment or thread) - skipping');
        return false;
    }
    
    // 启发式：可以上滚且上滚后第一个 article 不是当前 URL → 上面还有推文 → 视为评论
    try {
        const hasAbove = await hasTweetAboveCurrent(urlStatusId);
        if (hasAbove) return false;
    } catch (e) {
        console.warn('[isMainTweet] hasTweetAboveCurrent check failed:', e);
    }
    
    // 第一个 article 匹配 URL 或仅有一个 article 且无法取到 ID 时，用该 article 做「是否回复推文」判断
    const targetArticle = (firstArticleStatusId === urlStatusId) ? firstArticle
        : (articles.length === 1 && firstArticleStatusId == null) ? firstArticle
        : null;
    
    if (!targetArticle) {
        console.log('[isMainTweet] No article matches URL - skipping');
        return false;
    }
    
    if (isArticleReply(targetArticle)) {
        console.log('[isMainTweet] Target article is a reply - skipping');
        return false;
    }
    
    console.log('[isMainTweet] First article matches URL and is not a reply - main tweet');
    return true;
}

// Check if the tweet is already liked
function checkIfTweetLiked() {
    // Try multiple methods to detect if tweet is liked
    // Method 1: Check aria-label of like button (most reliable)
    let likeBtn = document.querySelector('article[tabindex="-1"] [data-testid="like"]');
    if (!likeBtn) {
        // Fallback: try first article
        likeBtn = document.querySelector('article[data-testid="tweet"] [data-testid="like"]');
    }
    
    if (likeBtn) {
        // Get the button element (likeBtn might be the div inside)
        const buttonEl = likeBtn.closest('button') || likeBtn.parentElement?.closest('button') || likeBtn;
        
        // Method 1: Check aria-label for "Unlike" or similar indicators
        const ariaLabel = (buttonEl.getAttribute('aria-label') || likeBtn.getAttribute('aria-label') || '').toLowerCase();
        if (ariaLabel.includes('unlike') || 
            ariaLabel.includes('取消') || 
            ariaLabel.includes('liked') ||
            ariaLabel.includes('已赞') ||
            ariaLabel.includes('已喜欢')) {
            console.log('[checkIfTweetLiked] Tweet is already liked (detected via aria-label):', ariaLabel);
            return true;
        }
        
        // Method 2: Check computed color of the button/text
        // Liked buttons have a pink/red color (#f91880 = rgb(249, 24, 128))
        const computedStyle = window.getComputedStyle(buttonEl);
        const color = computedStyle.color;
        if (color) {
            // Check for Twitter's like color (pink/red)
            if (color.includes('249, 24, 128') || 
                color.includes('245, 24, 128') || 
                color.includes('f91880') ||
                color.includes('rgb(249') ||
                color.includes('rgb(245')) {
                // Additional verification: check if it's not the default text color
                // Default unliked color is usually rgb(113, 118, 123) or similar gray
                if (!color.includes('113, 118, 123') && !color.includes('rgb(113')) {
                    console.log('[checkIfTweetLiked] Tweet is already liked (detected via color):', color);
                    return true;
                }
            }
        }
        
        // Method 3: Check SVG fill color inside the button
        const svg = buttonEl.querySelector('svg');
        if (svg) {
            const path = svg.querySelector('path');
            if (path) {
                const fill = path.getAttribute('fill');
                const computedFill = window.getComputedStyle(path).fill;
                const fillColor = fill || computedFill;
                
                // Liked tweets have pink/red fill
                if (fillColor && 
                    fillColor !== 'none' && 
                    fillColor !== 'transparent' &&
                    fillColor !== 'currentColor' &&
                    (fillColor.includes('f91880') || 
                     fillColor.includes('249, 24, 128') ||
                     fillColor.includes('245, 24, 128') ||
                     fillColor.includes('rgb(249') ||
                     fillColor.includes('rgb(245'))) {
                    console.log('[checkIfTweetLiked] Tweet is already liked (detected via SVG fill):', fillColor);
                    return true;
                }
            }
        }
        
        // Method 4: Check for r-* classes that indicate active state (Twitter uses r-* classes)
        // Liked buttons may have specific classes or data attributes
        if (buttonEl.classList.toString().includes('r-') || 
            buttonEl.getAttribute('data-testid') === 'like' && 
            (buttonEl.classList.toString().includes('active') || 
             computedStyle.backgroundColor.includes('249') ||
             computedStyle.backgroundColor.includes('245'))) {
            // Additional verification with color check
            const bgColor = computedStyle.backgroundColor;
            if (bgColor.includes('249, 24, 128') || bgColor.includes('245, 24, 128')) {
                console.log('[checkIfTweetLiked] Tweet is already liked (detected via background):', bgColor);
                return true;
            }
        }
    }
    
    console.log('[checkIfTweetLiked] Tweet is not liked');
    return false;
}

// Check if the tweet has already been replied to
function checkIfTweetReplied() {
    // Method 1: Check if reply textarea/dialog is already filled or active
    // If user has already replied, the reply dialog might be open or have text
    const replyTextarea = document.querySelector('[data-testid="tweetTextarea_0"]');
    if (replyTextarea) {
        const textValue = replyTextarea.value || replyTextarea.textContent || '';
        // If textarea has content, it might be a draft, but could also indicate a previous reply
        // We'll check if it's a substantial reply (more than just whitespace)
        if (textValue.trim().length > 10) {
            console.log('[checkIfTweetReplied] Reply textarea has content, might be already replied');
            // This is not definitive, so we'll continue checking
        }
    }

    // Method 2: Check for reply button aria-label or state
    // If already replied, the reply button might show different text or be disabled
    let replyBtn = document.querySelector('article[tabindex="-1"] [data-testid="reply"]');
    if (!replyBtn) {
        replyBtn = document.querySelector('article[data-testid="tweet"] [data-testid="reply"]');
    }
    
    if (replyBtn) {
        const buttonEl = replyBtn.closest('button') || replyBtn.parentElement?.closest('button') || replyBtn;
        const ariaLabel = (buttonEl.getAttribute('aria-label') || replyBtn.getAttribute('aria-label') || '').toLowerCase();
        
        // Check if button indicates already replied
        if (ariaLabel.includes('replied') || 
            ariaLabel.includes('已回复') ||
            ariaLabel.includes('already replied')) {
            console.log('[checkIfTweetReplied] Tweet is already replied (detected via aria-label):', ariaLabel);
            return true;
        }
        
        // Check if button is disabled (might indicate already replied in some cases)
        if (buttonEl && buttonEl.hasAttribute('disabled') && !buttonEl.disabled === false) {
            // Disabled state might indicate already interacted
            console.log('[checkIfTweetReplied] Reply button is disabled, might be already replied');
        }
    }

    // Method 3: Look for reply indicators in the tweet thread
    // Check if there are reply counts or visual indicators showing this tweet was replied to by current user
    // This is harder to detect reliably, so we'll rely more on URL-based tracking

    return false; // Default: not detected as replied
}

// 回复框当前文案（用于稳定检测与发送成功检测）
function getReplyBoxText() {
    const input = document.querySelector('[data-testid="tweetTextarea_0"]');
    if (!input) return '';
    return (input.innerText || input.textContent || '').trim();
}

// 发送前清空回复框，避免把新内容追加到上次残留（导致出现「正常句+不 稳 1 这」等乱序）
function clearReplyBox() {
    const replyInput = document.querySelector('[data-testid="tweetTextarea_0"]');
    if (!replyInput) return;
    replyInput.focus();
    const had = (replyInput.innerText || replyInput.textContent || '').trim();
    if (!had) return;
    try {
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, '');
    } catch (e) {
        try {
            replyInput.innerText = '';
            replyInput.textContent = '';
        } catch (e2) {}
    }
    console.log('[Reply] Cleared reply box (was ' + had.length + ' chars)');
}

// 打字结束后必须等「对话框没有新增字符」再点回复，避免写到一半就发送导致重复/半截回复
async function waitForReplyBoxContentStable(expectedText, maxWaitMs, stableDurationMs) {
    maxWaitMs = maxWaitMs || 15000;
    stableDurationMs = stableDurationMs || 2000;
    const pollIntervalMs = 300;
    const start = Date.now();
    let lastContent = '';
    let lastChangeTime = Date.now();
    while (Date.now() - start < maxWaitMs) {
        await wait(pollIntervalMs);
        const content = getReplyBoxText();
        if (content !== lastContent) {
            lastContent = content;
            lastChangeTime = Date.now();
        }
        const len = (expectedText || '').length;
        const contentLen = (content || '').length;
        const isFull = len === 0 || contentLen >= len;
        const stable = (Date.now() - lastChangeTime) >= stableDurationMs;
        if (isFull && stable) {
            console.log('[Reply] Reply box content full and stable for ' + stableDurationMs + 'ms, safe to send');
            return true;
        }
    }
    console.warn('[Reply] Reply box content did not stabilize within ' + maxWaitMs + 'ms (current length: ' + (lastContent || '').length + ', expected: ' + (expectedText || '').length + ')');
    return false;
}

// X 页面在重复发送时会显示「哇哦！你已经发过了。」，检测到则视为已发送成功
function hasXAlreadyPostedMessage() {
    const bodyText = document.body?.innerText || document.body?.textContent || '';
    return /你已经发过了|already posted/i.test(bodyText);
}

async function waitForReplySuccess(maxWaitMs, pollIntervalMs) {
    maxWaitMs = maxWaitMs || 20000;
    pollIntervalMs = pollIntervalMs || 600;
    const start = Date.now();
    while (Date.now() - start < maxWaitMs) {
        await wait(pollIntervalMs);
        const text = getReplyBoxText();
        if (text === '') {
            console.log('[Reply] Reply box cleared, reply sent successfully');
            return true;
        }
        if (hasXAlreadyPostedMessage()) {
            console.log('[Reply] X showed "already posted" - treating as sent, moving on');
            return true;
        }
    }
    console.warn('[Reply] Reply success detection timed out after ' + maxWaitMs + 'ms');
    return false;
}

// 检测页面上是否出现 X 的「账号可能不允许执行这项操作」限制横幅
function hasAccountRestrictionBanner() {
    const bodyText = (document.body && document.body.innerText) ? document.body.innerText : '';
    if (/你的账号可能不允许执行这项操作|请刷新页面并重试|不允许执行这项操作/i.test(bodyText)) {
        return true;
    }
    const banner = document.querySelector('[role="alert"]');
    if (banner && /不允许执行|刷新页面并重试/i.test(banner.textContent || '')) return true;
    return false;
}

async function performActions({ replyText, doLike, doRepost, replyDelay, likeDelay, postReplyWaitMin, postReplyWaitMax, skipMainTweetCheck = false }) {
    // 0. 若页面已出现 X 账号限制提示，直接返回错误并提示刷新
    if (hasAccountRestrictionBanner()) {
        console.warn('[performActions] X account restriction banner detected - skip and ask user to refresh');
        return { success: false, error: 'ACCOUNT_RESTRICTION: 你的账号可能不允许执行这项操作，请刷新页面并重试' };
    }
    // 1. Check if this is the main tweet (not a reply or thread continuation)
    // Skip this check for comment replies (skipMainTweetCheck = true)
    if (!skipMainTweetCheck && !(await isMainTweet())) {
        console.log('Skipping - this is not the main tweet (reply or thread continuation detected)');
        return { success: false, error: 'Not main tweet - skipping reply' };
    }
    
    if (skipMainTweetCheck) {
        console.log('[Comment Reply] Skipping main tweet check - this is a comment reply');
    }
    
    // 1. Simulate reading the tweet first (scroll 2-5 times)
    await simulateReading();

    // 1. Like
    if (doLike) {
        // Random Delay for Like
        const delay = getRandomDelay(likeDelay);
        if (delay > 0) {
            console.log(`Waiting ${delay}ms before liking...`);
            await wait(delay);
        }

        // Try to find like button - works for both main tweets and comments
        // First try the main article selector, then fallback to any article
        let likeBtn = document.querySelector('article[tabindex="-1"] [data-testid="like"]');
        if (!likeBtn) {
            // Fallback for comment pages or different page structures
            likeBtn = document.querySelector('article [data-testid="like"]');
        }
        if (likeBtn) {
            console.log('[Like] Clicking like button');
            likeBtn.click();
            await wait(500);
        } else {
            console.warn('[Like] Like button not found');
        }
    }

    // 2. Repost
    if (doRepost) {
        const retweetBtn = document.querySelector('article[tabindex="-1"] [data-testid="retweet"]');
        if (retweetBtn) {
            retweetBtn.click();
            await wait(500);
            const confirmRetweet = document.querySelector('[data-testid="retweetConfirm"]');
            if (confirmRetweet) {
                confirmRetweet.click();
                await wait(500);
            }
        }
    }

    // 3. Reply
    if (replyText) {
        // Random Delay for Reply
        const delay = getRandomDelay(replyDelay);
        if (delay > 0) {
            console.log(`Waiting ${delay}ms before replying...`);
            await wait(delay);
        }

        // Look for the inline reply area which is usually at the bottom of the main tweet or below it
        // On status page, there is a main reply input at the bottom fixed or inline.
        // Selector: [data-testid="tweetTextarea_0"]

        // Ensure the input is focused
        const replyInput = document.querySelector('[data-testid="tweetTextarea_0"]');
        if (replyInput) {
            replyInput.focus();
            await wait(200);
            // 先清空回复框，避免把新内容追加到上次残留（出现「正常句+不 稳 1 这」等乱序）
            clearReplyBox();
            await wait(300);

            // Human-like Typing Simulation (slower)
            await typeText(replyText);
            // 必须等回复框内容完整且无新增字符（稳定）后再点回复，避免写到一半就发送导致重复/半截
            let stable = await waitForReplyBoxContentStable(replyText, 15000, 2000);
            if (!stable) {
                await wait(3000);
                stable = await waitForReplyBoxContentStable(replyText, 5000, 1000);
            }
            if (!stable) {
                const current = getReplyBoxText();
                if (current.length < replyText.length) {
                    console.error('[Reply] Aborting - reply box has only ' + current.length + ' chars, expected ' + replyText.length + '. Not clicking to avoid partial send.');
                    return { success: false, error: 'Reply box content did not stabilize, aborted to avoid partial send' };
                }
            }
            await wait(800); // 再稍停一下再点

            // 点击前再次检测：若执行过程中 X 已弹出账号限制横幅，直接返回，避免继续操作导致端口断开
            if (hasAccountRestrictionBanner()) {
                console.warn('[performActions] X account restriction banner appeared before reply click - abort');
                return { success: false, error: 'ACCOUNT_RESTRICTION: 你的账号可能不允许执行这项操作，请刷新页面并重试' };
            }

            // Click Reply Button
            const replyBtn = document.querySelector('[data-testid="tweetButtonInline"]');
            if (replyBtn && !replyBtn.disabled) {
                replyBtn.click();
                // 先固定多等一会（长回复时服务器处理更久），再轮询「回复框已清空」再继续
                await wait(4000);
                await waitForReplySuccess(20000, 600);
                // 回复成功后：失焦回复框 + 多等 2s，让页面完全更新，减少「离开此网站？」弹窗
                const input = document.querySelector('[data-testid="tweetTextarea_0"]');
                if (input) {
                    input.blur();
                    document.body.focus();
                }
                // 回复成功后不再单独固定 2s，与下方「每条回复完成后等待」合并为一次等待
            }
        }
    }

    // 4. 每条回复完成后等待（使用设置项，默认 5-15 秒；不从 0 开始，最小 1 秒）
    const minSec = (postReplyWaitMin != null && postReplyWaitMin >= 1) ? postReplyWaitMin : 5;
    const maxSec = (postReplyWaitMax != null && postReplyWaitMax >= minSec) ? postReplyWaitMax : 15;
    const cooldownMs = Math.floor(Math.random() * (maxSec - minSec + 1) + minSec) * 1000;
    console.log(`Post-reply wait: ${cooldownMs}ms (${minSec}-${maxSec}s)`);
    await wait(cooldownMs);
}

// Simulate reading by scrolling the page 3-8 times (70% down, 30% up)
async function simulateReading() {
    const scrollCount = Math.floor(Math.random() * 6) + 3; // 3-8 scrolls
    console.log(`Simulating reading with ${scrollCount} scrolls...`);

    for (let i = 0; i < scrollCount; i++) {
        // 70% chance to scroll down, 30% to scroll up
        const scrollDown = Math.random() < 0.7;
        const scrollAmount = Math.floor(Math.random() * 200) + 100; // 100-300 pixels
        const direction = scrollDown ? scrollAmount : -scrollAmount;

        window.scrollBy({ top: direction, behavior: 'smooth' });

        // Longer wait between scrolls (1000-2500ms to simulate natural reading)
        const scrollDelay = Math.floor(Math.random() * 1500) + 1000;
        await wait(scrollDelay);
    }

    // Scroll back to top to see reply area
    window.scrollTo({ top: 0, behavior: 'smooth' });
    await wait(800);
}

async function typeText(text) {
    // Focus initially
    const replyInput = document.querySelector('[data-testid="tweetTextarea_0"]');
    if (replyInput) {
        // Simulate click to ensure editor is fully active
        replyInput.click();
        replyInput.focus();

        // Explicit wait as requested: 0.5 - 1.0 seconds
        // This allows the editor to initialize and prevents cursor jumping
        console.log("Focused reply box. Waiting before typing...");
        await wait(500 + Math.random() * 500);
    }

    for (const char of text) {
        // Ensure focus is still there, but don't force it if it causes jumps
        // Only refocus if we lost focus entirely
        if (document.activeElement !== replyInput && replyInput) {
            replyInput.focus();
            // If we refocus, we might need to move cursor to end? 
            // But usually execCommand inserts at cursor. 
            // If focus was lost, cursor might be lost.
            // For now, let's assume user doesn't click away.
        }

        document.execCommand('insertText', false, char);

        // Base random delay (100ms - 250ms) - Slower typing for human-like behavior
        let delay = Math.floor(Math.random() * 150) + 100;

        // Pause between words (space) - longer pause
        if (char === ' ') {
            delay += Math.floor(Math.random() * 200) + 100;
        }

        // Longer pause for punctuation - even slower
        if (['.', ',', '!', '?', '\n'].includes(char)) {
            delay += Math.floor(Math.random() * 500) + 300;
        }

        await wait(delay);
    }
}

function getRandomDelay(delayInput) {
    if (!delayInput) return 0;

    // Handle Object {min, max}
    if (typeof delayInput === 'object' && delayInput !== null) {
        const min = (delayInput.min || 0) * 1000;
        const max = (delayInput.max || 0) * 1000;
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // Handle String "min-max" or single value
    if (typeof delayInput === 'string') {
        const parts = delayInput.split('-').map(s => parseInt(s.trim()));
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
            const min = parts[0] * 1000;
            const max = parts[1] * 1000;
            return Math.floor(Math.random() * (max - min + 1)) + min;
        } else if (parts.length === 1 && !isNaN(parts[0])) {
            return parts[0] * 1000;
        }
    }

    // Handle Number
    if (typeof delayInput === 'number') {
        return delayInput * 1000;
    }

    return 0;
}

// Simulate browsing a KOL profile by scrolling 3-8 times (70% down, 30% up)
async function simulateBrowsingScroll() {
    const scrollCount = Math.floor(Math.random() * 6) + 3; // 3-8 scrolls
    console.log(`Simulating browsing with ${scrollCount} scrolls...`);

    for (let i = 0; i < scrollCount; i++) {
        // 70% chance to scroll down, 30% to scroll up
        const scrollDown = Math.random() < 0.7;
        const scrollAmount = Math.floor(Math.random() * 200) + 200; // 200-400 pixels
        const direction = scrollDown ? scrollAmount : -scrollAmount;

        window.scrollBy({ top: direction, behavior: 'smooth' });

        // Longer wait between scrolls (1200-2500ms to simulate reading)
        const scrollDelay = Math.floor(Math.random() * 1300) + 1200;
        await wait(scrollDelay);
    }
}

function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Auto-scroll state for scanner
let isScannerScrolling = false;

// Find and click "Show more" / "查看更多" buttons with human-like behavior
async function clickShowMoreButtons() {
    // Find all visible "Show more" buttons
    const showMoreButtons = document.querySelectorAll('[data-testid="tweet-text-show-more-link"]');

    for (const btn of showMoreButtons) {
        if (!isScannerScrolling) break;

        // Check if button is visible in viewport
        const rect = btn.getBoundingClientRect();
        const isVisible = rect.top >= 0 && rect.bottom <= window.innerHeight;

        if (isVisible && btn.offsetParent !== null) {
            console.log('Found "Show more" button, preparing to click...');

            // 1. Wait 1-2 seconds before clicking
            const preClickDelay = Math.floor(Math.random() * 1000) + 1000;
            await wait(preClickDelay);

            if (!isScannerScrolling) break;

            // 2. Click the button
            btn.click();
            console.log('Clicked "Show more" button');

            // 3. Wait 200-400ms for content to expand
            const expandDelay = Math.floor(Math.random() * 200) + 200;
            await wait(expandDelay);

            // 4. 50% chance of small scroll (up or down)
            if (Math.random() < 0.5) {
                const scrollDir = Math.random() < 0.5 ? 1 : -1;
                const scrollAmt = Math.floor(Math.random() * 80) + 50;
                window.scrollBy({ top: scrollAmt * scrollDir, behavior: 'smooth' });
            }

            // 5. Wait 1-4 seconds (simulate reading expanded content)
            const readDelay = Math.floor(Math.random() * 3000) + 1000;
            await wait(readDelay);

            // 6. Wait 1-4 seconds before looking for next button
            const nextButtonDelay = Math.floor(Math.random() * 3000) + 1000;
            await wait(nextButtonDelay);
        }
    }
}

// Continuous auto-scroll for scanner mode
// Slower, more human-like: 3-5 scrolls per batch, 2-3 seconds rest, 90% down / 10% up
async function startScannerAutoScroll() {
    if (isScannerScrolling) return;
    isScannerScrolling = true;
    console.log('Scanner auto-scroll started');

    while (isScannerScrolling) {
        // Check for "Show more" buttons and click them first
        await clickShowMoreButtons();

        if (!isScannerScrolling) break;

        // Random 3-5 scrolls per batch
        const scrollsPerBatch = Math.floor(Math.random() * 3) + 3;

        for (let i = 0; i < scrollsPerBatch && isScannerScrolling; i++) {
            // 90% down, 10% up
            const scrollDown = Math.random() < 0.9;

            // Random scroll distance (300-500 pixels)
            const scrollAmount = Math.floor(Math.random() * 200) + 300;
            const direction = scrollDown ? scrollAmount : -scrollAmount;

            window.scrollBy({ top: direction, behavior: 'smooth' });

            // Longer wait between scrolls (500-1000ms)
            const scrollDelay = Math.floor(Math.random() * 500) + 500;
            await wait(scrollDelay);
        }

        // Rest 2-3 seconds between batches (more human-like pause)
        const restTime = Math.floor(Math.random() * 1000) + 2000;
        console.log(`Scanner scroll batch complete. Resting ${restTime}ms...`);
        await wait(restTime);
    }

    console.log('Scanner auto-scroll stopped');
}

function stopScannerAutoScroll() {
    isScannerScrolling = false;
}

// === Comment Reply Functions ===

// Get own tweets from profile page (24 hours limit)
async function scrapeOwnTweets(payload = {}) {
    const maxTweets = payload.maxTweets || 10;
    const hoursLimit = payload.hoursLimit || 24;
    const now = Date.now();
    const timeLimit = now - (hoursLimit * 60 * 60 * 1000);

    const tweets = [];
    const processedIds = new Set();

    // 回复评论：只以「刷到超过 24h 的非置顶推文」为停止条件，无新推文就循环等待刷新
    await scrollToLoadMoreTweets({ hoursLimit });

    // Find all tweet articles on the profile page
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    console.log(`[Scrape Own Tweets] Found ${articles.length} tweet articles on page`);
    
    for (const article of articles) {
        if (tweets.length >= maxTweets) break;

        // Find the tweet link
        const timeLink = article.querySelector('a[href*="/status/"] time');
        if (!timeLink) continue;

        const anchor = timeLink.closest('a');
        if (!anchor) continue;

        const href = anchor.href;
        const match = href.match(/(?:twitter\.com|x\.com)\/([^\/]+)\/status\/(\d+)/);

        if (match) {
            const username = match[1];
            const tweetId = match[2];

            // Skip if already processed
            if (processedIds.has(tweetId)) continue;
            processedIds.add(tweetId);

            // Get timestamp from tweet ID (Snowflake ID)
            let timestamp = null;
            try {
                const id = BigInt(tweetId);
                timestamp = Number((id >> 22n) + 1288834974657n);
                
                // 验证时间戳合理性（应该在2006年之后，当前时间之前）
                const minTimestamp = 1136073600000; // 2006-01-01
                const maxTimestamp = Date.now() + 86400000; // 允许1天误差
                if (timestamp < minTimestamp || timestamp > maxTimestamp) {
                    console.warn(`[Scrape Own Tweets] 时间戳异常: ${timestamp} (推文ID: ${tweetId})`);
                    // 尝试从time元素获取时间
                    const timeElement = timeLink.getAttribute('datetime');
                    if (timeElement) {
                        timestamp = new Date(timeElement).getTime();
                        console.log(`[Scrape Own Tweets] 使用time元素时间: ${timestamp}`);
                    } else {
                        console.warn(`[Scrape Own Tweets] 无法获取推文时间，跳过: ${tweetId}`);
                        continue;
                    }
                }
            } catch (e) {
                console.warn(`[Scrape Own Tweets] 无法解析推文ID时间: ${tweetId}`, e);
                // 尝试从time元素获取时间作为备选
                const timeElement = timeLink.getAttribute('datetime');
                if (timeElement) {
                    timestamp = new Date(timeElement).getTime();
                    console.log(`[Scrape Own Tweets] 使用time元素时间（备选）: ${timestamp}`);
                } else {
                    continue;
                }
            }

            // Filter by time limit - 确保时间戳有效
            if (!timestamp || isNaN(timestamp)) {
                console.warn(`[Scrape Own Tweets] 时间戳无效，跳过: ${tweetId}`);
                continue;
            }
            
            // 计算时间差（小时）
            const hoursDiff = (now - timestamp) / (1000 * 60 * 60);
            
            if (timestamp < timeLimit) {
                console.log(`[Scrape Own Tweets] 跳过超过${hoursLimit}小时的推文: ${tweetId} (${hoursDiff.toFixed(1)}小时前)`);
                continue; // Skip tweets older than limit
            }
            
            console.log(`[Scrape Own Tweets] 包含推文: ${tweetId} (${hoursDiff.toFixed(1)}小时前)`);

            // Extract tweet content
            const tweetTextEl = article.querySelector('[data-testid="tweetText"]');
            const content = tweetTextEl ? tweetTextEl.innerText : '';

            tweets.push({
                id: tweetId,
                username: username,
                url: href,
                content: content,
                timestamp: timestamp
            });
        }
    }

    console.log(`[Scrape Own Tweets] Found ${tweets.length} tweets within ${hoursLimit} hours`);
    return tweets;
}

// Get comments from a tweet page (24 hours limit)
async function scrapeTweetComments(payload = {}) {
    const maxComments = payload.maxComments || 5;
    const hoursLimit = payload.hoursLimit || 24;
    const now = Date.now();
    const timeLimit = now - (hoursLimit * 60 * 60 * 1000);

    const comments = [];
    const processedIds = new Set();

    // Get parent tweet ID (the main tweet this page is showing)
    // The first article is the main tweet
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    let parentTweetId = null;
    if (articles.length > 0) {
        const mainTweetLink = articles[0].querySelector('a[href*="/status/"]');
        if (mainTweetLink) {
            const mainTweetHref = mainTweetLink.href;
            const mainTweetMatch = mainTweetHref.match(/\/status\/(\d+)/);
            if (mainTweetMatch) {
                parentTweetId = mainTweetMatch[1];
            }
        }
    }

    // Scroll to load more comments (may need multiple scrolls)
    // For now, just get visible comments
    await scrollToLoadComments();

    // Find all comment articles (replies to the main tweet)
    // Comments are also article[data-testid="tweet"] elements, but they appear after the main tweet
    const allArticles = document.querySelectorAll('article[data-testid="tweet"]');
    
    // Skip the first article (main tweet)
    const commentArticles = Array.from(allArticles).slice(1);

    for (const article of commentArticles) {
        if (comments.length >= maxComments) break;

        // Find the comment link
        const timeLink = article.querySelector('a[href*="/status/"] time');
        if (!timeLink) continue;

        const anchor = timeLink.closest('a');
        if (!anchor) continue;

        const href = anchor.href;
        
        // Extract comment ID from URL
        // Comment URLs can be: https://x.com/username/status/TWEET_ID/comment/COMMENT_ID
        // Or: https://x.com/username/status/COMMENT_ID (if it's a direct reply)
        const commentMatch = href.match(/(?:twitter\.com|x\.com)\/([^\/]+)\/status\/(\d+)(?:\/(?:comment|reply)\/(\d+))?/);
        
        if (commentMatch) {
            const username = commentMatch[1];
            const statusId = commentMatch[2];
            const commentId = commentMatch[3] || statusId; // Use comment ID if available, otherwise use status ID
            
            // Create unique ID for this comment
            const uniqueId = commentMatch[3] ? `${statusId}_${commentMatch[3]}` : statusId;

            // Skip if already processed
            if (processedIds.has(uniqueId)) continue;
            processedIds.add(uniqueId);

            // Get timestamp from comment ID (Snowflake ID)
            let timestamp = null;
            try {
                const id = BigInt(commentId);
                timestamp = Number((id >> 22n) + 1288834974657n);
            } catch (e) {
                // Try to get timestamp from time element
                const timeText = timeLink.getAttribute('datetime');
                if (timeText) {
                    timestamp = new Date(timeText).getTime();
                } else {
                    console.warn('无法解析评论时间:', commentId);
                    continue;
                }
            }

            // Filter by time limit
            if (timestamp && timestamp < timeLimit) {
                continue; // Skip comments older than limit
            }

            // Extract comment content
            const commentTextEl = article.querySelector('[data-testid="tweetText"]');
            const content = commentTextEl ? commentTextEl.innerText : '';

            // Get comment author
            const authorLink = article.querySelector('a[href*="/"][role="link"]');
            const authorUsername = authorLink ? (authorLink.getAttribute('href')?.match(/\/([^\/]+)$/)?.[1] || '') : '';

            // Skip if it's our own comment
            const currentUser = getCurrentUserUsername();
            if (authorUsername && currentUser && authorUsername.toLowerCase() === currentUser.toLowerCase()) {
                continue;
            }

            // Check if comment has already been replied to manually
            // This is a heuristic check - we'll verify more accurately when trying to reply
            let hasReplied = false;
            // Note: X/Twitter UI doesn't always clearly indicate if we've replied to a comment
            // We'll rely on the reply attempt to detect if it's already replied

            comments.push({
                id: uniqueId,
                commentId: commentId,
                username: authorUsername || username,
                url: href,
                content: content,
                timestamp: timestamp,
                parentTweetId: parentTweetId, // Add parent tweet ID for proper deduplication
                hasReplied: hasReplied // Flag for manually replied comments (will be checked during reply)
            });
        }
    }

    console.log(`[Scrape Tweet Comments] Found ${comments.length} comments within ${hoursLimit} hours`);
    return comments;
}

// Scroll to load more comments until no new comments appear (or max scrolls)
async function scrollToLoadComments() {
    const maxScrolls = 50;
    const maxNoChangeRounds = 3;
    let prevCount = 0;
    let noChangeRounds = 0;

    for (let i = 0; i < maxScrolls; i++) {
        window.scrollBy({ top: 500, behavior: 'smooth' });
        await wait(1000);
        const articles = document.querySelectorAll('article[data-testid="tweet"]');
        const count = Math.max(0, articles.length - 1); // 排除主推文
        if (count > prevCount) {
            prevCount = count;
            noChangeRounds = 0;
        } else {
            noChangeRounds++;
            if (noChangeRounds >= maxNoChangeRounds) break;
        }
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
    await wait(500);
}

// 获取用户主页前两条博主本人发布的推文，回复时间最新的一条（用于「回复评论者首条推文」）
// 置顶帖通常较旧，取最新一条自然跳过；转发的推文跳过，只回复本人发布的
async function getFirstNonPinnedTweet() {
    console.log('[getFirstNonPinnedTweet] Starting...');
    
    const url = window.location.href;
    const match = url.match(/(?:twitter\.com|x\.com)\/([^\/]+)(?:\/.*)?$/);
    const profileOwner = (match && match[1]) ? match[1].toLowerCase() : '';
    if (!profileOwner) {
        console.warn('[getFirstNonPinnedTweet] Cannot get profile owner from URL');
        return null;
    }
    
    await wait(2000);
    window.scrollBy({ top: 500, behavior: 'smooth' });
    await wait(1500);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    await wait(1000);
    
    const links = extractTweetLinks();
    const ownerTweets = links.filter(t => {
        if ((t.username || '').toLowerCase() !== profileOwner) return false;
        if (t.isRetweet) {
            console.log(`[getFirstNonPinnedTweet] 跳过转发的推文: ${t.id} @${t.username}`);
            return false;
        }
        if (t.isPinned) {
            console.log(`[getFirstNonPinnedTweet] 跳过置顶帖: ${t.id} @${t.username}`);
            return false;
        }
        return true;
    });
    console.log(`[getFirstNonPinnedTweet] Found ${links.length} tweets, ${ownerTweets.length} 条本人发布（已排除转发与置顶） from @${profileOwner}`);
    
    if (ownerTweets.length === 0) return null;
    if (ownerTweets.length === 1) {
        console.log(`[getFirstNonPinnedTweet] Only one owner tweet (non-pinned), using: ${ownerTweets[0].id}`);
        return ownerTweets[0];
    }
    const [first, second] = ownerTweets.slice(0, 2);
    const latest = (first.timestamp || 0) >= (second.timestamp || 0) ? first : second;
    console.log(`[getFirstNonPinnedTweet] First two owner tweets (non-pinned): ${first.id}, ${second.id} -> reply to latest: ${latest.id}`);
    return latest;
}

// Scan replies to check if current user has already replied to this tweet/comment
async function scanRepliesForCurrentUser() {
    const currentUser = getCurrentUserUsername();
    if (!currentUser) {
        console.log('[scanRepliesForCurrentUser] Cannot get current user username');
        return false;
    }

    console.log(`[scanRepliesForCurrentUser] Scanning replies for current user: @${currentUser}`);

    // Scroll to load more replies (wait for completion)
    window.scrollBy({ top: 500, behavior: 'smooth' });
    await wait(800);
    window.scrollBy({ top: 500, behavior: 'smooth' });
    await wait(800);
    window.scrollBy({ top: 500, behavior: 'smooth' });
    await wait(800);
    
    // Wait for replies to load
    await wait(1000);
    
    // Scroll back to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
    await wait(500);
    
    // Find all tweet articles (includes main tweet + replies)
    const articles = document.querySelectorAll('article[data-testid="tweet"]');
    console.log(`[scanRepliesForCurrentUser] Found ${articles.length} articles on page`);

    // Skip the first article (main tweet/comment being viewed)
    const replyArticles = Array.from(articles).slice(1);
    console.log(`[scanRepliesForCurrentUser] Checking ${replyArticles.length} reply articles`);

    for (const article of replyArticles) {
        // Get the author username of this reply
        // Try multiple selectors to find author link
        let authorLink = article.querySelector('a[href*="/"][role="link"]');
        if (!authorLink) {
            // Try alternative selector
            const userLink = article.querySelector('[data-testid="User-Name"] a');
            if (userLink) authorLink = userLink;
        }
        if (!authorLink) {
            // Try another alternative
            const userNameEl = article.querySelector('[data-testid="User-Names"] a');
            if (userNameEl) authorLink = userNameEl;
        }
        
        if (!authorLink) continue;

        const authorHref = authorLink.getAttribute('href') || '';
        const authorMatch = authorHref.match(/\/([^\/]+)$/);
        if (!authorMatch) continue;

        const authorUsername = authorMatch[1].toLowerCase().replace('@', '');
        const currentUserLower = currentUser.toLowerCase().replace('@', '');

        // Check if this reply is from current user
        if (authorUsername === currentUserLower) {
            console.log(`[scanRepliesForCurrentUser] ✅ Found own reply: @${authorUsername}`);
            return true; // Current user has already replied
        }
    }

    console.log(`[scanRepliesForCurrentUser] ❌ No own reply found in ${replyArticles.length} replies`);
    return false; // Current user has not replied
}

// 个人主页滚动加载推文：唯一停止条件 = 刷到超过 hoursLimit 的非置顶推文；无新推文就循环等待再滚
async function scrollToLoadMoreTweets(options = {}) {
    const hoursLimit = options.hoursLimit != null ? options.hoursLimit : 24;
    const maxScrollAttempts = options.maxScrollAttempts != null ? options.maxScrollAttempts : 120;
    const minScrollAttempts = 5;
    const now = Date.now();
    const timeLimit = now - (hoursLimit * 60 * 60 * 1000);

    let scrollAttempts = 0;
    let lastCount = 0;
    console.log(`[Scroll Tweets] 滚动直到出现超过 ${hoursLimit}h 的非置顶推文（先滚至少 ${minScrollAttempts} 次再判断，无新推文则循环等待）...`);
    await wait(5000);

    while (scrollAttempts < maxScrollAttempts) {
        const articles = document.querySelectorAll('article[data-testid="tweet"]');
        const currentCount = articles.length;

        let found24h = false;
        if (scrollAttempts >= minScrollAttempts) {
            for (let i = 0; i < articles.length; i++) {
                if (i === 0) continue;
                const article = articles[i];
                const info = getArticleTweetInfo(article);
                if (!info || !info.timestamp || isNaN(info.timestamp)) continue;
                if (info.isPinned) continue;
                if (info.timestamp < timeLimit) {
                    const ageHours = (now - info.timestamp) / (60 * 60 * 1000);
                    console.log(`[Scroll Tweets] 已出现超过 ${hoursLimit}h 的非置顶推文 (${ageHours.toFixed(1)}h, id=${info.tweetId})，停止滚动`);
                    found24h = true;
                    break;
                }
            }
        }
        if (found24h) break;

        const noNewTweets = scrollAttempts > 0 && currentCount === lastCount;
        if (noNewTweets) {
            console.log(`[Scroll Tweets] 本轮无新推文 (${currentCount} 条)，等待 4s 后继续滚动...`);
            await wait(4000);
        }
        lastCount = currentCount;
        console.log(`[Scroll Tweets] Attempt ${scrollAttempts + 1}, 当前 ${currentCount} 条，继续滚动...`);
        window.scrollBy({ top: 600 + Math.random() * 400, behavior: 'smooth' });
        await wait(noNewTweets ? 4000 : 3000 + Math.random() * 2000);
        scrollAttempts++;
    }

    console.log(`[Scroll Tweets] Scrolling back to top...`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    await wait(2500);
    const finalArticles = document.querySelectorAll('article[data-testid="tweet"]');
    console.log(`[Scroll Tweets] 结束，共 ${finalArticles.length} 条推文`);
}

// 个人主页：滚动加载 + 提取推文，过滤 24h 内且排除置顶（用于 KOL 列表 24h 回复）
async function scrollAndExtractProfileTweets(options = {}) {
    const maxAgeHours = options.maxAgeHours != null ? options.maxAgeHours : 24;
    
    console.log(`[scrollAndExtractProfileTweets] Starting: maxAgeHours=${maxAgeHours} (滚动到出现超过 ${maxAgeHours}h 的非置顶推文为止)`);
    
    try {
        await scrollToLoadMoreTweets({ hoursLimit: maxAgeHours });
        const links = extractTweetLinks();
        console.log(`[scrollAndExtractProfileTweets] Extracted ${links.length} total tweets`);
        
        const cutoff = Date.now() - maxAgeHours * 60 * 60 * 1000;
        const filtered = links.filter(t => {
            if (t.isPinned) {
                console.log(`[scrollAndExtractProfileTweets] Skipping pinned tweet: ${t.id}`);
                return false;
            }
            if (t.timestamp < cutoff) {
                const ageHours = (Date.now() - t.timestamp) / (60 * 60 * 1000);
                console.log(`[scrollAndExtractProfileTweets] Skipping old tweet: ${t.id}, age=${ageHours.toFixed(1)}h`);
                return false;
            }
            return true;
        });
        
        console.log(`[scrollAndExtractProfileTweets] Result: ${links.length} extracted, ${filtered.length} within ${maxAgeHours}h (pinned excluded)`);
        return { tweets: filtered };
    } catch (error) {
        console.error('[scrollAndExtractProfileTweets] Error:', error);
        return { tweets: [], error: error.message };
    }
}
