// Comment Reply Module - 评论回复功能模块
// 独立文件，避免 sidepanel.js 臃肿
// 注意：此文件依赖 sidepanel.js 中的 aiConfig、callAI 和 showNotification 函数

// 评论回复状态管理
let commentReplyState = {
    active: false,
    paused: false,
    currentTweetIndex: 0,
    currentCommentIndex: 0,
    tweets: [], // 自己的推文列表
    comments: [], // 当前推文的评论列表
    profileUrl: '', // 配置的主页链接
    maxTweets: 20, // 最多处理的推文数量（默认20）
    maxCommentsPerTweet: 30, // 每条推文最多回复的评论数（默认30）
    systemPrompt: '' // 评论回复专用的System Prompt
};

// 初始化评论回复配置
function initCommentReplyConfig() {
    // 从 localStorage 加载配置
    const savedProfileUrl = localStorage.getItem('commentReplyProfileUrl');
    if (savedProfileUrl) {
        commentReplyState.profileUrl = savedProfileUrl;
    } else {
        // 设置默认主页
        commentReplyState.profileUrl = 'https://x.com/WWTLitee';
    }
    
    const savedMaxTweets = localStorage.getItem('commentReplyMaxTweets');
    if (savedMaxTweets) {
        commentReplyState.maxTweets = parseInt(savedMaxTweets) || 20;
    } else {
        commentReplyState.maxTweets = 20;
    }
    
    const savedMaxComments = localStorage.getItem('commentReplyMaxComments');
    if (savedMaxComments) {
        commentReplyState.maxCommentsPerTweet = parseInt(savedMaxComments) || 30;
    } else {
        commentReplyState.maxCommentsPerTweet = 30;
    }
    
    const savedSystemPrompt = localStorage.getItem('commentReplySystemPrompt');
    if (savedSystemPrompt !== null && savedSystemPrompt.trim() !== '') {
        commentReplyState.systemPrompt = savedSystemPrompt;
    } else {
        commentReplyState.systemPrompt = '你是加密货币领域KOL，生成2-20字的推文评论，语言匹配推文主要语言（中英文为主，多语言以中文回复）不要用双引号,不要用@账户,不要用任何括号括起来,评论不要太官方,要有人性化。自动回复内容去除句号，逗号保留';
    }
}

// 保存评论回复配置
function saveCommentReplyConfig() {
    localStorage.setItem('commentReplyProfileUrl', commentReplyState.profileUrl);
    localStorage.setItem('commentReplyMaxTweets', commentReplyState.maxTweets.toString());
    localStorage.setItem('commentReplyMaxComments', commentReplyState.maxCommentsPerTweet.toString());
    localStorage.setItem('commentReplySystemPrompt', commentReplyState.systemPrompt);
}

// 获取已回复的评论ID列表（去重机制）
function getRepliedCommentIds() {
    try {
        const repliedData = localStorage.getItem('repliedCommentIds');
        return repliedData ? new Set(JSON.parse(repliedData)) : new Set();
    } catch (e) {
        console.warn('[Comment Reply] Failed to parse repliedCommentIds, using empty set:', e);
        return new Set();
    }
}

// 安全保存已回复的评论ID（配额管理：存储满时清理旧记录，避免重复回复）
function safeSaveRepliedCommentIds(ids) {
    const arr = Array.from(ids);
    try {
        localStorage.setItem('repliedCommentIds', JSON.stringify(arr));
        return true;
    } catch (e) {
        if (e.name === 'QuotaExceededError') {
            console.warn('[Comment Reply] Storage quota exceeded for repliedCommentIds, cleaning old entries...');
            const cleaned = arr.slice(-5000);
            try {
                localStorage.setItem('repliedCommentIds', JSON.stringify(cleaned));
                console.log(`[Comment Reply] Cleaned repliedCommentIds, kept ${cleaned.length} most recent entries`);
                return true;
            } catch (e2) {
                try {
                    const moreCleaned = arr.slice(-3000);
                    localStorage.setItem('repliedCommentIds', JSON.stringify(moreCleaned));
                    console.log(`[Comment Reply] Further cleaned to ${moreCleaned.length} entries`);
                    return true;
                } catch (e3) {
                    console.error('[Comment Reply] Failed to save repliedCommentIds even after cleanup');
                    return false;
                }
            }
        }
        console.error('[Comment Reply] Error saving repliedCommentIds:', e);
        return false;
    }
}

// 保存已回复的评论ID（使用安全写入，存储满时自动清理旧记录）
function saveRepliedCommentId(commentId) {
    const repliedIds = getRepliedCommentIds();
    repliedIds.add(commentId);
    const arr = Array.from(repliedIds);
    const toSave = arr.length > 6000 ? new Set(arr.slice(-5000)) : repliedIds;
    const ok = safeSaveRepliedCommentIds(toSave);
    if (ok) {
        console.log('[Comment Reply] Marked comment as replied:', commentId);
    } else {
        console.warn('[Comment Reply] Failed to persist repliedCommentIds (may cause duplicate replies):', commentId);
    }
}

// 检查评论是否已回复
function isCommentReplied(commentId) {
    const repliedIds = getRepliedCommentIds();
    return repliedIds.has(commentId);
}

// 标准化评论ID（从评论URL中提取）
// 格式：parentTweetId_commentId 确保同一评论在不同推文下有不同的ID
function normalizeCommentId(commentUrl, parentTweetId = null) {
    if (!commentUrl) return null;
    
    const match = commentUrl.match(/\/status\/(\d+)\/(?:comment|reply)\/(\d+)/);
    if (match) {
        const tweetId = match[1];
        const commentId = match[2];
        const parentId = parentTweetId || tweetId;
        return `${parentId}_${commentId}`;
    }
    
    const statusMatch = commentUrl.match(/\/status\/(\d+)/);
    if (statusMatch) {
        const statusId = statusMatch[1];
        if (parentTweetId) return `${parentTweetId}_${statusId}`;
        return statusId;
    }
    
    const normalized = commentUrl.replace(/\/$/, '').split('?')[0];
    if (parentTweetId) return `${parentTweetId}_${normalized}`;
    return normalized;
}

// 启动评论回复功能
async function startCommentReply() {
    if (commentReplyState.active) {
        stopCommentReply();
        return;
    }
    if (!commentReplyState.profileUrl) {
        if (typeof showNotification === 'function') showNotification('请先配置主页链接', true);
        else console.error('[Comment Reply] 请先配置主页链接');
        return;
    }
    if (!commentReplyState.profileUrl.includes('x.com/') && !commentReplyState.profileUrl.includes('twitter.com/')) {
        if (typeof showNotification === 'function') showNotification('请输入有效的X/Twitter主页链接', true);
        else console.error('[Comment Reply] 请输入有效的X/Twitter主页链接');
        return;
    }

    commentReplyState.active = true;
    commentReplyState.paused = false;
    commentReplyState.currentTweetIndex = 0;
    commentReplyState.currentCommentIndex = 0;
    commentReplyState.tweets = [];
    commentReplyState.comments = [];
    console.log('[Comment Reply] Starting comment reply process');
    updateCommentReplyUI();
    await processCommentReply();
}

// 停止评论回复功能
function stopCommentReply() {
    commentReplyState.active = false;
    commentReplyState.paused = false;
    updateCommentReplyUI();
    if (typeof window.hideGlobalProgress === 'function') window.hideGlobalProgress();
    if (typeof showNotification === 'function') showNotification('评论回复已停止', false);
    console.log('[Comment Reply] Stopped');
}

// 暂停/继续评论回复（恢复时仅清除暂停，不重调 processCommentReply，避免与等待中的 Promise 重复）
function togglePauseCommentReply() {
    commentReplyState.paused = !commentReplyState.paused;
    updateCommentReplyUI();
    if (typeof showNotification === 'function') {
        showNotification(commentReplyState.paused ? '评论回复已暂停' : '评论回复已继续', false);
    }
    // 恢复时不调用 processCommentReply()，由 fetchOwnTweets/fetchTweetComments/processNextComment 的 interval 在下一轮检测到 !paused 后 resolve 并继续
}

// 更新评论回复UI状态
function updateCommentReplyUI() {
    const btn = document.getElementById('startCommentReplyBtn');
    const pauseBtn = document.getElementById('pauseCommentReplyBtn');
    const stopBtn = document.getElementById('stopCommentReplyBtn');
    const progressContainer = document.getElementById('commentReplyProgress');
    if (!btn) return;

    if (!commentReplyState.active) {
        btn.textContent = '回复推文评论';
        btn.style.display = '';
        btn.classList.remove('active-state', 'paused-state');
        if (pauseBtn) pauseBtn.style.display = 'none';
        if (stopBtn) stopBtn.style.display = 'none';
        if (progressContainer) progressContainer.style.display = 'none';
    } else if (commentReplyState.paused) {
        btn.style.display = 'none';
        btn.classList.add('paused-state');
        btn.classList.remove('active-state');
        if (pauseBtn) pauseBtn.style.display = 'inline-block';
        if (stopBtn) stopBtn.style.display = 'inline-block';
        if (progressContainer) progressContainer.style.display = 'block';
    } else {
        btn.style.display = 'none';
        btn.classList.add('active-state');
        btn.classList.remove('paused-state');
        btn.innerHTML = '<div class="jumping-text"><span>A</span><span>i</span><span>n</span><span>g</span></div>';
        if (pauseBtn) pauseBtn.style.display = 'inline-block';
        if (stopBtn) stopBtn.style.display = 'inline-block';
        if (progressContainer) progressContainer.style.display = 'block';
    }
    updateCommentReplyProgress();
}

// 更新评论回复进度条（同时写入底部固定全局进度条）
function updateCommentReplyProgress() {
    const statusEl = document.getElementById('commentReplyStatus');
    const progressTextEl = document.getElementById('commentReplyProgressText');
    const progressBarEl = document.getElementById('commentReplyProgressBar');
    const tweetInfoEl = document.getElementById('commentReplyTweetInfo');
    const commentInfoEl = document.getElementById('commentReplyCommentInfo');

    const totalTweets = commentReplyState.tweets.length;
    const currentTweetIndex = commentReplyState.currentTweetIndex;
    const totalComments = commentReplyState.comments.length;
    const currentCommentIndex = commentReplyState.currentCommentIndex;
    let totalItems = 0, completedItems = currentTweetIndex;
    if (totalComments > 0) {
        completedItems += currentCommentIndex;
        totalItems += totalComments;
    }
    if (totalTweets > currentTweetIndex && totalComments > 0) {
        totalItems += (totalTweets - currentTweetIndex - 1) * totalComments;
    }

    let message = '处理中...';
    if (totalTweets === 0) {
        message = '正在获取推文列表...';
        if (statusEl) statusEl.textContent = message;
        if (progressTextEl) progressTextEl.textContent = '0/0';
        if (progressBarEl) progressBarEl.style.width = '0%';
        if (typeof window.updateGlobalProgress === 'function') window.updateGlobalProgress({ type: 'commentReply', current: 0, total: 1, message });
        return;
    }
    const currentTweet = commentReplyState.tweets[currentTweetIndex];
    if (totalComments === 0) message = `正在获取评论 (推文 ${currentTweetIndex + 1}/${totalTweets})...`;
    else if (currentCommentIndex < totalComments) message = `正在回复评论 (${currentCommentIndex + 1}/${totalComments}) (推文 ${currentTweetIndex + 1}/${totalTweets})`;
    else message = `推文 ${currentTweetIndex + 1}/${totalTweets} 处理完成`;
    if (currentTweetIndex >= totalTweets) message = '所有推文处理完成';

    if (statusEl) statusEl.textContent = message;
    const progressPercent = totalItems > 0 ? Math.min(100, Math.round((completedItems / totalItems) * 100)) : 0;
    if (progressTextEl) progressTextEl.textContent = `${completedItems}/${totalItems}`;
    if (progressBarEl) progressBarEl.style.width = `${progressPercent}%`;
    if (tweetInfoEl) tweetInfoEl.textContent = `推文: ${currentTweetIndex + 1}/${totalTweets}`;
    if (commentInfoEl) commentInfoEl.textContent = totalComments > 0 ? `评论: ${currentCommentIndex + 1}/${totalComments}` : '评论: 0/0';

    if (typeof window.updateGlobalProgress === 'function') window.updateGlobalProgress({ type: 'commentReply', current: completedItems, total: Math.max(1, totalItems), message, subLabel: '当前推文', subCurrent: currentTweetIndex + 1, subTotal: Math.max(1, totalTweets) });
}

// 主处理流程
async function processCommentReply() {
    if (!commentReplyState.active || commentReplyState.paused) return;

    if (commentReplyState.tweets.length === 0) {
        updateCommentReplyProgress();
        await fetchOwnTweets();
        updateCommentReplyProgress();
    }
    if (commentReplyState.currentTweetIndex >= commentReplyState.tweets.length) {
        console.log('[Comment Reply] All tweets processed');
        stopCommentReply();
        if (typeof showNotification === 'function') showNotification(`评论回复完成，共处理 ${commentReplyState.tweets.length} 条推文`, false);
        return;
    }

    const currentTweet = commentReplyState.tweets[commentReplyState.currentTweetIndex];
    if (commentReplyState.comments.length === 0) {
        updateCommentReplyProgress();
        console.log(`[Comment Reply] Fetching comments for tweet ${commentReplyState.currentTweetIndex + 1}/${commentReplyState.tweets.length}...`);
        await fetchTweetComments(currentTweet);
        updateCommentReplyProgress();
        if (commentReplyState.comments.length === 0) {
            if (typeof showNotification === 'function') {
                showNotification(`推文 ${commentReplyState.currentTweetIndex + 1}/${commentReplyState.tweets.length} 评论已全部回复过，跳过`, false);
            }
            commentReplyState.currentTweetIndex++;
            commentReplyState.currentCommentIndex = 0;
            commentReplyState.comments = [];
            if (commentReplyState.currentTweetIndex < commentReplyState.tweets.length) setTimeout(() => processCommentReply(), 1000);
            else stopCommentReply();
            return;
        }
        commentReplyState.currentCommentIndex = 0;
        console.log(`[Comment Reply] Comments fetched, ${commentReplyState.comments.length} to process`);
    }

    if (commentReplyState.currentCommentIndex >= commentReplyState.comments.length) {
        commentReplyState.currentTweetIndex++;
        commentReplyState.currentCommentIndex = 0;
        commentReplyState.comments = [];
        updateCommentReplyProgress();
        if (commentReplyState.currentTweetIndex < commentReplyState.tweets.length) {
            await new Promise(r => setTimeout(r, 2000));
            processCommentReply();
        } else stopCommentReply();
        return;
    }

    await processNextComment();
}

// 获取自己的推文列表
async function fetchOwnTweets() {
    return new Promise((resolve, reject) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0]) { reject(new Error('No active tab')); return; }
            const tabId = tabs[0].id;
            chrome.tabs.update(tabId, { url: commentReplyState.profileUrl });
            const checkTabStatus = setInterval(() => {
                if (!commentReplyState.active) { clearInterval(checkTabStatus); return; }
                if (commentReplyState.paused) return;
                chrome.tabs.get(tabId, async (tab) => {
                    if (chrome.runtime.lastError || !tab) { clearInterval(checkTabStatus); reject(new Error('Tab error')); return; }
                    if (tab.status === 'complete') {
                        if (commentReplyState.paused) return;
                        clearInterval(checkTabStatus);
                        setTimeout(async () => {
                            try {
                                const response = await chrome.tabs.sendMessage(tabId, { action: 'SCRAPE_OWN_TWEETS', payload: { maxTweets: commentReplyState.maxTweets, hoursLimit: 24 } });
                                if (response && response.tweets) {
                                    commentReplyState.tweets = response.tweets;
                                    console.log(`[Comment Reply] Fetched ${response.tweets.length} tweets`);
                                    if (typeof showNotification === 'function') {
                                        showNotification(`已加载 ${response.tweets.length} 条 24h 内推文，将逐条检查评论并回复（已回复过的评论会自动跳过）`, false);
                                    }
                                    resolve(response.tweets);
                                } else reject(new Error('Failed to fetch tweets'));
                            } catch (e) { console.error('[Comment Reply] Error fetching tweets:', e); reject(e); }
                        }, 3000);
                    }
                });
            }, 500);
        });
    });
}

// 获取推文下的评论列表
async function fetchTweetComments(tweet) {
    return new Promise((resolve, reject) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0] || !commentReplyState.active) { reject(new Error('No active tab')); return; }
            const tabId = tabs[0].id;
            chrome.tabs.update(tabId, { url: tweet.url });
            const checkTabStatus = setInterval(() => {
                if (!commentReplyState.active) { clearInterval(checkTabStatus); return; }
                if (commentReplyState.paused) return;
                chrome.tabs.get(tabId, async (tab) => {
                    if (chrome.runtime.lastError || !tab) { clearInterval(checkTabStatus); reject(new Error('Tab error')); return; }
                    if (tab.status === 'complete') {
                        if (commentReplyState.paused) return;
                        clearInterval(checkTabStatus);
                        setTimeout(async () => {
                            try {
                                const response = await chrome.tabs.sendMessage(tabId, { action: 'SCRAPE_TWEET_COMMENTS', payload: { maxComments: commentReplyState.maxCommentsPerTweet, hoursLimit: 24 } });
                                if (response && response.comments) {
                                    const currentTweet = commentReplyState.tweets[commentReplyState.currentTweetIndex];
                                    const parentTweetId = currentTweet ? currentTweet.id : (response.comments[0]?.parentTweetId || null);
                                    const filteredComments = response.comments.filter(comment => {
                                        const commentParentId = comment.parentTweetId || parentTweetId;
                                        const commentId = normalizeCommentId(comment.url || comment.id, commentParentId);
                                        if (!commentId) return false;
                                        if (isCommentReplied(commentId)) { console.log('[Comment Reply] Skipping already replied:', commentId); return false; }
                                        if (comment.hasReplied) { saveRepliedCommentId(commentId); return false; }
                                        return true;
                                    });
                                    commentReplyState.comments = filteredComments;
                                    commentReplyState.currentCommentIndex = 0;
                                    console.log(`[Comment Reply] ${response.comments.length} comments, ${filteredComments.length} new to reply`);
                                    resolve(filteredComments);
                                } else { commentReplyState.comments = []; commentReplyState.currentCommentIndex = 0; resolve([]); }
                            } catch (e) { console.error('[Comment Reply] Error fetching comments:', e); commentReplyState.comments = []; commentReplyState.currentCommentIndex = 0; resolve([]); }
                        }, 3000);
                    }
                });
            }, 500);
        });
    });
}

// 获取当前评论的 parentTweetId（与 fetchTweetComments 一致）
function getParentTweetIdForComment(comment) {
    const currentTweet = commentReplyState.tweets[commentReplyState.currentTweetIndex];
    return currentTweet ? currentTweet.id : (comment.parentTweetId || null);
}

// 处理下一条评论
async function processNextComment() {
    if (!commentReplyState.active || commentReplyState.paused) return;
    updateCommentReplyProgress();

    const comment = commentReplyState.comments[commentReplyState.currentCommentIndex];
    if (!comment) {
        commentReplyState.currentCommentIndex = commentReplyState.comments.length;
        processCommentReply();
        return;
    }

    const parentTweetId = getParentTweetIdForComment(comment);
    const commentId = normalizeCommentId(comment.url || comment.id, parentTweetId);
    console.log(`[Comment Reply] Processing ${commentReplyState.currentCommentIndex + 1}/${commentReplyState.comments.length}:`, commentId);

    if (commentId && isCommentReplied(commentId)) {
        console.log('[Comment Reply] Already replied, skipping:', commentId);
        commentReplyState.currentCommentIndex++;
        processCommentReply();
        return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        if (!tabs[0] || !commentReplyState.active) return;
        const tabId = tabs[0].id;
        const commentUrl = comment.url || comment.id;
        chrome.tabs.update(tabId, { url: commentUrl });

        const checkTabStatus = setInterval(() => {
            if (!commentReplyState.active) { clearInterval(checkTabStatus); return; }
            if (commentReplyState.paused) return;
            chrome.tabs.get(tabId, async (tab) => {
                if (chrome.runtime.lastError || !tab) { clearInterval(checkTabStatus); return; }
                if (tab.status !== 'complete') return;
                if (commentReplyState.paused) return;
                clearInterval(checkTabStatus);

                setTimeout(async () => {
                    if (!commentReplyState.active || commentReplyState.paused) return;
                    const parentId = getParentTweetIdForComment(comment);
                    const cid = normalizeCommentId(comment.url || comment.id, parentId);

                    try {
                        const scrapeResponse = await chrome.tabs.sendMessage(tabId, { action: 'SCRAPE_TWEET_CONTENT' });
                        if (!scrapeResponse || !scrapeResponse.content) {
                            commentReplyState.currentCommentIndex++;
                            processCommentReply();
                            return;
                        }

                        if (scrapeResponse.isLiked) {
                            if (cid) saveRepliedCommentId(cid);
                            commentReplyState.currentCommentIndex++;
                            processCommentReply();
                            return;
                        }

                        await new Promise(r => setTimeout(r, 1000));
                        try {
                            const scanResponse = await chrome.tabs.sendMessage(tabId, { action: 'SCAN_REPLIES' });
                            if (scanResponse && scanResponse.hasReplied) {
                                if (cid) saveRepliedCommentId(cid);
                                commentReplyState.currentCommentIndex++;
                                processCommentReply();
                                return;
                            }
                        } catch (_) {}

                        if (typeof aiConfig === 'undefined' || typeof callAI === 'undefined') {
                            commentReplyState.currentCommentIndex++;
                            processCommentReply();
                            return;
                        }

                        let systemPrompt = commentReplyState.systemPrompt || aiConfig.systemPrompt || '你是加密货币领域KOL，生成2-20字的推文评论，语言匹配推文主要语言（中英文为主，多语言以中文回复）不要用双引号,不要用@账户,不要用任何括号括起来,评论不要太官方,要有人性化。自动回复内容去除句号，逗号保留';
                        const currentUser = scrapeResponse.currentUser || '';
                        const tweetAuthor = scrapeResponse.tweetAuthor || '';
                        const currentTweet = commentReplyState.tweets[commentReplyState.currentTweetIndex];
                        const originalTweetContent = currentTweet ? currentTweet.content : '';

                        let enhancedPrompt = systemPrompt;
                        if (currentUser && tweetAuthor) {
                            if (tweetAuthor.toLowerCase() !== currentUser.toLowerCase()) {
                                enhancedPrompt += `\n\n当前情况：\n- 你是 @${currentUser}\n- 评论作者是 @${tweetAuthor}\n- 这是 @${tweetAuthor} 对你推文的评论\n\n请先判断评论对象，然后根据判断结果回复。`;
                            } else {
                                console.log('[Comment Reply] Skipping own comment');
                                commentReplyState.currentCommentIndex++;
                                processCommentReply();
                                return;
                            }
                        }

                        let fullContext = `评论作者：${tweetAuthor || '未知'}\n当前用户（你）：${currentUser || '未知'}\n`;
                        if (originalTweetContent) fullContext += `原推文内容：${originalTweetContent}\n`;
                        fullContext += `评论内容：${scrapeResponse.content}`;

                        const replyText = await callAI(aiConfig.provider, aiConfig.apiKey, enhancedPrompt, fullContext);
                        if (!replyText) {
                            commentReplyState.currentCommentIndex++;
                            processCommentReply();
                            return;
                        }

                        const autoLike = aiConfig.autoLike || false;
                        const actionResult = await chrome.tabs.sendMessage(tabId, {
                            action: 'PERFORM_ACTIONS',
                            payload: {
                                replyText, doLike: autoLike, doRepost: false,
                                replyDelay: `${aiConfig.replyDelayMin || 3}-${aiConfig.replyDelayMax || 5}`,
                                likeDelay: `${aiConfig.likeDelayMin || 1}-${aiConfig.likeDelayMax || 2}`,
                                skipMainTweetCheck: true
                            }
                        });

                        if (actionResult) {
                            if (actionResult.error && /already|已回复|replied|Not main tweet/i.test(actionResult.error)) {
                                if (cid) saveRepliedCommentId(cid);
                                commentReplyState.currentCommentIndex++;
                                processCommentReply();
                                return;
                            }
                            if (actionResult.success !== false && cid) saveRepliedCommentId(cid);
                        } else {
                            if (cid) saveRepliedCommentId(cid);
                        }

                        const delay = 3000 + Math.floor(Math.random() * 2000);
                        commentReplyState.currentCommentIndex++;
                        setTimeout(() => processCommentReply(), delay);
                    } catch (error) {
                        console.error('[Comment Reply] Error:', error);
                        commentReplyState.currentCommentIndex++;
                        setTimeout(() => processCommentReply(), 2000);
                    }
                }, 3000);
            });
        }, 500);
    });
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { commentReplyState, initCommentReplyConfig, saveCommentReplyConfig, startCommentReply, stopCommentReply, togglePauseCommentReply, updateCommentReplyUI };
}
