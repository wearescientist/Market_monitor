/**
 * ARCHIVED COMMUNITY SCAN FEATURE
 * Archived on: 2025-12-11
 * 
 * This file contains code related to the Community Scan feature that was removed from the main extension.
 * It includes logic from content.js, sidepanel.js, and sidepanel.html.
 */

/* ==========================================================================
   FROM: content.js
   ========================================================================== */

// Message Handlers (Reference)
/*
    // Community scan: Get list of communities
    if (message.action === 'GET_COMMUNITIES') {
        const communities = getCommunityList();
        sendResponse(communities);
        return false;
    }

    // Community scan: Scan a specific community
    if (message.action === 'SCAN_COMMUNITY') {
        scanCommunityMessages(message.communityId).then(result => {
            sendResponse(result);
        });
        return true; // Keep channel open for async
    }

    // Community scan: Click on a community to enter it
    if (message.action === 'CLICK_COMMUNITY') {
        clickCommunityById(message.communityId).then(success => {
            sendResponse({ success });
        });
        return true; // Keep channel open for async
    }
*/

// Get list of communities from the DM drawer (right side of X)
// Uses URL pattern matching: group chats have URLs like /chat/gXXXX, private chats have /chat/XXXX-XXXX
function getCommunityList() {
    const communities = [];

    console.log('Scanning for communities using URL pattern...');

    // Find all group chat links (URLs starting with /i/chat/g)
    const groupLinks = document.querySelectorAll('a[href*="/i/chat/g"]');

    console.log(`Found ${groupLinks.length} group chat links`);

    groupLinks.forEach((link, index) => {
        const href = link.href;
        const groupId = href.match(/\/chat\/(g\d+)/)?.[1];

        if (groupId) {
            // Extract group name from the link's container
            const container = link.closest('[data-testid="cellInnerDiv"]') ||
                link.closest('[data-testid="conversation"]') ||
                link.parentElement;

            let name = '';

            if (container) {
                // Try to find the group name from the container's text
                // The group name is usually in the first text element before time indicators
                const textContent = container.textContent || '';

                // Method 1: Look for divs that contain the title
                const titleDivs = container.querySelectorAll('div[dir="ltr"]');
                for (const div of titleDivs) {
                    const text = div.textContent.trim();
                    // Skip time indicators and "sent" messages
                    if (text &&
                        text.length > 2 &&
                        text.length < 60 &&
                        !text.match(/^\d+[mhdws]$/) && // Not time like "7m", "2h", "3d", "1w", "30s"
                        !text.includes('sent a') &&
                        !text.includes('sent an') &&
                        !text.match(/^(You|你):/)) { // Not a message preview
                        name = text;
                        break;
                    }
                }

                // Method 2: Fallback - first line of text
                if (!name) {
                    const lines = textContent.split('\n').filter(l => l.trim().length > 2);
                    if (lines[0]) {
                        // Clean up the name (remove time indicators at the end)
                        name = lines[0].replace(/\d+[mhdws]$/, '').trim().substring(0, 50);
                    }
                }
            }

            // Final fallback: use the group ID
            if (!name) {
                name = groupId;
            }

            // Avoid duplicates (check by ID, not name)
            if (!communities.find(c => c.id === groupId)) {
                communities.push({
                    id: groupId,
                    element: link,
                    name: name.trim(),
                    url: href,
                    isGroup: true
                });
                console.log(`Found community: ${name} (${groupId})`);
            }
        }
    });

    console.log(`Total communities found: ${communities.length}`);
    return communities;
}

// Click on a community by ID to enter the chat
// Now uses the new group ID format (gXXXX) from URL pattern matching
async function clickCommunityById(communityId) {
    console.log(`Attempting to click on community: ${communityId}`);

    // Method 1: Direct URL match - most reliable
    // Find the link that contains this specific group ID in its href
    if (communityId.startsWith('g')) {
        const directLink = document.querySelector(`a[href*="/i/chat/${communityId}"]`);
        if (directLink) {
            console.log(`Found direct link for ${communityId}, clicking...`);
            directLink.click();
            await new Promise(r => setTimeout(r, 800));
            return true;
        }
    }

    // Method 2: Find by group ID in all group chat links
    const groupLinks = document.querySelectorAll('a[href*="/i/chat/g"]');
    for (const link of groupLinks) {
        const href = link.href;
        const groupId = href.match(/\/chat\/(g\d+)/)?.[1];

        if (groupId === communityId) {
            console.log(`Found matching group link: ${href}`);
            link.click();
            await new Promise(r => setTimeout(r, 800));
            return true;
        }
    }

    // Method 3: Fallback - navigate directly to the chat URL
    if (communityId.startsWith('g')) {
        console.log(`Trying direct navigation to: /i/chat/${communityId}`);
        window.location.href = `https://x.com/i/chat/${communityId}`;
        await new Promise(r => setTimeout(r, 1500));
        return true;
    }

    console.log(`Could not find community: ${communityId}`);
    return false;
}

// Scan messages in a community for tweet links
async function scanCommunityMessages(communityId) {
    const tweets = [];

    // Find all links in the current DM view that look like tweet URLs
    const links = document.querySelectorAll('a[href*="/status/"]');

    links.forEach(link => {
        const href = link.href;
        const match = href.match(/(?:twitter\.com|x\.com)\/([^\/]+)\/status\/(\d+)/);

        if (match) {
            const username = match[1];
            const tweetId = match[2];

            // Skip if it's a quote tweet or embedded preview that's not a share
            if (!tweets.find(t => t.id === tweetId)) {
                tweets.push({
                    id: tweetId,
                    username: username,
                    url: href,
                    timestamp: getTweetTimestamp(tweetId)
                });
            }
        }
    });

    console.log(`Found ${tweets.length} tweet links in community`);
    return { tweets };
}

/* ==========================================================================
   FROM: sidepanel.html (HTML Structure)
   ========================================================================== */

/*
<!-- Community/Group Icon in Sidebar -->
<button id="navCommunity" class="nav-btn" title="社群扫描">
  <svg class="icon-svg" viewBox="0 0 24 24">
    <path
      d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z" />
  </svg>
</button>

<!-- Community View Container -->
<div id="viewCommunity" class="view">
  <header>
    <h1>社群扫描</h1>
  </header>

  <!-- Current Community Status -->
  <div class="status-bar" id="communityStatus">
    <span id="communityStatusText">请先进入社群聊天界面，然后点击扫描</span>
  </div>

  <!-- Community Tweet List -->
  <div id="communityList" class="tweet-list">
    <div class="empty-state">
      1. 打开 X 右下角消息面板<br>
      2. 进入一个社群聊天<br>
      3. 点击下方「扫描」按钮
    </div>
  </div>

  <!-- Community Action Toolbar -->
  <div class="community-toolbar">
    <button id="multiGroupBtn" class="community-action-btn" title="多群组扫描模式">
      <span>多群</span>
    </button>
    <button id="scanCommunityBtn" class="community-action-btn primary-btn" title="扫描当前社群中的帖子链接">
      <span>扫描</span>
    </button>
    <button id="aiCommunityBtn" class="community-action-btn" title="AI自动回复">
      <span>AI</span>
    </button>
    <button id="clearCommunityBtn" class="community-action-btn danger" title="清空列表">
      <span>清空</span>
    </button>
  </div>
</div>
*/

/* ==========================================================================
   FROM: sidepanel.js
   ========================================================================== */

// === Community Scan Feature ===

/*
const communityList = document.getElementById('communityList');
const communityStatusText = document.getElementById('communityStatusText');
const selectCommunityBtn = document.getElementById('selectCommunityBtn');
const scanCommunityBtn = document.getElementById('scanCommunityBtn');
const aiCommunityBtn = document.getElementById('aiCommunityBtn');
const clearCommunityBtn = document.getElementById('clearCommunityBtn');
const multiGroupBtn = document.getElementById('multiGroupBtn');

// Community State
const communityState = {
    selectedCommunity: null,
    communityName: '',
    scanning: false,
    aiRunning: false,
    multiGroupMode: false,
    selectedGroups: [],
    tweets: new Map() // Local store for community tweets
};
*/

// Add community tweet card
function addCommunityTweetCard(tweet) {
    removeEmptyState(communityList);

    const card = document.createElement('div');
    card.className = 'community-tweet-card';
    card.dataset.id = tweet.id;

    // Format timestamp as full date/time
    const formatFullTime = (ts) => {
        if (!ts) return '';
        const date = new Date(ts);
        if (isNaN(date.getTime())) return ts;
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const year = date.getFullYear();
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const ampm = date.getHours() >= 12 ? 'PM' : 'AM';
        const hour12 = date.getHours() % 12 || 12;
        return `${month}/${day}/${year}, ${hour12}:${minutes} ${ampm}`;
    };

    card.innerHTML = `
        <div class="community-tweet-header">
            <span class="community-tweet-user">@${tweet.username || 'User'}...</span>
            <span class="community-tweet-time">${formatFullTime(tweet.timestamp)}</span>
            <div class="community-tweet-header-actions">
                <button class="community-tweet-mini-btn expand" title="在新标签页打开">⊕</button>
                <button class="community-tweet-mini-btn delete" title="删除">🗑</button>
            </div>
        </div>
        <div class="community-tweet-body">
            <a href="${tweet.url}" target="_blank" class="community-tweet-link">${tweet.url}</a>
        </div>
        <div class="community-tweet-actions">
            <button class="community-action-icon reply ${tweet.interactions?.reply ? 'active' : ''}" title="回复">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M1.751 10c0-4.42 3.584-8 8.005-8h4.481c4.436 0 8.05 3.58 8.05 8s-3.614 8-8.05 8h-1.5v3.55c0 .3-.36.47-.6.28-2.22-1.75-4.1-3.85-5.61-6.18-1.66-2.54-2.83-5.36-2.83-7.65zm8.005-6c-3.317 0-6.005 2.69-6.005 6 0 1.85 1.01 4.24 2.46 6.45 1.24 1.89 2.78 3.68 4.68 5.23V18.5c0-.83.67-1.5 1.5-1.5h2.363c3.333 0 6.05-2.69 6.05-6s-2.717-6-6.05-6H9.756z"/></svg>
            </button>
            <button class="community-action-icon retweet ${tweet.interactions?.retweet ? 'active' : ''}" title="转发">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M4.5 3.88l4.432 4.14-1.364 1.46L5.5 7.55V16c0 1.1.896 2 2 2H13v2H7.5c-2.209 0-4-1.79-4-4V7.55L1.432 9.48.068 8.02 4.5 3.88zM16.5 6H11V4h5.5c2.209 0 4 1.79 4 4v8.45l2.068-1.93 1.364 1.46-4.432 4.14-4.432-4.14 1.364-1.46 2.068 1.93V8c0-1.1-.896-2-2-2z"/></svg>
            </button>
            <button class="community-action-icon like ${tweet.interactions?.like ? 'active' : ''}" title="喜欢">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M16.697 5.5c-1.222-.06-2.679.51-3.89 2.16l-.805 1.09-.806-1.09C9.984 6.01 8.526 5.44 7.304 5.5c-1.243.07-2.349.78-2.91 1.91-.552 1.12-.633 2.78.479 4.82 1.074 1.97 3.257 4.27 7.129 6.61 3.87-2.34 6.052-4.64 7.126-6.61 1.111-2.04 1.03-3.7.477-4.82-.561-1.13-1.666-1.84-2.908-1.91zm4.187 7.69c-1.351 2.48-4.001 5.12-8.379 7.67l-.503.3-.504-.3c-4.379-2.55-7.029-5.19-8.382-7.67-1.36-2.5-1.41-4.86-.514-6.67.887-1.79 2.647-2.91 4.601-3.01 1.651-.09 3.368.56 4.798 2.01 1.429-1.45 3.146-2.1 4.796-2.01 1.954.1 3.714 1.22 4.601 3.01.896 1.81.846 4.17-.514 6.67z"/></svg>
            </button>
        </div>
    `;

    // Add delete button handler
    card.querySelector('.community-tweet-mini-btn.delete').addEventListener('click', (e) => {
        e.stopPropagation();
        communityState.tweets.delete(tweet.id);
        card.remove();
        if (communityState.tweets.size === 0) {
            showEmptyState(communityList, '暂无帖子，请点击扫描');
        }
    });

    // Add expand button handler
    card.querySelector('.community-tweet-mini-btn.expand').addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.tabs.create({ url: tweet.url });
    });

    communityList.prepend(card);
}

// Community picker modal
function showCommunityPickerModal(communities) {
    // Create modal overlay
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.id = 'communityPickerOverlay';

    const modal = document.createElement('div');
    modal.className = 'modal community-picker-modal';
    modal.innerHTML = `
        <div class="modal-header">
            <h3>选择社群</h3>
            <button class="modal-close-btn" id="closeCommunityPicker">✕</button>
        </div>
        <div class="modal-body">
            <div class="community-list">
                ${communities.map((c, i) => `
                    <div class="community-item" data-index="${i}" data-id="${c.id}">
                        <span class="community-name">${c.name}</span>
                        <span class="community-members">${c.memberCount || ''} 成员</span>
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Close button
    document.getElementById('closeCommunityPicker').addEventListener('click', () => {
        overlay.remove();
    });

    // Community selection
    modal.querySelectorAll('.community-item').forEach(item => {
        item.addEventListener('click', () => {
            const index = parseInt(item.dataset.index);
            const selected = communities[index];

            communityState.selectedCommunity = selected;
            communityState.communityName = selected.name;
            communityStatusText.textContent = `当前社群: ${selected.name}`;

            overlay.remove();
            showNotification(`已选择: ${selected.name}`, false);
        });
    });

    // Click overlay to close
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) overlay.remove();
    });
}

// Show Multi-Group Picker Modal
async function showMultiGroupPicker() {
    communityStatusText.textContent = '正在获取群组列表...';

    let communities = [];
    try {
        communities = await sendMessageToActiveTab({ action: 'GET_COMMUNITIES' });

        if (!communities || communities.length === 0) {
            communityStatusText.textContent = '正在扫描消息面板...';
            await new Promise(r => setTimeout(r, 1500));
            communities = await sendMessageToActiveTab({ action: 'GET_COMMUNITIES' });
        }
    } catch (e) {
        console.error('Failed to get communities:', e);
    }

    if (!communities || communities.length === 0) {
        communityStatusText.textContent = '未找到群组，请展开 X 消息面板';
        showNotification('未找到群组', true);
        return;
    }

    // Create modal
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
        <div class="community-picker-modal">
            <div class="modal-header">
                <h3>选择群组</h3>
                <button class="modal-close-btn">✕</button>
            </div>
            <div class="modal-body">
                <div class="community-list">
                    ${communities.map((c, i) => `
                        <label class="community-item-checkbox">
                            <input type="checkbox" data-index="${i}" />
                            <span class="community-name">${c.name}</span>
                            <span class="community-members">${c.memberCount || ''}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
            <div class="modal-footer">
                <button class="modal-btn secondary" id="selectAllGroupsBtn">全选</button>
                <button class="modal-btn primary" id="startMultiScanBtn">开始扫描</button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    // Close button
    overlay.querySelector('.modal-close-btn').addEventListener('click', () => overlay.remove());

    // Select all
    overlay.querySelector('#selectAllGroupsBtn').addEventListener('click', () => {
        const checkboxes = overlay.querySelectorAll('input[type="checkbox"]');
        const allChecked = Array.from(checkboxes).every(cb => cb.checked);
        checkboxes.forEach(cb => cb.checked = !allChecked);
    });

    // Start multi-scan
    overlay.querySelector('#startMultiScanBtn').addEventListener('click', async () => {
        const checkboxes = overlay.querySelectorAll('input[type="checkbox"]:checked');
        const selectedIndices = Array.from(checkboxes).map(cb => parseInt(cb.dataset.index));

        if (selectedIndices.length === 0) {
            showNotification('请至少选择一个群组', true);
            return;
        }

        const selectedCommunities = selectedIndices.map(i => communities[i]);
        overlay.remove();

        // Start multi-group scan
        await scanMultipleGroups(selectedCommunities);
    });

    // Click overlay to close
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) overlay.remove();
    });
}

// Scan Multiple Groups
async function scanMultipleGroups(groups) {
    communityState.scanning = true;
    scanCommunityBtn.classList.add('active-state');

    let totalTweets = 0;

    for (let i = 0; i < groups.length; i++) {
        if (!communityState.scanning) break;

        const group = groups[i];
        communityStatusText.textContent = `扫描中 ${i + 1}/${groups.length}: ${group.name}`;

        try {
            // Click on the group to enter it
            await sendMessageToActiveTab({
                action: 'CLICK_COMMUNITY',
                communityId: group.id
            });

            // Wait for the chat to load
            await new Promise(r => setTimeout(r, 2000));

            if (!communityState.scanning) break;

            // Scan the current page
            const result = await sendMessageToActiveTab({
                action: 'SCAN_COMMUNITY'
            });

            if (result && result.tweets && result.tweets.length > 0) {
                result.tweets.forEach(tweet => {
                    if (!communityState.tweets.has(tweet.id)) {
                        communityState.tweets.set(tweet.id, {
                            ...tweet,
                            groupName: group.name,
                            interactions: { reply: false, like: false, retweet: false }
                        });
                        addCommunityTweetCard(tweet);
                        totalTweets++;
                    }
                });
            }
        } catch (e) {
            console.error(`Failed to scan group ${group.name}:`, e);
        }
    }

    communityState.scanning = false;
    scanCommunityBtn.classList.remove('active-state');
    communityStatusText.textContent = `扫描完成，共找到 ${totalTweets} 条帖子`;
    showNotification(`多群组扫描完成，共 ${totalTweets} 条帖子`, false);
}
