#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成插件图标 - 奶牛花纹背景 + AI字母"""

from PIL import Image, ImageDraw, ImageFont
import os

def generate_icon(size):
    """生成指定尺寸的图标"""
    # 创建白色背景
    img = Image.new('RGB', (size, size), color='#FFFFFF')
    draw = ImageDraw.Draw(img)
    
    # 奶牛花纹斑块位置
    spots = [
        {'x': 0, 'y': 0, 'w': int(size * 0.4), 'h': int(size * 0.3)},
        {'x': int(size * 0.5), 'y': 0, 'w': int(size * 0.5), 'h': int(size * 0.4)},
        {'x': 0, 'y': int(size * 0.4), 'w': int(size * 0.3), 'h': int(size * 0.6)},
        {'x': int(size * 0.4), 'y': int(size * 0.5), 'w': int(size * 0.6), 'h': int(size * 0.5)},
        {'x': int(size * 0.2), 'y': int(size * 0.7), 'w': int(size * 0.3), 'h': int(size * 0.3)},
    ]
    
    # 绘制黑色斑块（椭圆）
    for spot in spots:
        bbox = [spot['x'], spot['y'], spot['x'] + spot['w'], spot['y'] + spot['h']]
        draw.ellipse(bbox, fill='#2C2C2C')
    
    # 绘制小斑块
    small_spots = [
        {'x': int(size * 0.15), 'y': int(size * 0.15), 'r': int(size * 0.08)},
        {'x': int(size * 0.75), 'y': int(size * 0.25), 'r': int(size * 0.06)},
        {'x': int(size * 0.3), 'y': int(size * 0.6), 'r': int(size * 0.05)},
        {'x': int(size * 0.7), 'y': int(size * 0.7), 'r': int(size * 0.07)},
    ]
    
    for spot in small_spots:
        bbox = [
            spot['x'] - spot['r'],
            spot['y'] - spot['r'],
            spot['x'] + spot['r'],
            spot['y'] + spot['r']
        ]
        draw.ellipse(bbox, fill='#1A1A1A')
    
    # 绘制"AI"字母
    try:
        # 尝试使用系统字体
        font_size = int(size * 0.35)
        try:
            # Windows
            font = ImageFont.truetype("arial.ttf", font_size)
        except:
            try:
                # macOS
                font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", font_size)
            except:
                # Linux 或默认
                font = ImageFont.load_default()
    except:
        font = ImageFont.load_default()
    
    text = "AI"
    text_x = size // 2
    text_y = size // 2
    
    # 计算文本尺寸以居中
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    # 绘制黑色边框（通过多次偏移绘制实现粗边框）
    border_width = max(1, int(size * 0.015))
    for dx in range(-border_width, border_width + 1):
        for dy in range(-border_width, border_width + 1):
            if dx*dx + dy*dy <= border_width*border_width:
                draw.text(
                    (text_x - text_width // 2 + dx, text_y - text_height // 2 + dy),
                    text,
                    fill='#000000',
                    font=font
                )
    
    # 绘制白色填充
    draw.text(
        (text_x - text_width // 2, text_y - text_height // 2),
        text,
        fill='#FFFFFF',
        font=font
    )
    
    return img

if __name__ == '__main__':
    sizes = [16, 48, 128]
    for size in sizes:
        img = generate_icon(size)
        filename = f'icon{size}.png'
        img.save(filename)
        print(f'Generated {filename} ({size}x{size})')




